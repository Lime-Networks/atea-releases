// ============================================================
// Lime Networks — content.itglue.js
// ITGlue documentatie modal: ticket-oplossing wegschrijven als ITGlue-document
// via een N8N-webhook. De ITGlue API key en het bepalen van de klant leven in
// N8N, nooit in de extensie.
//
// VEILIGHEIDSKEUZES (dit herhaalt bewust NIET de fouten van de verwijderde
// Script-tab, F11):
// - Geen default/hardcoded webhook URL, ooit. Leeg totdat de engineer 'm instelt.
// - Auth-token is VERPLICHT, geen fallback-pad zonder token. En alleen over https.
// - De klant wordt NIET hier gekozen. ATEA stuurt alleen het ticketnummer; N8N
//   zoekt het bedrijf op in Autotask en de bijbehorende organisatie in ITGlue.
//   Zo kan een typfout of een verkeerde keuze het document niet bij de verkeerde
//   klant laten belanden. De enige keuze is "klant" (standaard) of "lime" voor
//   algemene kennis; welke organisatie Lime is, staat vast in N8N.
// - Geen opslag van concept-content. Alles leeft in de modal-state en verdwijnt
//   bij sluiten, net als de mail-modal.
// - Sensitivity-scan is een HARDE blokkade (content.security.js). N8N herhaalt
//   die controle server-side, want een directe POST omzeilt deze check.
// ============================================================

const LN_ITGLUE_CATEGORIES = [
  { value: "email",     label: "📧 Email" },
  { value: "netwerk",   label: "🌐 Netwerk" },
  { value: "account",   label: "🔑 Account/Toegang" },
  { value: "hardware",  label: "💻 Hardware" },
  { value: "software",  label: "⚙️ Software" },
  { value: "telefoon",  label: "📞 Telefoon" },
  { value: "server",    label: "🖥️ Server" },
  { value: "overig",    label: "📋 Overig" }
];

// --- Ticketnummer van het ticket dat openstaat ---
// Het ticketnummer bepaalt bij welke klant het document terechtkomt. Dus niet het
// eerste T-nummer op de pagina pakken (readTicketMetadata doet dat): dat kan uit
// een paneel met gerelateerde tickets komen. Wel de venstertitel, die Autotask
// vult als "Ticket - T20260924.0021 - <titel> (<klant>)" — zo gezien op echte
// ticketpagina's. De URL is geen optie: die bevat soms meerdere tickets.
// Niets gevonden = null, en dan wordt er niet verzonden.
const LN_TICKET_IN_TITLE = /\bTicket\s*-\s*(T\d{8}\.\d{4})\b/;
const LN_TICKET_HEADER   = /^Ticket\s*-\s*(T\d{8}\.\d{4})\b/;

// Venstertitel van de ticketpagina: eigen frame eerst, vanuit een iframe die van
// het hoofdvenster. Alleen titels waar een ticketnummer in staat.
function _lnTicketWindowTitle() {
  const titleOf = (doc) => { try { return String(doc && doc.title || ""); } catch (e) { return ""; } };
  let t = titleOf(document);
  if (!LN_TICKET_IN_TITLE.test(t)) { try { t = titleOf(window.top.document); } catch (e) { t = ""; } }
  return LN_TICKET_IN_TITLE.test(t) ? t : "";
}

function currentTicketNumber() {
  const nr = _lnTicketWindowTitle().match(LN_TICKET_IN_TITLE)?.[1] || null;
  if (nr) return nr;
  // Terugval: de kopbalk van het ticket, die dezelfde tekst toont.
  for (const el of document.querySelectorAll("h1, h2, div, span")) {
    const txt = (el.textContent || "").trim();
    if (txt.length > 300) continue;
    const m = txt.match(LN_TICKET_HEADER);
    if (m) return m[1];
  }
  return null;
}

// --- Klantnaam uit de documenttitel houden ---
// Tickettitels beginnen vaak met de klant ("Adriaan van Erk Groep - AvE-CN02 -
// Cluster Volume Status"). In ITGlue staat het document al bij die klant, dus die
// naam is dubbel. De klant staat tussen haakjes achter in de venstertitel:
// "Ticket - T20260923.0003 - <titel> (<klant>)". Alleen voor het vooraf invullen:
// de engineer ziet en bewerkt de titel nog, en wat hij verstuurt, gaat zo naar ITGlue.
function currentTicketCustomer() {
  const m = _lnTicketWindowTitle().match(/\(([^()]+)\)\s*$/);
  return m ? m[1].trim() : "";
}

function _lnStripCustomerPrefix(title, customer) {
  const t = String(title || "").trim();
  const c = String(customer || "").trim();
  if (!t || !c) return t;
  const escRe = s => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const pattern = name => name.split(/\s+/).map(escRe).join("\\s+");
  // Ook zonder rechtsvorm: Autotask zegt soms "X B.V." waar de titel "X" gebruikt.
  const bare = c.replace(/[\s,]*\b(B\.?\s?V\.?|N\.?\s?V\.?|V\.?O\.?F\.?|GmbH|Ltd\.?)\s*$/i, "").trim();
  for (const name of [c, bare]) {
    if (!name) continue;
    // Alleen weghalen als er een scheidingsteken volgt, en nooit de hele titel.
    const re = new RegExp("^" + pattern(name) + "\\s*[-–—:|]\\s*", "i");
    const rest = t.replace(re, "").trim();
    if (rest && rest !== t) return rest;
  }
  return t;
}

// --- Waar het document terechtkomt ---
// Statische teksten (geen invoer van de pagina), dus veilig in innerHTML/textContent.
const LN_ITGLUE_DEST_HINT = {
  klant: "Het document komt bij de klant van dit ticket (Autotask → ITGlue). Klopt dit ticketnummer niet, verstuur dan niet.",
  lime:  "Het document komt bij Lime Networks zelf, als algemene kennis. Laat klantnamen, hostnamen, IP-adressen en " +
         "gebruikersnamen weg. Klik zo nodig opnieuw op AI-voorstel voor een algemene versie."
};

function _lnSelectedDest(modal) {
  const v = modal.querySelector('input[name="ln-itglue-dest"]:checked')?.value;
  return v === "lime" ? "lime" : "klant";
}

// --- Alleen een link naar ITGlue zelf tonen ---
function _lnIsItglueUrl(url) {
  try {
    const u = new URL(url);
    return u.protocol === "https:" && (u.hostname === "itglue.com" || u.hostname.endsWith(".itglue.com"));
  } catch (e) { return false; }
}

// --- Sensitivity-status renderen in de modal ---
function _lnRenderSensitivityStatus(modal, text) {
  const box = modal.querySelector("#ln-itglue-sensitivity");
  const sendBtn = modal.querySelector("#ln-itglue-send");
  const hits = detectSensitiveData(text);
  if (hits.length === 0) {
    box.style.display = "none";
    box.innerHTML = "";
    sendBtn.dataset.blockedSensitive = "";
  } else {
    const lines = hits.map(h => `regel ${h.line} (${esc(h.type)})`).join(", ");
    box.style.display = "block";
    box.innerHTML = `🚫 Mogelijk gevoelige data gevonden: ${esc(lines)}. Verwijder dit eerst — dit blokkeert verzenden.`;
    sendBtn.dataset.blockedSensitive = "1";
  }
  _lnUpdateSendState(modal);
}

// --- Verzendknop enable/disable op basis van alle voorwaarden samen ---
function _lnUpdateSendState(modal) {
  const sendBtn  = modal.querySelector("#ln-itglue-send");
  const title    = modal.querySelector("#ln-itglue-title").value.trim();
  const content  = modal.querySelector("#ln-itglue-content").value.trim();
  const blocked  = sendBtn.dataset.blockedSensitive === "1";
  const noAuth   = sendBtn.dataset.noAuth === "1";
  const noTicket = sendBtn.dataset.noTicket === "1";
  sendBtn.disabled = blocked || noAuth || noTicket || !title || !content;
  sendBtn.style.opacity = sendBtn.disabled ? "0.5" : "1";
}

// --- Resultaat of fout blijvend in de modal tonen (een toast is na 3,5s weg) ---
function _lnShowResult(modal, ok, text, url) {
  const el = modal.querySelector("#ln-itglue-result");
  el.style.display = "block";
  el.style.color = ok ? "#84cc16" : "#fca5a5";
  el.textContent = "";
  const line = document.createElement("div");
  line.textContent = text;
  el.appendChild(line);
  if (ok && url && _lnIsItglueUrl(url)) {
    const link = document.createElement("a");
    link.href = url;
    link.target = "_blank";
    link.rel = "noopener noreferrer";
    link.style.cssText = "color:#84cc16;font-size:12px;text-decoration:none;";
    link.textContent = "🔗 Openen in ITGlue";
    el.appendChild(link);
  }
}

// --- POST naar een N8N-webhook, met foutmeldingen die een engineer begrijpt ---
// timeoutMs alleen bij zoeken. Bij documenteren kan N8N na een afgebroken
// aanvraag toch doorgaan, en dan zou "mislukt" niet kloppen.
async function _lnCallWebhook(url, token, payload, timeoutMs) {
  const ctrl  = timeoutMs ? new AbortController() : null;
  const timer = ctrl ? setTimeout(() => ctrl.abort(), timeoutMs) : null;
  let res;
  try {
    res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json", "Authorization": `Bearer ${token}` },
      body: JSON.stringify(payload),
      signal: ctrl ? ctrl.signal : undefined
    });
  } catch (e) {
    if (e && e.name === "AbortError") throw new Error("N8N gaf geen antwoord binnen de tijd. Probeer het later opnieuw.");
    throw e;
  } finally {
    if (timer) clearTimeout(timer);
  }
  if (!res.ok) {
    let msg = "";
    try { msg = (await res.json()).error || ""; } catch (e) {}
    if (res.status === 403) msg = "Het webhook-token klopt niet. Controleer het token in ⚙️ Instellingen.";
    if (res.status === 404) msg = msg || "Webhook niet gevonden. Klopt de URL, en staat de N8N-workflow aan?";
    throw new Error(msg || `Webhook HTTP ${res.status}`);
  }
  const data = await res.json().catch(() => ({}));
  if (data.error) throw new Error(data.error);
  return data;
}

// --- ITGlue modal tonen ---
async function showITGlueModal() {
  document.getElementById("ln-itglue-modal")?.remove();

  const ticketNr = currentTicketNumber();
  const { ticketTitle, existingNotes, ticketDescription } = getTicketContext();
  const hasEntries = existingNotes.length > 0;

  const itglueSettings = await loadItglueSettings();
  const authConfigured = !!(itglueSettings.webhookUrl && itglueSettings.token);

  const overlay = document.createElement("div");
  overlay.id = "ln-itglue-modal";
  Object.assign(overlay.style, {
    position: "fixed", inset: "0", zIndex: "99999999",
    background: "rgba(0,0,0,0.65)", display: "flex",
    alignItems: "center", justifyContent: "center",
    fontFamily: "Segoe UI, system-ui, sans-serif"
  });

  const modal = document.createElement("div");
  Object.assign(modal.style, {
    background: "#1a2233", border: "1.5px solid #84cc16",
    borderRadius: "12px", width: "560px", maxWidth: "calc(100vw - 40px)",
    maxHeight: "calc(100vh - 40px)", overflow: "hidden",
    display: "flex", flexDirection: "column",
    boxShadow: "0 8px 40px rgba(0,0,0,0.6)"
  });

  const safeTitle = esc(_lnStripCustomerPrefix(ticketTitle || "", currentTicketCustomer()));

  const authWarning = authConfigured ? "" : `
    <div style="background:#3a1f1f;border:1px solid #ef4444;border-radius:6px;padding:10px 12px;font-size:12px;color:#fca5a5;line-height:1.5;">
      ⚠️ Webhook-URL en/of token niet ingesteld. Stel dit eerst in via <strong>⚙️ Instellingen</strong> —
      zonder token blijft verzenden uitgeschakeld.
    </div>`;

  const ticketBlock = ticketNr
    ? `<div style="background:#0f1620;border:1px solid #2e3a50;border-radius:6px;padding:8px 10px;font-size:12px;color:#9ca3af;line-height:1.5;">
         Ticket <strong style="color:#e5e7eb;">${esc(ticketNr)}</strong>.
         <span id="ln-itglue-dest-hint">${LN_ITGLUE_DEST_HINT.klant}</span>
       </div>`
    : `<div style="background:#3a1f1f;border:1px solid #ef4444;border-radius:6px;padding:10px 12px;font-size:12px;color:#fca5a5;line-height:1.5;">
         ⚠️ Geen ticketnummer gevonden op deze pagina. Open het ticket zelf en probeer het daar opnieuw.
       </div>`;

  const radioStyle = "display:flex;align-items:center;gap:6px;font-size:13px;color:#e5e7eb;cursor:pointer;";
  const destBlock = `
      <div>
        <label style="font-size:11px;font-weight:700;color:#84cc16;text-transform:uppercase;letter-spacing:0.5px;display:block;margin-bottom:5px;">Vastleggen bij</label>
        <div style="display:flex;gap:18px;flex-wrap:wrap;">
          <label style="${radioStyle}"><input type="radio" name="ln-itglue-dest" value="klant" checked style="accent-color:#84cc16;margin:0;"> Klant van dit ticket</label>
          <label style="${radioStyle}"><input type="radio" name="ln-itglue-dest" value="lime" style="accent-color:#84cc16;margin:0;"> Lime Networks (algemene kennis)</label>
        </div>
      </div>`;

  modal.innerHTML = `
    <div style="display:flex;align-items:center;justify-content:space-between;padding:16px 20px;border-bottom:1px solid #2e3a50;flex-shrink:0;">
      <span style="font-size:15px;font-weight:700;color:#e5e7eb;">&#x1F4DA; Documenteren in ITGlue</span>
      <span id="ln-itglue-close" style="cursor:pointer;font-size:22px;color:#6b7280;line-height:1;padding:2px 6px;">&times;</span>
    </div>
    <div style="overflow-y:auto;padding:16px 20px;display:flex;flex-direction:column;gap:14px;">
      ${authWarning}
      ${destBlock}
      ${ticketBlock}
      <div>
        <label style="font-size:11px;font-weight:700;color:#84cc16;text-transform:uppercase;letter-spacing:0.5px;display:block;margin-bottom:5px;">Type</label>
        <select id="ln-itglue-type"
          style="width:100%;box-sizing:border-box;background:#252d3d;border:1px solid #3d4e6b;border-radius:6px;
          padding:8px 10px;color:#e5e7eb;font-size:13px;outline:none;font-family:Segoe UI,system-ui,sans-serif;">
          ${LN_ITGLUE_CATEGORIES.map(c => `<option value="${esc(c.value)}">${esc(c.label)}</option>`).join("")}
        </select>
      </div>
      <div>
        <label style="font-size:11px;font-weight:700;color:#84cc16;text-transform:uppercase;letter-spacing:0.5px;display:block;margin-bottom:5px;">Titel *</label>
        <input id="ln-itglue-title" type="text" value="${safeTitle}"
          style="width:100%;box-sizing:border-box;background:#252d3d;border:1px solid #3d4e6b;border-radius:6px;
          padding:8px 10px;color:#e5e7eb;font-size:13px;outline:none;font-family:Segoe UI,system-ui,sans-serif;" />
      </div>
      <div>
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:5px;">
          <label style="font-size:11px;font-weight:700;color:#84cc16;text-transform:uppercase;letter-spacing:0.5px;">Inhoud * <span style="color:#4b5563;font-weight:400;text-transform:none;">(altijd bewerkbaar vóór verzenden)</span></label>
          <button id="ln-itglue-generate" style="background:#252d3d;border:1px solid #3d4e6b;border-radius:6px;padding:4px 10px;color:#84cc16;font-size:11px;font-weight:700;cursor:pointer;">&#x2728; AI-voorstel</button>
        </div>
        <textarea id="ln-itglue-content" placeholder="Beschrijf het probleem en de oplossing, of klik op AI-voorstel..."
          style="width:100%;box-sizing:border-box;background:#252d3d;border:1px solid #3d4e6b;border-radius:6px;
          padding:8px 10px;color:#e5e7eb;font-size:13px;line-height:1.6;resize:vertical;min-height:160px;
          outline:none;font-family:Segoe UI,system-ui,sans-serif;"></textarea>
        <div id="ln-itglue-sensitivity" style="display:none;margin-top:6px;background:#3a1f1f;border:1px solid #ef4444;border-radius:6px;padding:8px 10px;font-size:11px;color:#fca5a5;line-height:1.5;"></div>
      </div>
      <div style="display:flex;gap:8px;justify-content:flex-end;">
        <button id="ln-itglue-cancel" style="background:#252d3d;border:1px solid #3d4e6b;border-radius:6px;padding:9px 16px;color:#e5e7eb;font-size:13px;font-weight:700;cursor:pointer;">Annuleren</button>
        <button id="ln-itglue-send" disabled style="background:#84cc16;border:none;border-radius:6px;padding:9px 20px;color:#0f1117;font-size:13px;font-weight:700;cursor:pointer;opacity:0.5;">&#x1F4DA; Verzenden naar ITGlue</button>
      </div>
      <div id="ln-itglue-result" style="display:none;font-size:12px;line-height:1.5;"></div>
    </div>
  `;

  overlay.appendChild(modal);
  document.body.appendChild(overlay);

  const sendBtn = modal.querySelector("#ln-itglue-send");
  sendBtn.dataset.noAuth   = authConfigured ? "" : "1";
  sendBtn.dataset.noTicket = ticketNr ? "" : "1";
  const updateSendState = () => _lnUpdateSendState(modal);

  modal.querySelector("#ln-itglue-title").addEventListener("input", updateSendState);
  modal.querySelector("#ln-itglue-content").addEventListener("input", (e) => {
    _lnRenderSensitivityStatus(modal, e.target.value);
  });
  modal.querySelectorAll('input[name="ln-itglue-dest"]').forEach(r => r.addEventListener("change", () => {
    const hint = modal.querySelector("#ln-itglue-dest-hint");
    if (hint) hint.textContent = LN_ITGLUE_DEST_HINT[_lnSelectedDest(modal)];
  }));

  modal.querySelector("#ln-itglue-close").addEventListener("click", () => overlay.remove());
  modal.querySelector("#ln-itglue-cancel").addEventListener("click", () => overlay.remove());
  overlay.addEventListener("click", (e) => { if (e.target === overlay) overlay.remove(); });

  // AI-voorstel genereren
  modal.querySelector("#ln-itglue-generate").addEventListener("click", async () => {
    const genBtn = modal.querySelector("#ln-itglue-generate");
    const contentArea = modal.querySelector("#ln-itglue-content");
    if (!hasEntries && !ticketDescription) {
      showToast("⚠️ Geen time entries of beschrijving gevonden om van uit te gaan.", "warning");
      return;
    }
    genBtn.textContent = "⏳ Bezig...";
    genBtn.disabled = true;
    try {
      const sourceText = hasEntries ? existingNotes.map(n => n.text).join("\n") : ticketDescription;
      const entryLines = hasEntries
        ? existingNotes.map(n => `- [${n.ts || "geen datum"}] ${n.text}`).join("\n")
        : "";
      const raw = hasEntries
        ? `Ticket title: ${ticketTitle}\n\nTime entry notes:\n${entryLines}` +
          (ticketDescription ? `\n\nOriginal problem (ticket description):\n${ticketDescription}` : "")
        : `Ticket title: ${ticketTitle}\n\nTicket description:\n${ticketDescription}`;
      const settings = await loadSettings();
      const lang = await resolveOutputLang(sourceText, settings);
      const draft = await callAIForITGlueDoc(wrapUntrusted(raw), lang, _lnSelectedDest(modal) === "lime");
      contentArea.value = draft.trim();
      _lnRenderSensitivityStatus(modal, contentArea.value);
    } catch(e) {
      showToast("❌ AI-voorstel mislukt: " + e.message, "error");
    } finally {
      genBtn.textContent = "✨ AI-voorstel";
      genBtn.disabled = false;
    }
  });

  // Verzenden
  sendBtn.addEventListener("click", async () => {
    // Laatste check vlak voor verzenden — defense-in-depth naast de live check,
    // voor het geval de knop-state om wat voor reden dan ook niet is bijgewerkt.
    const contentVal = modal.querySelector("#ln-itglue-content").value.trim();
    if (detectSensitiveData(contentVal).length > 0) {
      showToast("🚫 Verzenden geblokkeerd — mogelijk gevoelige data in de inhoud.", "error");
      return;
    }
    if (!ticketNr) return;
    const settings = await loadItglueSettings();
    // Een engineer die "Bearer <token>" plakt zou anders "Bearer Bearer ..." sturen.
    const token = String(settings.token || "").replace(/^\s*Bearer\s+/i, "").trim();
    if (!settings.webhookUrl || !token) {
      showToast("⚠️ Webhook-URL of token ontbreekt — stel dit in via ⚙️ Instellingen.", "warning");
      return;
    }
    if (!/^https:\/\//i.test(settings.webhookUrl)) {
      _lnShowResult(modal, false, "De webhook-URL moet met https:// beginnen. Het token wordt niet over een onversleutelde verbinding verstuurd.");
      return;
    }
    const typeVal  = modal.querySelector("#ln-itglue-type").value;
    const titleVal = modal.querySelector("#ln-itglue-title").value.trim();
    if (!titleVal || !contentVal) return;

    sendBtn.textContent = "⏳ Bezig...";
    sendBtn.disabled = true;
    try {
      const payload = {
        ticket_number: ticketNr,
        destination:   _lnSelectedDest(modal),
        asset_type:    typeVal,
        title:         titleVal,
        content:       contentVal,
        tags:          [`ticket:${ticketNr}`, typeVal]
      };
      const data = await _lnCallWebhook(settings.webhookUrl, token, payload);
      // Een lege 200 betekent dat de flow is gestopt zonder te bevestigen. Dan
      // weten we niet of er iets is aangemaakt, dus geen succes melden.
      if (!data.itglue_id) {
        throw new Error("Geen bevestiging van ITGlue ontvangen. Controleer in ITGlue of het document bestaat voordat je opnieuw verstuurt.");
      }

      const waar = data.organization ? ` bij ${data.organization}` : "";
      _lnShowResult(modal, true, `✅ Gedocumenteerd in ITGlue${waar}.`, data.itglue_url);
      showToast("📚 Gedocumenteerd in ITGlue!", "success");
      sendBtn.textContent = "✅ Verzonden";
    } catch(e) {
      _lnShowResult(modal, false, "❌ " + e.message);
      showToast("❌ Verzenden mislukt", "error");
      sendBtn.textContent = "📚 Verzenden naar ITGlue";
      updateSendState();
    }
  });

  updateSendState();
  setTimeout(() => modal.querySelector("#ln-itglue-content")?.focus(), 100);
}

// ============================================================
// 🔎 Kennis zoeken in ITGlue
// De andere kant op: N8N zoekt in ITGlue naar documentatie die bij dit ticket
// past, en geeft verwijzingen en een mogelijke oplossing terug. Gezocht wordt
// in alle documentatie van de klant en in de ATEA-map van Lime (bij een ticket
// op Lime zelf: alles van Lime). Workflow: n8n-atea-itglue-zoeken-workflow.json.
//
// VEILIGHEIDSKEUZES:
// - ATEA stuurt alleen het ticketnummer. Wat er gezocht wordt en bij welke
//   klant, bepaalt N8N (Autotask → ITGlue), net als bij het documenteren.
// - Afgeschermde documenten slaat N8N over: de ITGlue-key ziet meer dan een
//   engineer mag zien.
// - Wat terugkomt is inhoud uit ITGlue en van een AI. Alleen als tekst tonen
//   (textContent), links alleen naar *.itglue.com, gevoelige delen nogmaals
//   weglaten. En alleen tonen: er gaat niets vanzelf het ticket in.
// ============================================================
const LN_SEARCH_TIMEOUT_MS = 120000;

function _lnRenderSearchResult(box, data) {
  const el = (tag, css, text) => {
    const e = document.createElement(tag);
    if (css) e.style.cssText = css;
    if (text !== undefined) e.textContent = text;
    return e;
  };
  box.textContent = "";
  const results  = Array.isArray(data.results) ? data.results : [];
  const solution = redactSensitive(typeof data.solution === "string" ? data.solution : "").trim();
  const searched = data.searched || {};
  const klant    = (typeof data.organization === "string" && data.organization.trim()) || "de klant";
  const label    = "font-size:11px;font-weight:700;color:#84cc16;text-transform:uppercase;letter-spacing:0.5px;";

  if (solution) {
    const sol = el("div", "background:#0f1620;border:1px solid #84cc16;border-radius:6px;padding:10px 12px;");
    sol.appendChild(el("div", label + "margin-bottom:6px;", "💡 Mogelijke oplossing"));
    sol.appendChild(el("div", "font-size:13px;color:#e5e7eb;line-height:1.6;white-space:pre-wrap;", solution));
    sol.appendChild(el("div", "font-size:11px;color:#6b7280;margin-top:8px;line-height:1.4;",
      "AI-voorstel op basis van de documenten hieronder. Controleer het zelf voordat je het toepast."));
    box.appendChild(sol);
  }

  if (results.length) {
    box.appendChild(el("div", label, `Documentatie (${results.length})`));
    for (const r of results) {
      const row  = el("div", "background:#252d3d;border:1px solid #3d4e6b;border-radius:6px;padding:8px 10px;");
      const head = el("div", "display:flex;gap:8px;align-items:baseline;flex-wrap:wrap;");
      head.appendChild(el("span", "color:#9ca3af;font-size:12px;", `[${Number(r.nr) || "?"}]`));
      const title = redactSensitive(String(r.title || "(zonder titel)"));
      if (r.url && _lnIsItglueUrl(r.url)) {
        const a = el("a", "color:#84cc16;font-size:13px;font-weight:600;text-decoration:none;", title);
        a.href = r.url;
        a.target = "_blank";
        a.rel = "noopener noreferrer";
        head.appendChild(a);
      } else {
        head.appendChild(el("span", "color:#e5e7eb;font-size:13px;font-weight:600;", title));
      }
      head.appendChild(el("span", "font-size:10px;color:#0f1117;background:" + (r.source === "lime" ? "#84cc16" : "#9ca3af") +
        ";border-radius:4px;padding:1px 6px;", r.source === "lime" ? "Lime" : klant));
      row.appendChild(head);
      const reason = redactSensitive(String(r.reason || "")).trim();
      if (reason) row.appendChild(el("div", "font-size:12px;color:#9ca3af;margin-top:4px;line-height:1.5;", reason));
      box.appendChild(row);
    }
  }

  if (!solution && !results.length) {
    box.appendChild(el("div", "font-size:13px;color:#e5e7eb;", "Geen passende documentatie gevonden in ITGlue."));
  }

  const nKlant = Number(searched.klant) || 0, nLime = Number(searched.lime) || 0;
  box.appendChild(el("div", "font-size:11px;color:#6b7280;",
    `Gezocht in ${nKlant} documenten van ${klant}` + (nLime ? ` en ${nLime} in de ATEA-map van Lime.` : ".")));
}

async function showITGlueSearchModal() {
  document.getElementById("ln-itglue-search-modal")?.remove();

  const ticketNr = currentTicketNumber();
  const settings = await loadItglueSettings();
  const token    = String(settings.token || "").replace(/^\s*Bearer\s+/i, "").trim();

  const problem = !ticketNr
      ? "⚠️ Geen ticketnummer gevonden op deze pagina. Open het ticket zelf en probeer het daar opnieuw."
    : (!settings.searchUrl || !token)
      ? "⚠️ Zoek-URL en/of token niet ingesteld. Stel dit eerst in via ⚙️ Instellingen."
    : !/^https:\/\//i.test(settings.searchUrl)
      ? "De zoek-URL moet met https:// beginnen. Het token wordt niet over een onversleutelde verbinding verstuurd."
    : "";

  const overlay = document.createElement("div");
  overlay.id = "ln-itglue-search-modal";
  Object.assign(overlay.style, {
    position: "fixed", inset: "0", zIndex: "99999999",
    background: "rgba(0,0,0,0.65)", display: "flex",
    alignItems: "center", justifyContent: "center",
    fontFamily: "Segoe UI, system-ui, sans-serif"
  });

  const modal = document.createElement("div");
  Object.assign(modal.style, {
    background: "#1a2233", border: "1.5px solid #84cc16",
    borderRadius: "12px", width: "620px", maxWidth: "calc(100vw - 40px)",
    maxHeight: "calc(100vh - 40px)", overflow: "hidden",
    display: "flex", flexDirection: "column",
    boxShadow: "0 8px 40px rgba(0,0,0,0.6)"
  });

  modal.innerHTML = `
    <div style="display:flex;align-items:center;justify-content:space-between;padding:16px 20px;border-bottom:1px solid #2e3a50;flex-shrink:0;">
      <span style="font-size:15px;font-weight:700;color:#e5e7eb;">&#x1F50E; Kennis uit ITGlue</span>
      <span id="ln-search-close" style="cursor:pointer;font-size:22px;color:#6b7280;line-height:1;padding:2px 6px;">&times;</span>
    </div>
    <div style="overflow-y:auto;padding:16px 20px;display:flex;flex-direction:column;gap:12px;">
      <div id="ln-search-scope" style="background:#0f1620;border:1px solid #2e3a50;border-radius:6px;padding:8px 10px;font-size:12px;color:#9ca3af;line-height:1.5;"></div>
      <div id="ln-search-status" style="display:none;font-size:12px;line-height:1.5;"></div>
      <div id="ln-search-result" style="display:flex;flex-direction:column;gap:8px;"></div>
      <div style="display:flex;gap:8px;justify-content:flex-end;">
        <button id="ln-search-again" style="background:#252d3d;border:1px solid #3d4e6b;border-radius:6px;padding:9px 16px;color:#e5e7eb;font-size:13px;font-weight:700;cursor:pointer;">&#x1F50E; Opnieuw zoeken</button>
        <button id="ln-search-ok" style="background:#84cc16;border:none;border-radius:6px;padding:9px 20px;color:#0f1117;font-size:13px;font-weight:700;cursor:pointer;">Sluiten</button>
      </div>
    </div>
  `;
  overlay.appendChild(modal);
  document.body.appendChild(overlay);

  const scopeEl  = modal.querySelector("#ln-search-scope");
  const statusEl = modal.querySelector("#ln-search-status");
  const resultEl = modal.querySelector("#ln-search-result");
  const againBtn = modal.querySelector("#ln-search-again");

  if (ticketNr) {
    scopeEl.textContent = `Ticket ${ticketNr}. Gezocht wordt in alle documentatie van de klant van dit ticket, ` +
      "en in de ATEA-map van Lime. Afgeschermde documenten worden overgeslagen.";
  } else {
    scopeEl.style.display = "none";
  }

  const setStatus = (text, kind) => {
    statusEl.style.display = text ? "block" : "none";
    statusEl.style.color = kind === "error" ? "#fca5a5" : "#9ca3af";
    statusEl.textContent = text;
  };

  const close = () => overlay.remove();
  modal.querySelector("#ln-search-close").addEventListener("click", close);
  modal.querySelector("#ln-search-ok").addEventListener("click", close);
  overlay.addEventListener("click", (e) => { if (e.target === overlay) close(); });

  const search = async () => {
    if (problem) { setStatus(problem, "error"); againBtn.disabled = true; againBtn.style.opacity = "0.5"; return; }
    againBtn.disabled = true;
    againBtn.style.opacity = "0.5";
    resultEl.textContent = "";
    setStatus("⏳ Zoeken in ITGlue… dit kan een halve minuut duren.", "busy");
    try {
      const data = await _lnCallWebhook(settings.searchUrl, token, { ticket_number: ticketNr }, LN_SEARCH_TIMEOUT_MS);
      if (!data || !Array.isArray(data.results)) {
        throw new Error("Onverwacht antwoord van N8N. Staat de zoek-URL op de zoek-workflow (niet op die van het documenteren)?");
      }
      setStatus("", "");
      _lnRenderSearchResult(resultEl, data);
    } catch (e) {
      setStatus("❌ " + e.message, "error");
    } finally {
      againBtn.disabled = false;
      againBtn.style.opacity = "1";
    }
  };
  againBtn.addEventListener("click", search);
  search();
}
