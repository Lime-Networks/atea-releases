// ============================================================
// Lime Networks — content.itglue.js
// ITGlue documentatie modal: ticket-oplossing wegschrijven als ITGlue-document
// via een N8N-webhook. De ITGlue API key en het bepalen van de klant leven in
// N8N, nooit in de extensie.
//
// VEILIGHEIDSKEUZES (dit herhaalt bewust NIET de fouten van de verwijderde
// Script-tab, F11):
// - Geen default/hardcoded webhook URL, ooit. Leeg totdat de engineer 'm instelt.
// - Auth-token is VERPLICHT, geen fallback-pad zonder token. En alleen over https.
// - De klant wordt NIET hier gekozen. ATEA stuurt alleen het ticketnummer; N8N
//   zoekt het bedrijf op in Autotask en de bijbehorende organisatie in ITGlue.
//   Zo kan een typfout of een verkeerde keuze het document niet bij de verkeerde
//   klant laten belanden. De enige keuze is "klant" (standaard) of "lime" voor
//   algemene kennis; welke organisatie Lime is, staat vast in N8N.
// - Geen opslag van concept-content. Alles leeft in de modal-state en verdwijnt
//   bij sluiten, net als de mail-modal.
// - Sensitivity-scan is een HARDE blokkade (content.security.js). N8N herhaalt
//   die controle server-side, want een directe POST omzeilt deze check.
// ============================================================

const LN_ITGLUE_CATEGORIES = [
  { value: "email",     label: "📧 Email" },
  { value: "netwerk",   label: "🌐 Netwerk" },
  { value: "account",   label: "🔑 Account/Toegang" },
  { value: "hardware",  label: "💻 Hardware" },
  { value: "software",  label: "⚙️ Software" },
  { value: "telefoon",  label: "📞 Telefoon" },
  { value: "server",    label: "🖥️ Server" },
  { value: "overig",    label: "📋 Overig" }
];

// --- Ticketnummer van het ticket dat openstaat ---
// Het ticketnummer bepaalt bij welke klant het document terechtkomt. Dus niet het
// eerste T-nummer op de pagina pakken (readTicketMetadata doet dat): dat kan uit
// een paneel met gerelateerde tickets komen. Wel de venstertitel, die Autotask
// vult als "Ticket - T20260924.0021 - <titel> (<klant>)" — zo gezien op echte
// ticketpagina's. De URL is geen optie: die bevat soms meerdere tickets.
// Niets gevonden = null, en dan wordt er niet verzonden.
const LN_TICKET_IN_TITLE = /\bTicket\s*-\s*(T\d{8}\.\d{4})\b/;
const LN_TICKET_HEADER   = /^Ticket\s*-\s*(T\d{8}\.\d{4})\b/;

function currentTicketNumber() {
  const fromTitle = (doc) => {
    try { return (doc && doc.title || "").match(LN_TICKET_IN_TITLE)?.[1] || null; }
    catch (e) { return null; }
  };
  // Eigen frame eerst; vanuit een iframe de titel van het hoofdvenster.
  let nr = fromTitle(document);
  if (!nr) { try { nr = fromTitle(window.top.document); } catch (e) {} }
  if (nr) return nr;
  // Terugval: de kopbalk van het ticket, die dezelfde tekst toont.
  for (const el of document.querySelectorAll("h1, h2, div, span")) {
    const txt = (el.textContent || "").trim();
    if (txt.length > 300) continue;
    const m = txt.match(LN_TICKET_HEADER);
    if (m) return m[1];
  }
  return null;
}

// --- Waar het document terechtkomt ---
// Statische teksten (geen invoer van de pagina), dus veilig in innerHTML/textContent.
const LN_ITGLUE_DEST_HINT = {
  klant: "Het document komt bij de klant van dit ticket (Autotask → ITGlue). Klopt dit ticketnummer niet, verstuur dan niet.",
  lime:  "Het document komt bij Lime Networks zelf, als algemene kennis. Laat klantnamen, hostnamen, IP-adressen en " +
         "gebruikersnamen weg. Klik zo nodig opnieuw op AI-voorstel voor een algemene versie."
};

function _lnSelectedDest(modal) {
  const v = modal.querySelector('input[name="ln-itglue-dest"]:checked')?.value;
  return v === "lime" ? "lime" : "klant";
}

// --- Alleen een link naar ITGlue zelf tonen ---
function _lnIsItglueUrl(url) {
  try {
    const u = new URL(url);
    return u.protocol === "https:" && (u.hostname === "itglue.com" || u.hostname.endsWith(".itglue.com"));
  } catch (e) { return false; }
}

// --- Sensitivity-status renderen in de modal ---
function _lnRenderSensitivityStatus(modal, text) {
  const box = modal.querySelector("#ln-itglue-sensitivity");
  const sendBtn = modal.querySelector("#ln-itglue-send");
  const hits = detectSensitiveData(text);
  if (hits.length === 0) {
    box.style.display = "none";
    box.innerHTML = "";
    sendBtn.dataset.blockedSensitive = "";
  } else {
    const lines = hits.map(h => `regel ${h.line} (${esc(h.type)})`).join(", ");
    box.style.display = "block";
    box.innerHTML = `🚫 Mogelijk gevoelige data gevonden: ${esc(lines)}. Verwijder dit eerst — dit blokkeert verzenden.`;
    sendBtn.dataset.blockedSensitive = "1";
  }
  _lnUpdateSendState(modal);
}

// --- Verzendknop enable/disable op basis van alle voorwaarden samen ---
function _lnUpdateSendState(modal) {
  const sendBtn  = modal.querySelector("#ln-itglue-send");
  const title    = modal.querySelector("#ln-itglue-title").value.trim();
  const content  = modal.querySelector("#ln-itglue-content").value.trim();
  const blocked  = sendBtn.dataset.blockedSensitive === "1";
  const noAuth   = sendBtn.dataset.noAuth === "1";
  const noTicket = sendBtn.dataset.noTicket === "1";
  sendBtn.disabled = blocked || noAuth || noTicket || !title || !content;
  sendBtn.style.opacity = sendBtn.disabled ? "0.5" : "1";
}

// --- Resultaat of fout blijvend in de modal tonen (een toast is na 3,5s weg) ---
function _lnShowResult(modal, ok, text, url) {
  const el = modal.querySelector("#ln-itglue-result");
  el.style.display = "block";
  el.style.color = ok ? "#84cc16" : "#fca5a5";
  el.textContent = "";
  const line = document.createElement("div");
  line.textContent = text;
  el.appendChild(line);
  if (ok && url && _lnIsItglueUrl(url)) {
    const link = document.createElement("a");
    link.href = url;
    link.target = "_blank";
    link.rel = "noopener noreferrer";
    link.style.cssText = "color:#84cc16;font-size:12px;text-decoration:none;";
    link.textContent = "🔗 Openen in ITGlue";
    el.appendChild(link);
  }
}

// --- ITGlue modal tonen ---
async function showITGlueModal() {
  document.getElementById("ln-itglue-modal")?.remove();

  const ticketNr = currentTicketNumber();
  const { ticketTitle, existingNotes, ticketDescription } = getTicketContext();
  const hasEntries = existingNotes.length > 0;

  const itglueSettings = await loadItglueSettings();
  const authConfigured = !!(itglueSettings.webhookUrl && itglueSettings.token);

  const overlay = document.createElement("div");
  overlay.id = "ln-itglue-modal";
  Object.assign(overlay.style, {
    position: "fixed", inset: "0", zIndex: "99999999",
    background: "rgba(0,0,0,0.65)", display: "flex",
    alignItems: "center", justifyContent: "center",
    fontFamily: "Segoe UI, system-ui, sans-serif"
  });

  const modal = document.createElement("div");
  Object.assign(modal.style, {
    background: "#1a2233", border: "1.5px solid #84cc16",
    borderRadius: "12px", width: "560px", maxWidth: "calc(100vw - 40px)",
    maxHeight: "calc(100vh - 40px)", overflow: "hidden",
    display: "flex", flexDirection: "column",
    boxShadow: "0 8px 40px rgba(0,0,0,0.6)"
  });

  const safeTitle = esc(ticketTitle || "");

  const authWarning = authConfigured ? "" : `
    <div style="background:#3a1f1f;border:1px solid #ef4444;border-radius:6px;padding:10px 12px;font-size:12px;color:#fca5a5;line-height:1.5;">
      ⚠️ Webhook-URL en/of token niet ingesteld. Stel dit eerst in via <strong>⚙️ Instellingen</strong> —
      zonder token blijft verzenden uitgeschakeld.
    </div>`;

  const ticketBlock = ticketNr
    ? `<div style="background:#0f1620;border:1px solid #2e3a50;border-radius:6px;padding:8px 10px;font-size:12px;color:#9ca3af;line-height:1.5;">
         Ticket <strong style="color:#e5e7eb;">${esc(ticketNr)}</strong>.
         <span id="ln-itglue-dest-hint">${LN_ITGLUE_DEST_HINT.klant}</span>
       </div>`
    : `<div style="background:#3a1f1f;border:1px solid #ef4444;border-radius:6px;padding:10px 12px;font-size:12px;color:#fca5a5;line-height:1.5;">
         ⚠️ Geen ticketnummer gevonden op deze pagina. Open het ticket zelf en probeer het daar opnieuw.
       </div>`;

  const radioStyle = "display:flex;align-items:center;gap:6px;font-size:13px;color:#e5e7eb;cursor:pointer;";
  const destBlock = `
      <div>
        <label style="font-size:11px;font-weight:700;color:#84cc16;text-transform:uppercase;letter-spacing:0.5px;display:block;margin-bottom:5px;">Vastleggen bij</label>
        <div style="display:flex;gap:18px;flex-wrap:wrap;">
          <label style="${radioStyle}"><input type="radio" name="ln-itglue-dest" value="klant" checked style="accent-color:#84cc16;margin:0;"> Klant van dit ticket</label>
          <label style="${radioStyle}"><input type="radio" name="ln-itglue-dest" value="lime" style="accent-color:#84cc16;margin:0;"> Lime Networks (algemene kennis)</label>
        </div>
      </div>`;

  modal.innerHTML = `
    <div style="display:flex;align-items:center;justify-content:space-between;padding:16px 20px;border-bottom:1px solid #2e3a50;flex-shrink:0;">
      <span style="font-size:15px;font-weight:700;color:#e5e7eb;">&#x1F4DA; Documenteren in ITGlue</span>
      <span id="ln-itglue-close" style="cursor:pointer;font-size:22px;color:#6b7280;line-height:1;padding:2px 6px;">&times;</span>
    </div>
    <div style="overflow-y:auto;padding:16px 20px;display:flex;flex-direction:column;gap:14px;">
      ${authWarning}
      ${destBlock}
      ${ticketBlock}
      <div>
        <label style="font-size:11px;font-weight:700;color:#84cc16;text-transform:uppercase;letter-spacing:0.5px;display:block;margin-bottom:5px;">Type</label>
        <select id="ln-itglue-type"
          style="width:100%;box-sizing:border-box;background:#252d3d;border:1px solid #3d4e6b;border-radius:6px;
          padding:8px 10px;color:#e5e7eb;font-size:13px;outline:none;font-family:Segoe UI,system-ui,sans-serif;">
          ${LN_ITGLUE_CATEGORIES.map(c => `<option value="${esc(c.value)}">${esc(c.label)}</option>`).join("")}
        </select>
      </div>
      <div>
        <label style="font-size:11px;font-weight:700;color:#84cc16;text-transform:uppercase;letter-spacing:0.5px;display:block;margin-bottom:5px;">Titel *</label>
        <input id="ln-itglue-title" type="text" value="${safeTitle}"
          style="width:100%;box-sizing:border-box;background:#252d3d;border:1px solid #3d4e6b;border-radius:6px;
          padding:8px 10px;color:#e5e7eb;font-size:13px;outline:none;font-family:Segoe UI,system-ui,sans-serif;" />
      </div>
      <div>
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:5px;">
          <label style="font-size:11px;font-weight:700;color:#84cc16;text-transform:uppercase;letter-spacing:0.5px;">Inhoud * <span style="color:#4b5563;font-weight:400;text-transform:none;">(altijd bewerkbaar vóór verzenden)</span></label>
          <button id="ln-itglue-generate" style="background:#252d3d;border:1px solid #3d4e6b;border-radius:6px;padding:4px 10px;color:#84cc16;font-size:11px;font-weight:700;cursor:pointer;">&#x2728; AI-voorstel</button>
        </div>
        <textarea id="ln-itglue-content" placeholder="Beschrijf het probleem en de oplossing, of klik op AI-voorstel..."
          style="width:100%;box-sizing:border-box;background:#252d3d;border:1px solid #3d4e6b;border-radius:6px;
          padding:8px 10px;color:#e5e7eb;font-size:13px;line-height:1.6;resize:vertical;min-height:160px;
          outline:none;font-family:Segoe UI,system-ui,sans-serif;"></textarea>
        <div id="ln-itglue-sensitivity" style="display:none;margin-top:6px;background:#3a1f1f;border:1px solid #ef4444;border-radius:6px;padding:8px 10px;font-size:11px;color:#fca5a5;line-height:1.5;"></div>
      </div>
      <div style="display:flex;gap:8px;justify-content:flex-end;">
        <button id="ln-itglue-cancel" style="background:#252d3d;border:1px solid #3d4e6b;border-radius:6px;padding:9px 16px;color:#e5e7eb;font-size:13px;font-weight:700;cursor:pointer;">Annuleren</button>
        <button id="ln-itglue-send" disabled style="background:#84cc16;border:none;border-radius:6px;padding:9px 20px;color:#0f1117;font-size:13px;font-weight:700;cursor:pointer;opacity:0.5;">&#x1F4DA; Verzenden naar ITGlue</button>
      </div>
      <div id="ln-itglue-result" style="display:none;font-size:12px;line-height:1.5;"></div>
    </div>
  `;

  overlay.appendChild(modal);
  document.body.appendChild(overlay);

  const sendBtn = modal.querySelector("#ln-itglue-send");
  sendBtn.dataset.noAuth   = authConfigured ? "" : "1";
  sendBtn.dataset.noTicket = ticketNr ? "" : "1";
  const updateSendState = () => _lnUpdateSendState(modal);

  modal.querySelector("#ln-itglue-title").addEventListener("input", updateSendState);
  modal.querySelector("#ln-itglue-content").addEventListener("input", (e) => {
    _lnRenderSensitivityStatus(modal, e.target.value);
  });
  modal.querySelectorAll('input[name="ln-itglue-dest"]').forEach(r => r.addEventListener("change", () => {
    const hint = modal.querySelector("#ln-itglue-dest-hint");
    if (hint) hint.textContent = LN_ITGLUE_DEST_HINT[_lnSelectedDest(modal)];
  }));

  modal.querySelector("#ln-itglue-close").addEventListener("click", () => overlay.remove());
  modal.querySelector("#ln-itglue-cancel").addEventListener("click", () => overlay.remove());
  overlay.addEventListener("click", (e) => { if (e.target === overlay) overlay.remove(); });

  // AI-voorstel genereren
  modal.querySelector("#ln-itglue-generate").addEventListener("click", async () => {
    const genBtn = modal.querySelector("#ln-itglue-generate");
    const contentArea = modal.querySelector("#ln-itglue-content");
    if (!hasEntries && !ticketDescription) {
      showToast("⚠️ Geen time entries of beschrijving gevonden om van uit te gaan.", "warning");
      return;
    }
    genBtn.textContent = "⏳ Bezig...";
    genBtn.disabled = true;
    try {
      const sourceText = hasEntries ? existingNotes.map(n => n.text).join("\n") : ticketDescription;
      const entryLines = hasEntries
        ? existingNotes.map(n => `- [${n.ts || "geen datum"}] ${n.text}`).join("\n")
        : "";
      const raw = hasEntries
        ? `Ticket title: ${ticketTitle}\n\nTime entry notes:\n${entryLines}` +
          (ticketDescription ? `\n\nOriginal problem (ticket description):\n${ticketDescription}` : "")
        : `Ticket title: ${ticketTitle}\n\nTicket description:\n${ticketDescription}`;
      const settings = await loadSettings();
      const lang = await resolveOutputLang(sourceText, settings);
      const draft = await callAIForITGlueDoc(wrapUntrusted(raw), lang, _lnSelectedDest(modal) === "lime");
      contentArea.value = draft.trim();
      _lnRenderSensitivityStatus(modal, contentArea.value);
    } catch(e) {
      showToast("❌ AI-voorstel mislukt: " + e.message, "error");
    } finally {
      genBtn.textContent = "✨ AI-voorstel";
      genBtn.disabled = false;
    }
  });

  // Verzenden
  sendBtn.addEventListener("click", async () => {
    // Laatste check vlak voor verzenden — defense-in-depth naast de live check,
    // voor het geval de knop-state om wat voor reden dan ook niet is bijgewerkt.
    const contentVal = modal.querySelector("#ln-itglue-content").value.trim();
    if (detectSensitiveData(contentVal).length > 0) {
      showToast("🚫 Verzenden geblokkeerd — mogelijk gevoelige data in de inhoud.", "error");
      return;
    }
    if (!ticketNr) return;
    const settings = await loadItglueSettings();
    // Een engineer die "Bearer <token>" plakt zou anders "Bearer Bearer ..." sturen.
    const token = String(settings.token || "").replace(/^\s*Bearer\s+/i, "").trim();
    if (!settings.webhookUrl || !token) {
      showToast("⚠️ Webhook-URL of token ontbreekt — stel dit in via ⚙️ Instellingen.", "warning");
      return;
    }
    if (!/^https:\/\//i.test(settings.webhookUrl)) {
      _lnShowResult(modal, false, "De webhook-URL moet met https:// beginnen. Het token wordt niet over een onversleutelde verbinding verstuurd.");
      return;
    }
    const typeVal  = modal.querySelector("#ln-itglue-type").value;
    const titleVal = modal.querySelector("#ln-itglue-title").value.trim();
    if (!titleVal || !contentVal) return;

    sendBtn.textContent = "⏳ Bezig...";
    sendBtn.disabled = true;
    try {
      const payload = {
        ticket_number: ticketNr,
        destination:   _lnSelectedDest(modal),
        asset_type:    typeVal,
        title:         titleVal,
        content:       contentVal,
        tags:          [`ticket:${ticketNr}`, typeVal]
      };
      const res = await fetch(settings.webhookUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json", "Authorization": `Bearer ${token}` },
        body: JSON.stringify(payload)
      });
      if (!res.ok) {
        let msg = "";
        try { msg = (await res.json()).error || ""; } catch (e) {}
        if (res.status === 403) msg = "Het webhook-token klopt niet. Controleer het token in ⚙️ Instellingen.";
        if (res.status === 404) msg = msg || "Webhook niet gevonden. Klopt de URL, en staat de N8N-workflow aan?";
        throw new Error(msg || `Webhook HTTP ${res.status}`);
      }
      const data = await res.json().catch(() => ({}));
      if (data.error) throw new Error(data.error);
      // Een lege 200 betekent dat de flow is gestopt zonder te bevestigen. Dan
      // weten we niet of er iets is aangemaakt, dus geen succes melden.
      if (!data.itglue_id) {
        throw new Error("Geen bevestiging van ITGlue ontvangen. Controleer in ITGlue of het document bestaat voordat je opnieuw verstuurt.");
      }

      const waar = data.organization ? ` bij ${data.organization}` : "";
      _lnShowResult(modal, true, `✅ Gedocumenteerd in ITGlue${waar}.`, data.itglue_url);
      showToast("📚 Gedocumenteerd in ITGlue!", "success");
      sendBtn.textContent = "✅ Verzonden";
    } catch(e) {
      _lnShowResult(modal, false, "❌ " + e.message);
      showToast("❌ Verzenden mislukt", "error");
      sendBtn.textContent = "📚 Verzenden naar ITGlue";
      updateSendState();
    }
  });

  updateSendState();
  setTimeout(() => modal.querySelector("#ln-itglue-content")?.focus(), 100);
}
