// ============================================================
// Lime Networks — content.db.js  (v1.2)
// Lokale oplossingsdatabase — anoniem, versleuteld, compact
// Max 1500 records · AES-256-GCM · geen privacygevoelige data
// Slaat op: titel, description (anoniem), ticketnummer (hash)
// ============================================================

const DB_KEY        = "ln_solution_db";
const DB_MAX        = 1500;   // max aantal opgeslagen patronen
const DB_TTL_DAYS   = 365;   // records ouder dan 1 jaar vervallen
const MATCH_THRESH  = 0.30;  // minimale similarity score voor een match

// --- Privacyfilter: verwijder namen, IPs, emails, telefoonnummers ---
function anonymize(text) {
  if (!text) return "";
  return text
    .replace(/\b[A-Z][a-z]+ [A-Z][a-z]+\b/g, "[persoon]")          // Voor- en achternaam
    .replace(/\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/g, "[ip]")    // IPv4
    .replace(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-z]{2,}/g, "[email]") // e-mailadressen
    .replace(/\b\+?[\d\s\-().]{7,15}\b/g, "[tel]")                  // Telefoonnummers
    .replace(/\b(de heer|mevrouw|dhr\.|mevr\.)\s+[A-Z][a-z]+\b/gi, "[persoon]") // Aanhef + naam
    .replace(/\b[A-Z]{2,}\d{4,}\b/g, "[ref]")                       // Ticket/order refs
    .trim();
}

// --- Ticketnummer hashen (T20260311.0027 → korte hash, niet traceerbaar) ---
function hashTicketNr(ticketNr) {
  if (!ticketNr) return null;
  // Verwijder prefix T + datum, houd alleen volgnummer, hash het
  const clean = ticketNr.replace(/[^0-9]/g, "");
  let h = 0;
  for (let i = 0; i < clean.length; i++) {
    h = (Math.imul(31, h) + clean.charCodeAt(i)) | 0;
  }
  return Math.abs(h).toString(36); // bijv. "3kx9m" — niet herleidbaar
}

// --- Tekst normaliseren voor vergelijking ---
function normalize(text) {
  return text.toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

// --- Eenvoudige keyword extractie (geen stopwoorden) ---
const STOP_NL = new Set(["de","het","een","van","in","op","met","voor","aan","bij","door","is","was","er","dat","dit","die","dan","maar","ook","naar","uit","over","als","om","nog","al","wel","niet","zo","we","ze","ik","je","hij","zij","hun","ons","onze","heb","had","heeft","hebben","worden","werd","worden","kan","kon","moet","mocht","zou","zal","zijn"]);
const STOP_EN = new Set(["the","a","an","of","in","on","with","for","at","by","from","to","and","or","but","is","was","it","that","this","they","we","i","you","he","she","its","be","been","have","has","had","do","did","not","no","can","could","will","would","should","may","might","there","their","them","then","than"]);

function extractKeywords(text) {
  const words = normalize(text).split(" ").filter(w => w.length > 2);
  return words.filter(w => !STOP_NL.has(w) && !STOP_EN.has(w));
}

// --- Jaccard similarity tussen twee keyword-sets ---
function similarity(kw1, kw2) {
  if (!kw1.length || !kw2.length) return 0;
  const s1 = new Set(kw1);
  const s2 = new Set(kw2);
  const intersection = [...s1].filter(w => s2.has(w)).length;
  const union = new Set([...s1, ...s2]).size;
  return union === 0 ? 0 : intersection / union;
}

// --- Versleuteling (hergebruik van zelfde methode als crypto.js) ---
async function dbGetKey() {
  const raw = chrome.runtime.id + "-lime-networks-encryption-key";
  return crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(raw.padEnd(32,"0").substring(0,32)),
    { name: "AES-GCM" }, false, ["encrypt","decrypt"]
  );
}

async function dbEncrypt(obj) {
  const key = await dbGetKey();
  const iv  = crypto.getRandomValues(new Uint8Array(12));
  const enc = await crypto.subtle.encrypt(
    { name:"AES-GCM", iv }, key,
    new TextEncoder().encode(JSON.stringify(obj))
  );
  const combined = new Uint8Array(iv.byteLength + enc.byteLength);
  combined.set(iv); combined.set(new Uint8Array(enc), 12);
  // Gebruik loop i.p.v. spread (...combined) om stack overflow te voorkomen bij grote DB
  let b64 = "";
  combined.forEach(b => { b64 += String.fromCharCode(b); });
  return btoa(b64);
}

async function dbDecrypt(cipher) {
  if (!cipher) return [];
  try {
    const key      = await dbGetKey();
    const combined = Uint8Array.from(atob(cipher), c => c.charCodeAt(0));
    const dec      = await crypto.subtle.decrypt(
      { name:"AES-GCM", iv: combined.slice(0,12) }, key, combined.slice(12)
    );
    return JSON.parse(new TextDecoder().decode(dec));
  } catch { return []; }
}

// --- Database laden en opslaan ---
async function dbLoad() {
  return new Promise(resolve => {
    chrome.storage.local.get([DB_KEY], async r => {
      resolve(await dbDecrypt(r[DB_KEY] || ""));
    });
  });
}

async function dbSave(records) {
  const cipher = await dbEncrypt(records);
  return new Promise(resolve => {
    chrome.storage.local.set({ [DB_KEY]: cipher }, resolve);
  });
}

// --- Database opruimen: verwijder oud + zelden gebruikt bij overschrijding ---
function dbTrim(records) {
  const cutoff = Date.now() - DB_TTL_DAYS * 86400000;
  // Verwijder verlopen records
  let trimmed = records.filter(r => new Date(r.last).getTime() > cutoff);
  // Als nog steeds te veel: verwijder laagste score (hits × recentheid)
  if (trimmed.length > DB_MAX) {
    trimmed.sort((a,b) => {
      const scoreA = a.hits * (new Date(a.last).getTime() / 1e12);
      const scoreB = b.hits * (new Date(b.last).getTime() / 1e12);
      return scoreA - scoreB;
    });
    trimmed = trimmed.slice(trimmed.length - DB_MAX);
  }
  return trimmed;
}

// --- Categorie bepalen op basis van keywords ---
function detectCategory(keywords) {
  const cats = {
    email:    ["outlook","mail","exchange","smtp","imap","autodiscover","mailbox","email"],
    netwerk:  ["netwerk","network","vpn","wifi","dns","dhcp","ip","internet","verbinding","ping","firewall","switch","router"],
    account:  ["account","wachtwoord","password","login","mfa","2fa","authenticator","sso","active directory","ad","azure","entra"],
    hardware: ["laptop","computer","pc","printer","monitor","scherm","toetsenbord","muis","hardware","geheugen","ram","ssd","hdd"],
    software: ["installatie","install","update","licentie","license","teams","office","windows","applicatie","app","software","crash"],
    telefoon: ["telefoon","phone","mobiel","mobile","teams","voip","softphone","headset"],
    server:   ["server","rdp","remote","hyper-v","vm","virtueel","backup","back-up","raid","storage"],
    overig:   []
  };
  for (const [cat, terms] of Object.entries(cats)) {
    if (keywords.some(kw => terms.includes(kw))) return cat;
  }
  return "overig";
}

// --- AI: patroon extraheren uit gepolijste tekst ---
async function extractPattern(polishedText) {
  const s = await loadSettings();
  // Vereist minimaal één geconfigureerde sleutel
  if (!s.claudeKey && !s.openaiKey) return null;

  const sysPrompt = `You are a data extraction assistant for an MSP helpdesk database.
Extract a SHORT, ANONYMOUS problem-solution pattern from this time entry.
Respond ONLY with valid JSON in this exact format:
{"prob":"<problem in max 8 words>","sol":"<solution in max 8 words>"}
Rules:
- NO names, company names, IP addresses, emails, or phone numbers
- Use generic terms: 'user', 'client', 'device', 'server'
- Be specific enough to be useful but generic enough to match similar cases
- Dutch input → Dutch output, English input → English output`;

  try {
    const raw    = await _callProvider(s, sysPrompt, polishedText, 80);
    const parsed = JSON.parse(raw.replace(/```json|```/g, "").trim());
    if (parsed.prob && parsed.sol) return parsed;
  } catch { /* silent fail — niet kritisch */ }
  return null;
}

// --- Publieke API ---

// Sla een nieuwe oplossing op na succesvolle polish
// ticketMeta = { title, description, ticketNr } — allemaal optioneel
async function dbSaveEntry(originalText, polishedText, ticketMeta = {}) {
  try {
    const pattern = await extractPattern(polishedText);
    if (!pattern) return;

    const anonProb  = anonymize(pattern.prob);
    const anonSol   = anonymize(pattern.sol);
    const anonTitle = ticketMeta.title       ? anonymize(ticketMeta.title)       : null;
    const anonDesc  = ticketMeta.description ? anonymize(ticketMeta.description).substring(0, 200) : null;
    const ticketRef = hashTicketNr(ticketMeta.ticketNr || null);

    // Keywords bouwen uit alle beschikbare bronnen (titel + description verrijken de match)
    const allText  = [anonProb, anonSol, anonTitle, anonDesc].filter(Boolean).join(" ");
    const keywords = extractKeywords(allText);
    const category = detectCategory(keywords);
    const today    = new Date().toISOString().slice(0,10);

    const records = await dbLoad();

    // Deduplicatie: zelfde ticket of 70%+ keyword overlap
    const existing = records.find(r =>
      (ticketRef && r.ref === ticketRef) ||
      similarity(keywords, r.kw) > 0.7
    );

    if (existing) {
      existing.hits++;
      existing.last = today;
      // Verrijk bestaand record met titel/desc als die er nog niet in zaten
      if (anonTitle && !existing.title) existing.title = anonTitle;
      if (anonDesc  && !existing.desc)  existing.desc  = anonDesc;
    } else {
      const record = {
        id:   Math.random().toString(36).slice(2,9),
        cat:  category,
        kw:   keywords,
        prob: anonProb,
        sol:  anonSol,
        hits: 1,
        last: today
      };
      if (anonTitle) record.title = anonTitle;
      if (anonDesc)  record.desc  = anonDesc;
      if (ticketRef) record.ref   = ticketRef;
      records.push(record);
    }

    await dbSave(dbTrim(records));
  } catch { /* silent — nooit crashen op DB operaties */ }
}

// Zoek matches voor een stuk tekst + optionele ticketcontext
async function dbFindMatches(text, ticketMeta = {}, maxResults = 3) {
  try {
    const records  = await dbLoad();
    if (!records.length) return [];

    // Combineer zoektekst met titel + description voor rijkere matching
    const allText  = [text, ticketMeta.title, ticketMeta.description]
      .filter(Boolean).join(" ");
    const keywords = extractKeywords(anonymize(allText));
    if (!keywords.length) return [];

    return records
      .map(r => ({ ...r, score: similarity(keywords, r.kw) }))
      .filter(r => r.score >= MATCH_THRESH)
      .sort((a,b) => (b.score * b.hits) - (a.score * a.hits))
      .slice(0, maxResults);
  } catch { return []; }
}

// Database statistieken (voor popup)
async function dbGetStats() {
  try {
    const records = await dbLoad();
    const cats    = {};
    records.forEach(r => { cats[r.cat] = (cats[r.cat] || 0) + 1; });
    const topCat  = Object.entries(cats).sort((a,b)=>b[1]-a[1])[0];
    return {
      total:  records.length,
      cats,
      topCat: topCat ? topCat[0] : null,
      oldest: records.reduce((min,r) => r.last < min ? r.last : min, "9999"),
      newest: records.reduce((max,r) => r.last > max ? r.last : max, "0000")
    };
  } catch { return { total:0, cats:{}, topCat:null }; }
}

// Database wissen (voor instellingen)
async function dbClear() {
  return new Promise(resolve => {
    chrome.storage.local.remove([DB_KEY], resolve);
  });
}