#!/bin/bash
# ============================================================
# Lime Networks - ATEA Native Messaging Host (macOS)
# Tegenhanger van atea-host.ps1
# ============================================================
#
# Chrome/Edge starten dit script en spreken het stdio-protocol:
# een 4-byte lengte-prefix in host byte order (little-endian op zowel Intel als
# Apple Silicon), gevolgd door het JSON-bericht. Het antwoord moet in exact
# hetzelfde formaat terug over stdout.
#
# BELANGRIJK: op stdout mag NIETS anders terechtkomen dan lengte-prefix + JSON.
# Eén losse echo corrumpeert het bericht en de extensie ziet dan geen antwoord.
# Alle diagnostiek gaat daarom naar het logbestand.
#
# Op macOS bestaat er geen registry: de LOCATIE van het host-manifest is de
# registratie. install-mac.command zet dat manifest neer.

set -u

INSTALL_DIR="$HOME/Library/Application Support/LimeNetworks/ATEA"
STAGING_DIR="$HOME/Library/Application Support/LimeNetworks/.atea-staging"
LOG_FILE="$INSTALL_DIR/atea-host.log"
ZIP_URL="https://raw.githubusercontent.com/Lime-Networks/atea-releases/main/extension.zip"
HASH_URL="https://raw.githubusercontent.com/Lime-Networks/atea-releases/main/extension.sha256"

mkdir -p "$INSTALL_DIR" 2>/dev/null

log() {
  # Nieuwe regels strippen en afkappen, zodat een fout het log niet kan vervuilen.
  printf '[%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" \
    "$(printf '%s' "$*" | tr -d '\r\n' | cut -c1-500)" >> "$LOG_FILE" 2>/dev/null
}

json_escape() {
  # Alleen tab en printbare ASCII houden, daarna backslash en quote escapen.
  # Voorkomt kapotte JSON door onverwachte tekens in een foutmelding.
  printf '%s' "$1" | tr -d '\r\n' | LC_ALL=C tr -cd '\11\40-\176' | sed 's/\\/\\\\/g; s/"/\\"/g'
}

send_response() {
  local json="$1" n
  # Byte-lengte, niet tekens: ${#json} zou bij non-ASCII verkeerd tellen.
  n=$(printf '%s' "$json" | wc -c | tr -d ' ')
  printf '%b' "$(printf '\\x%02x\\x%02x\\x%02x\\x%02x' \
    $(( n         & 0xFF )) \
    $(( (n >> 8)  & 0xFF )) \
    $(( (n >> 16) & 0xFF )) \
    $(( (n >> 24) & 0xFF )))"
  printf '%s' "$json"
}

fail() {
  log "FOUT: $1"
  send_response "{\"success\":false,\"error\":\"$(json_escape "$1")\"}"
  exit 0
}

read_version() {
  sed -n 's/.*"version"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' "$1" 2>/dev/null | head -1
}

# --- Bericht lezen ---------------------------------------------------------
# dd met bs=1 count=4 leest exact 4 bytes. head -c zou vooruit kunnen bufferen
# en dan is de rest van het bericht weg.
LEN=$(dd bs=1 count=4 2>/dev/null | od -An -tu4 | tr -d ' \n')

if ! printf '%s' "${LEN:-}" | grep -Eq '^[0-9]+$' || [ "$LEN" -eq 0 ] || [ "$LEN" -gt 1048576 ]; then
  # Geen bruikbaar bericht: niets terugsturen, Chrome ziet een lege stream.
  log "Ongeldige lengte-prefix ontvangen: '${LEN:-leeg}'"
  exit 1
fi

MSG=$(dd bs=1 count="$LEN" 2>/dev/null)

# Alleen [a-zA-Z_-] toestaan; de waarde wordt uitsluitend met = vergeleken.
ACTION=$(printf '%s' "$MSG" | sed -n 's/.*"action"[[:space:]]*:[[:space:]]*"\([a-zA-Z_-]*\)".*/\1/p')

log "Host gestart, actie: ${ACTION:-onbekend}"

case "${ACTION:-}" in
  ping)
    log "Ping ontvangen"
    send_response '{"success":true,"status":"ok"}'
    exit 0
    ;;

  update)
    rm -rf "$STAGING_DIR" 2>/dev/null
    mkdir -p "$STAGING_DIR/extract" || fail "Kan staging-map niet aanmaken."
    TMP_ZIP="$STAGING_DIR/extension.zip"

    log "Downloaden van $ZIP_URL"
    curl -fsSL --max-time 120 -o "$TMP_ZIP" "$ZIP_URL" \
      || fail "Download mislukt - controleer de internetverbinding."
    log "Download klaar"

    # Integriteitscontrole. LET OP: de hash komt van dezelfde host als de zip,
    # dus dit beschermt tegen een corrupte download, niet tegen een gecompromitteerd
    # releases-kanaal (zie F1/F3 in de security review).
    log "SHA-256 ophalen van $HASH_URL"
    EXPECTED=$(curl -fsSL --max-time 30 "$HASH_URL" | tr -d ' \r\n' | tr 'A-F' 'a-f') \
      || fail "Kan de verwachte hash niet ophalen."
    printf '%s' "$EXPECTED" | grep -Eq '^[0-9a-f]{64}$' \
      || fail "Ongeldige hash ontvangen - update afgebroken."

    ACTUAL=$(shasum -a 256 "$TMP_ZIP" | awk '{print $1}')
    if [ "$ACTUAL" != "$EXPECTED" ]; then
      rm -f "$TMP_ZIP"
      fail "SHA-256 mismatch! Verwacht: $EXPECTED / Werkelijk: $ACTUAL - update afgebroken."
    fi
    log "SHA-256 geverifieerd: $ACTUAL"

    unzip -o -q "$TMP_ZIP" -d "$STAGING_DIR/extract" || fail "Uitpakken mislukt."
    log "Uitgepakt"

    SRC="$STAGING_DIR/extract"
    if [ ! -f "$SRC/manifest.json" ]; then
      # Een GitHub source-zip heeft één submap; extension.zip heeft de bestanden in de root.
      SUB=$(find "$SRC" -mindepth 1 -maxdepth 1 -type d 2>/dev/null | head -1)
      if [ -n "$SUB" ] && [ -f "$SUB/manifest.json" ]; then SRC="$SUB"; fi
    fi
    [ -f "$SRC/manifest.json" ] || fail "Uitgepakte map bevat geen manifest.json - onverwachte zip-inhoud."

    NEW_VERSION=$(read_version "$SRC/manifest.json")
    [ -n "$NEW_VERSION" ] || fail "Kan de versie niet uit manifest.json lezen."
    log "Installeren van v$NEW_VERSION"

    # Installeren met mv, niet cp. Dit script kan zichzelf overschrijven, en een
    # rename vervangt alleen de directory-entry: de draaiende bash blijft de oude
    # inode lezen. Met cp verandert de inhoud onder de interpreter vandaan en
    # voert bash halverwege nieuwe bytes uit.
    # Staging staat bewust onder dezelfde map als de installatie, zodat mv een
    # rename is en geen copy+delete over een filesystem-grens.
    for f in "$SRC"/*; do
      [ -e "$f" ] || continue
      base=$(basename "$f")
      mv -f "$f" "$INSTALL_DIR/$base" || fail "Kan $base niet plaatsen."
    done

    # Host uit de nieuwe release moet uitvoerbaar blijven.
    [ -f "$INSTALL_DIR/atea-host.sh" ] && chmod +x "$INSTALL_DIR/atea-host.sh"
    [ -f "$INSTALL_DIR/install-mac.command" ] && chmod +x "$INSTALL_DIR/install-mac.command"

    INSTALLED=$(read_version "$INSTALL_DIR/manifest.json")
    if [ "$INSTALLED" != "$NEW_VERSION" ]; then
      fail "Installatie niet doorgevoerd: map staat op v${INSTALLED:-onbekend}, verwacht v$NEW_VERSION."
    fi

    rm -rf "$STAGING_DIR" 2>/dev/null
    log "Update succesvol geinstalleerd: v$INSTALLED"
    send_response '{"success":true}'
    exit 0
    ;;

  *)
    log "Onbekende actie: ${ACTION:-leeg}"
    send_response "{\"success\":false,\"error\":\"Onbekende actie: $(json_escape "${ACTION:-leeg}")\"}"
    exit 0
    ;;
esac
