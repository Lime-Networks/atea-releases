// ============================================================
// Lime Networks — content.observer.js  (v2.2)
// Status observer + message listener + DB integratie
// Match popup ALLEEN bij time entry, lampje in knoppen menu
// ============================================================

// Guard: voorkom dat het script meerdere keren in dezelfde scope laadt
// (Autotask gebruikt iframes waardoor content scripts herhaald worden geladen)
if (typeof window._lnObserverLoaded !== "undefined") {
  // Al geladen — stop hier
} else {
window._lnObserverLoaded = true;

// --- Ticket metadata uitlezen van de Autotask pagina ---
function readTicketMetadata() {
  const meta = { title: null, description: null, ticketNr: null };

  // Ticketnummer (patroon: T20260311.0027)
  document.querySelectorAll("span, div, h1, h2").forEach(el => {
    if (meta.ticketNr) return;
    const txt = el.textContent.trim();
    if (/^T\d{8}\.\d{4}$/.test(txt)) meta.ticketNr = txt;
  });
  if (!meta.ticketNr) {
    const urlMatch = location.href.match(/ids%5B0%5D=(\d+)/);
    if (urlMatch) meta.ticketNr = "ID" + urlMatch[1];
  }

  // Tickettitel
  document.querySelectorAll("div.Title").forEach(el => {
    if (meta.title) return;
    if (!el.parentElement?.className?.includes("Content")) return;
    const txt = el.textContent.trim();
    if (txt.length > 5 && txt.length < 300 && !txt.includes("Ticket -")) {
      meta.title = txt;
    }
  });

  // Description
  document.querySelectorAll("div, span").forEach(el => {
    if (meta.description) return;
    if (el.children.length > 0) return;
    if (el.textContent.trim() !== "Description") return;
    let node = el.nextElementSibling || el.parentElement?.nextElementSibling;
    while (node) {
      const txt = node.textContent.trim();
      if (txt.length > 10 && txt !== "Description") {
        meta.description = txt.substring(0, 300);
        break;
      }
      node = node.nextElementSibling;
    }
  });

  return meta;
}

// --- Cache voor matches van het huidige ticket ---
if (typeof cachedTicketMatches === "undefined") var cachedTicketMatches = [];

// --- Lampje indicator updaten naast de knoppen ---
function updateMatchIndicator(count) {
  const btn = document.getElementById("ln-match-btn");
  if (!btn) return;
  btn.style.display = "inline";
  if (count > 0) {
    btn.style.opacity  = "1";
    btn.style.filter   = "";
    btn.title = `${count} vergelijkbare oplossing${count > 1 ? "en" : ""} gevonden — klik om te bekijken`;
  } else {
    btn.style.opacity  = "0.35";
    btn.style.filter   = "grayscale(1)";
    btn.title = "Geen lokale match — klik voor bekende oplossingen via AI";
  }
}

// --- Basis banner aanmaken (gedeeld door lokale matches en AI-suggesties) ---
function _createBannerBase(title) {
  const existing = document.getElementById("ln-match-banner");
  if (existing) existing.remove();
  const banner = document.createElement("div");
  banner.id = "ln-match-banner";
  Object.assign(banner.style, {
    position: "fixed", bottom: "80px", right: "24px", zIndex: "9999998",
    background: "#083E47", border: "1.5px solid #76B82A",
    borderRadius: "12px", padding: "12px 14px", maxWidth: "340px",
    fontFamily: "Segoe UI, system-ui, sans-serif",
    boxShadow: "0 4px 20px rgba(0,0,0,0.4)", color: "#F7F8F9"
  });
  banner.innerHTML = `
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">
      <span style="font-size:12px;font-weight:700;color:#76B82A;">${title}</span>
      <span id="ln-match-close" style="cursor:pointer;font-size:16px;color:#6D6E72;line-height:1;">×</span>
    </div>
  `;
  return banner;
}

// --- Lokale DB matches tonen ---
function showMatchBanner(matches) {
  const banner = _createBannerBase(`💡 ${matches.length} vergelijkbare oplossing${matches.length > 1 ? "en" : ""} gevonden`);
  const catIcon = { email:"📧", netwerk:"🌐", account:"🔑", hardware:"💻",
                    software:"⚙️", telefoon:"📞", server:"🖥️", overig:"📋" };
  matches.forEach((m, i) => {
    const item = document.createElement("div");
    Object.assign(item.style, {
      background: "#0d4f5c", borderRadius: "8px", padding: "8px 10px",
      marginBottom: i < matches.length - 1 ? "6px" : "0",
      fontSize: "12px", lineHeight: "1.5"
    });
    const pct = Math.round(m.score * 100);
    const titleLine = m.title
      ? `<div style="color:#76B82A;font-size:11px;margin-bottom:3px;font-style:italic;">"${m.title}"</div>`
      : "";
    item.innerHTML = `
      <div style="display:flex;justify-content:space-between;margin-bottom:4px;">
        <span style="color:#76B82A;font-weight:700;">${catIcon[m.cat] || "📋"} ${m.cat}</span>
        <span style="color:#6D6E72;font-size:11px;">${pct}% · ${m.hits}× gebruikt</span>
      </div>
      ${titleLine}
      <div style="color:#9dbfc7;margin-bottom:2px;">🔍 <em>${m.prob}</em></div>
      ${m.sol
        ? `<div style="color:#F7F8F9;">✅ ${m.sol}</div>`
        : `<div style="color:#6D6E72;font-style:italic;">Oplossing nog niet bekend</div>`}
    `;
    banner.appendChild(item);
  });
  document.body.appendChild(banner);
  document.getElementById("ln-match-close").addEventListener("click", () => banner.remove());
  setTimeout(() => { if (banner.isConnected) banner.remove(); }, 15000);
}

// --- AI-suggesties tonen ---
function showAISuggestionBanner(suggestions) {
  const banner = _createBannerBase("🤖 Bekende oplossingen via AI");
  suggestions.forEach((s, i) => {
    const item = document.createElement("div");
    Object.assign(item.style, {
      background: "#0d4f5c", borderRadius: "8px", padding: "8px 10px",
      marginBottom: i < suggestions.length - 1 ? "6px" : "0",
      fontSize: "12px", lineHeight: "1.5", color: "#F7F8F9"
    });
    item.innerHTML = `<span style="color:#00B1EB;margin-right:6px;">→</span>${s}`;
    banner.appendChild(item);
  });
  const note = document.createElement("div");
  note.style.cssText = "font-size:10px;color:#6D6E72;margin-top:8px;";
  note.textContent = "Gebaseerd op AI-kennis — controleer altijd zelf";
  banner.appendChild(note);
  document.body.appendChild(banner);
  document.getElementById("ln-match-close").addEventListener("click", () => banner.remove());
  setTimeout(() => { if (banner.isConnected) banner.remove(); }, 20000);
}

// --- AI-suggesties ophalen en tonen ---
async function showAISuggestions() {
  const meta = readTicketMetadata();
  const problem = [meta.title, meta.description].filter(Boolean).join(" — ");
  if (!problem || problem.length < 5) {
    showToast("⚠️ Onvoldoende ticketcontext om te zoeken", "warning");
    return;
  }
  showToast("🔍 Bekende oplossingen zoeken...", "loading");
  try {
    const suggestions = await callAIForKnownSolutions(problem);
    document.getElementById("ln-toast")?.remove();
    if (suggestions.length > 0) {
      showAISuggestionBanner(suggestions);
    } else {
      showToast("Geen bekende oplossingen gevonden", "info");
    }
  } catch(e) {
    showToast("❌ " + e.message, "error");
  }
}

// --- Message listener ---
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.action === "polishSelection") handlePolish();
});

// --- handlePolish met DB integratie ---
async function handlePolishWithDB() {
  const source = getSelectedText();
  if (!source || !source.text) {
    showToast("⚠️ Geen tekst gevonden. Selecteer tekst of klik in een tekstveld.", "warning");
    return;
  }
  const originalText = source.text;
  const ticketMeta   = readTicketMetadata();
  showToast("⏳ Bezig met polijsten...", "loading");
  try {
    const result = await callAI(originalText);
    const ok = replaceText(source, result);
    if (ok) {
      showToast("✅ Tekst gepolijst!", "success");
      if (_cachedFeatures.oplossing) {
        dbSaveEntry(originalText, result, ticketMeta).catch(() => {});
        // Toon matches NU wel — engineer is actief bezig met time entry
        const matches = cachedTicketMatches.length > 0
          ? cachedTicketMatches
          : await dbFindMatches(originalText, ticketMeta).catch(() => []);
        if (matches.length > 0) showMatchBanner(matches);
      }
    } else {
      await navigator.clipboard.writeText(result);
      showToast("📋 Gekopieerd naar klembord — plak handmatig (Ctrl+V)", "warning");
      if (_cachedFeatures.oplossing) dbSaveEntry(originalText, result, ticketMeta).catch(() => {});
    }
  } catch(e) {
    showToast("❌ Fout: " + e.message, "error");
  }
}

if (typeof window !== "undefined") {
  window.handlePolish = handlePolishWithDB;
}

// --- Lampje knop toevoegen na injectSummaryButton ---
const _origInjectSummaryButton = typeof injectSummaryButton === "function" ? injectSummaryButton : null;

function injectSummaryButtonWithMatch() {
  const result = _origInjectSummaryButton ? _origInjectSummaryButton() : false;
  if (!result) return false;

  if (!_cachedFeatures.oplossing) return result;

  if (!document.getElementById("ln-match-btn")) {
    const labelContainer = document.querySelector("#ln-polish-btn")?.closest(".LabelContainer1");
    if (!labelContainer) return result;

    const matchBtn = document.createElement("span");
    matchBtn.id = "ln-match-btn";
    matchBtn.textContent = "💡";
    matchBtn.style.cssText = "display:inline;cursor:pointer;font-size:14px;user-select:none;margin-left:4px;opacity:0.35;filter:grayscale(1);";
    matchBtn.title = "Geen lokale match — klik voor bekende oplossingen via AI";
    matchBtn.addEventListener("mouseenter", () => { matchBtn.style.opacity = String(parseFloat(matchBtn.style.opacity) + 0.3); });
    matchBtn.addEventListener("mouseleave", () => { updateMatchIndicator(cachedTicketMatches.length); });
    matchBtn.addEventListener("click", async (e) => {
      e.preventDefault(); e.stopPropagation();
      if (cachedTicketMatches.length > 0) showMatchBanner(cachedTicketMatches);
      else await showAISuggestions();
    });
    labelContainer.appendChild(matchBtn);

    // Direct updaten als cache al gevuld is
    if (cachedTicketMatches.length > 0) updateMatchIndicator(cachedTicketMatches.length);
  }
  return result;
}

if (typeof window !== "undefined") {
  window.injectSummaryButton = injectSummaryButtonWithMatch;
}

// --- Stil verzamelen bij openen ticket ---
async function checkMatchesForCurrentTicket() {
  if (!_cachedFeatures.oplossing) return;
  const meta = readTicketMetadata();
  if (!meta.title && !meta.description) return;

  const searchText = [meta.title, meta.description].filter(Boolean).join(" ");
  const matches = await dbFindMatches(searchText, meta).catch(() => []);
  cachedTicketMatches = matches;
  updateMatchIndicator(matches.length); // lampje aan/uit, géén popup

  // Sla ticketcontext op als open entry
  try {
    const allText = [meta.title, meta.description].filter(Boolean).join(" ");
    if (allText.length < 10) return;
    const records   = await dbLoad();
    const ticketRef = hashTicketNr(meta.ticketNr);

    if (ticketRef && records.some(r => r.ref === ticketRef)) return;

    const anonTitle = meta.title       ? anonymize(meta.title)                        : null;
    const anonDesc  = meta.description ? anonymize(meta.description).substring(0,200) : null;
    const keywords  = extractKeywords([anonTitle, anonDesc].filter(Boolean).join(" "));
    if (!keywords.length) return;

    const record = {
      id:   Math.random().toString(36).slice(2,9),
      cat:  detectCategory(keywords),
      kw:   keywords,
      prob: anonTitle || anonDesc || "",
      sol:  "",
      hits: 1,
      last: new Date().toISOString().slice(0,10),
      open: true
    };
    if (anonTitle) record.title = anonTitle;
    if (anonDesc)  record.desc  = anonDesc;
    if (ticketRef) record.ref   = ticketRef;

    records.push(record);
    await dbSave(dbTrim(records));
  } catch { /* silent */ }
}

function startStatusObserver() {
  let alreadyTicked         = false;
  let ticketAlreadyComplete = false;
  let matchCheckedForUrl    = "";
  const completeValues = ["complete", "completed", "resolved"];

  function readTicketStatusFromPage() {
    const allStatuses = [
      "new", "escalate", "resolution plan", "in progress",
      "waiting materials", "waiting customer", "waiting vendor",
      "waiting software", "complete", "completed", "resolved",
      "customer note added"
    ];

    const checkbox = document.querySelector("div.Checkbox2");
    let popupContainer = null;
    if (checkbox) {
      let node = checkbox.parentElement;
      while (node && node !== document.body) {
        const r = node.getBoundingClientRect();
        if (r.width > 500 && r.height > 400) { popupContainer = node; break; }
        node = node.parentElement;
      }
    }

    const allEls = document.querySelectorAll("div, span");
    for (const el of allEls) {
      if (el.children.length > 0) continue;
      if (el.textContent.trim() !== "Status") continue;
      if (popupContainer && popupContainer.contains(el)) continue;

      let sibling = el.nextElementSibling;
      while (sibling) {
        const txt = sibling.textContent.trim().toLowerCase();
        if (allStatuses.includes(txt)) return txt;
        for (const child of sibling.querySelectorAll("*")) {
          const childTxt = child.textContent.trim().toLowerCase();
          if (allStatuses.includes(childTxt)) return childTxt;
        }
        sibling = sibling.nextElementSibling;
      }
      const parentNext = el.parentElement?.nextElementSibling;
      if (parentNext) {
        const txt = parentNext.textContent.trim().toLowerCase();
        if (allStatuses.includes(txt)) return txt;
        for (const child of parentNext.querySelectorAll("*")) {
          const childTxt = child.textContent.trim().toLowerCase();
          if (allStatuses.includes(childTxt)) return childTxt;
        }
      }
    }
    return null;
  }

  setInterval(() => {
    if (!document.getElementById("ln-summary-btn") || !document.getElementById("ln-polish-btn")) {
      injectSummaryButton();
    }
    if (!document.getElementById("ln-toolbar-polish-btn")) {
      injectActivityToolbarButtons();
    }
    const newtixBtn = document.getElementById("ln-newtix-btn");
    if (newtixBtn && !isNewOrEditTicketPage()) {
      newtixBtn.remove();
    } else if (!newtixBtn) {
      injectNewTicketButtons();
    }

    // Check matches 1× per unieke ticket URL — stil, geen popup
    const currentUrl = location.href;
    if (currentUrl !== matchCheckedForUrl) {
      matchCheckedForUrl  = currentUrl;
      cachedTicketMatches = []; // reset cache bij nieuw ticket
      setTimeout(() => checkMatchesForCurrentTicket(), 1500);
    }

    const appendExists = document.querySelector("div.Checkbox2");

    if (!appendExists) {
      alreadyTicked = false;
      const status = readTicketStatusFromPage();
      if (status !== null) ticketAlreadyComplete = completeValues.includes(status);
      return;
    }

    if (alreadyTicked) return;
    if (ticketAlreadyComplete) return;

    let isComplete = false;
    document.querySelectorAll(".TargetPreview").forEach(el => {
      const txt = el.textContent.trim().toLowerCase();
      if (completeValues.includes(txt)) isComplete = true;
    });
    if (!isComplete) return;

    document.querySelectorAll("div.Checkbox2").forEach(el => {
      if (el.textContent.trim().toLowerCase().includes("append summary notes to resolution")) {
        const hack = el.querySelector("div.TabIndexHack");
        if (hack && !hack.classList.contains("Checked") && !alreadyTicked) {
          hack.click();
          showToast("☑️ 'Append to Resolution' automatisch aangevinkt!", "success");
          alreadyTicked = true;
        } else if (hack && hack.classList.contains("Checked")) {
          alreadyTicked = true;
        }
      }
    });
  }, 1000);
}

// --- Start ---
startStatusObserver();
langOverride = null;

} // end _lnObserverLoaded guard