// ============================================================
// Lime Networks — content.observer.js  (v2.2)
// Status observer + message listener + DB integratie
// Match popup ALLEEN bij time entry, lampje in knoppen menu
// ============================================================

// Guard: voorkom dat het script meerdere keren in dezelfde scope laadt
// (Autotask gebruikt iframes waardoor content scripts herhaald worden geladen)
if (typeof window._lnObserverLoaded !== "undefined") {
  // Al geladen — stop hier
} else {
window._lnObserverLoaded = true;

// --- Ticket metadata uitlezen van de Autotask pagina ---
function readTicketMetadata() {
  const meta = { title: null, description: null, ticketNr: null };

  // Ticketnummer (patroon: T20260311.0027)
  document.querySelectorAll("span, div, h1, h2").forEach(el => {
    if (meta.ticketNr) return;
    const txt = el.textContent.trim();
    if (/^T\d{8}\.\d{4}$/.test(txt)) meta.ticketNr = txt;
  });
  if (!meta.ticketNr) {
    const urlMatch = location.href.match(/ids%5B0%5D=(\d+)/);
    if (urlMatch) meta.ticketNr = "ID" + urlMatch[1];
  }

  // Tickettitel
  document.querySelectorAll("div.Title").forEach(el => {
    if (meta.title) return;
    if (!el.parentElement?.className?.includes("Content")) return;
    const txt = el.textContent.trim();
    if (txt.length > 5 && txt.length < 300 && !txt.includes("Ticket -")) {
      meta.title = txt;
    }
  });

  // Description
  document.querySelectorAll("div, span").forEach(el => {
    if (meta.description) return;
    if (el.children.length > 0) return;
    if (el.textContent.trim() !== "Description") return;
    let node = el.nextElementSibling || el.parentElement?.nextElementSibling;
    while (node) {
      const txt = node.textContent.trim();
      if (txt.length > 10 && txt !== "Description") {
        meta.description = txt.substring(0, 300);
        break;
      }
      node = node.nextElementSibling;
    }
  });

  return meta;
}

// --- HTML escaping ---
// Bewust GEEN eigen esc() meer hier. Dit bestand laadt als laatste (zie manifest.json en
// CONTENT_FILES in background.js), en een functiedeclaratie in dit else-blok wordt via
// Annex B naar de globale scope gehesen. Een duplicaat hier overschreef daarmee de
// volledigere esc() uit content.polish.js voor de HELE extensie — die versie escapet ook
// de apostrof. Gebruik dus die ene implementatie.

// --- Cache voor matches van het huidige ticket ---
if (typeof cachedTicketMatches === "undefined") var cachedTicketMatches = [];

// --- Lampje indicator updaten naast de knoppen ---
function updateMatchIndicator(count) {
  const btn = document.getElementById("ln-match-btn");
  if (!btn) return;
  btn.style.display = "inline";
  if (count > 0) {
    btn.style.opacity  = "1";
    btn.style.filter   = "";
    btn.title = `${count} vergelijkbare oplossing${count > 1 ? "en" : ""} gevonden — klik om te bekijken`;
  } else {
    btn.style.opacity  = "0.35";
    btn.style.filter   = "grayscale(1)";
    btn.title = "Geen lokale match — klik voor bekende oplossingen via AI";
  }
}

// --- Basis banner aanmaken (gedeeld door lokale matches en AI-suggesties) ---
function _createBannerBase(title) {
  const existing = document.getElementById("ln-match-banner");
  if (existing) existing.remove();
  const banner = document.createElement("div");
  banner.id = "ln-match-banner";
  Object.assign(banner.style, {
    position: "fixed", bottom: "80px", right: "24px", zIndex: "9999998",
    background: "#083E47", border: "1.5px solid #76B82A",
    borderRadius: "12px", padding: "12px 14px", maxWidth: "340px",
    fontFamily: "Segoe UI, system-ui, sans-serif",
    boxShadow: "0 4px 20px rgba(0,0,0,0.4)", color: "#F7F8F9"
  });
  banner.innerHTML = `
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">
      <span style="font-size:12px;font-weight:700;color:#76B82A;">${title}</span>
      <span id="ln-match-close" style="cursor:pointer;font-size:16px;color:#6D6E72;line-height:1;">×</span>
    </div>
  `;
  return banner;
}

// --- Lokale DB matches tonen ---
function showMatchBanner(matches) {
  const banner = _createBannerBase(`💡 ${matches.length} vergelijkbare oplossing${matches.length > 1 ? "en" : ""} gevonden`);
  const catIcon = { email:"📧", netwerk:"🌐", account:"🔑", hardware:"💻",
                    software:"⚙️", telefoon:"📞", server:"🖥️", overig:"📋" };
  matches.forEach((m, i) => {
    const item = document.createElement("div");
    Object.assign(item.style, {
      background: "#0d4f5c", borderRadius: "8px", padding: "8px 10px",
      marginBottom: i < matches.length - 1 ? "6px" : "0",
      fontSize: "12px", lineHeight: "1.5"
    });
    const pct = Math.round(m.score * 100);
    const titleLine = m.title
      ? `<div style="color:#76B82A;font-size:11px;margin-bottom:3px;font-style:italic;">"${esc(m.title)}"</div>`
      : "";
    item.innerHTML = `
      <div style="display:flex;justify-content:space-between;margin-bottom:4px;">
        <span style="color:#76B82A;font-weight:700;">${esc(catIcon[m.cat] || "📋")} ${esc(m.cat)}</span>
        <span style="color:#6D6E72;font-size:11px;">${pct}% · ${esc(m.hits)}× gebruikt</span>
      </div>
      ${titleLine}
      <div style="color:#9dbfc7;margin-bottom:2px;">🔍 <em>${esc(m.prob)}</em></div>
      ${m.sol
        ? `<div style="color:#F7F8F9;">✅ ${esc(m.sol)}</div>`
        : `<div style="color:#6D6E72;font-style:italic;">Oplossing nog niet bekend</div>`}
    `;
    banner.appendChild(item);
  });
  document.body.appendChild(banner);
  document.getElementById("ln-match-close").addEventListener("click", () => banner.remove());
  setTimeout(() => { if (banner.isConnected) banner.remove(); }, 15000);
}

// --- AI-suggesties tonen ---
function showAISuggestionBanner(suggestions) {
  const banner = _createBannerBase("🤖 Bekende oplossingen via AI");
  suggestions.forEach((s, i) => {
    const item = document.createElement("div");
    Object.assign(item.style, {
      background: "#0d4f5c", borderRadius: "8px", padding: "8px 10px",
      marginBottom: i < suggestions.length - 1 ? "6px" : "0",
      fontSize: "12px", lineHeight: "1.5", color: "#F7F8F9"
    });
    item.innerHTML = `<span style="color:#00B1EB;margin-right:6px;">→</span>${esc(s)}`;
    banner.appendChild(item);
  });
  const note = document.createElement("div");
  note.style.cssText = "font-size:10px;color:#6D6E72;margin-top:8px;";
  note.textContent = "Gebaseerd op AI-kennis — controleer altijd zelf";
  banner.appendChild(note);
  document.body.appendChild(banner);
  document.getElementById("ln-match-close").addEventListener("click", () => banner.remove());
  setTimeout(() => { if (banner.isConnected) banner.remove(); }, 20000);
}

// --- AI-suggesties ophalen en tonen ---
async function showAISuggestions() {
  const meta = readTicketMetadata();
  const problem = [meta.title, meta.description].filter(Boolean).join(" — ");
  if (!problem || problem.length < 5) {
    showToast("⚠️ Onvoldoende ticketcontext om te zoeken", "warning");
    return;
  }
  showToast("🔍 Bekende oplossingen zoeken...", "loading");
  try {
    const suggestions = await callAIForKnownSolutions(problem);
    document.getElementById("ln-toast")?.remove();
    if (suggestions.length > 0) {
      showAISuggestionBanner(suggestions);
    } else {
      showToast("Geen bekende oplossingen gevonden", "info");
    }
  } catch(e) {
    showToast("❌ " + e.message, "error");
  }
}

// --- Message listener ---
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.action === "polishSelection") handlePolish();
});

// --- handlePolish met DB integratie ---
async function handlePolishWithDB() {
  const source = getSelectedText();
  if (!source || !source.text) {
    showToast("⚠️ Geen tekst gevonden. Selecteer tekst of klik in een tekstveld.", "warning");
    return;
  }
  const originalText = source.text;
  const ticketMeta   = readTicketMetadata();
  showToast("⏳ Bezig met polijsten...", "loading");
  try {
    const result = await callAI(originalText);
    const ok = replaceText(source, result);
    if (ok) {
      showToast("✅ Tekst gepolijst!", "success");
      if (_cachedFeatures.oplossing) {
        dbSaveEntry(originalText, result, ticketMeta).catch(() => {});
        // Toon matches NU wel — engineer is actief bezig met time entry
        const matches = cachedTicketMatches.length > 0
          ? cachedTicketMatches
          : await dbFindMatches(originalText, ticketMeta).catch(() => []);
        if (matches.length > 0) showMatchBanner(matches);
      }
    } else {
      await navigator.clipboard.writeText(result);
      showToast("📋 Gekopieerd naar klembord — plak handmatig (Ctrl+V)", "warning");
      if (_cachedFeatures.oplossing) dbSaveEntry(originalText, result, ticketMeta).catch(() => {});
    }
  } catch(e) {
    showToast("❌ Fout: " + e.message, "error");
  }
}

if (typeof window !== "undefined") {
  window.handlePolish = handlePolishWithDB;
}

// --- Lampje knop toevoegen na injectSummaryButton ---
const _origInjectSummaryButton = typeof injectSummaryButton === "function" ? injectSummaryButton : null;

function injectSummaryButtonWithMatch() {
  const result = _origInjectSummaryButton ? _origInjectSummaryButton() : false;
  if (!result) return false;

  if (!_cachedFeatures.oplossing) return result;

  if (!document.getElementById("ln-match-btn")) {
    const labelContainer = document.querySelector("#ln-polish-btn")?.closest(".LabelContainer1");
    if (!labelContainer) return result;

    const matchBtn = document.createElement("span");
    matchBtn.id = "ln-match-btn";
    matchBtn.textContent = "💡";
    matchBtn.style.cssText = "display:inline;cursor:pointer;font-size:14px;user-select:none;margin-left:4px;opacity:0.35;filter:grayscale(1);";
    matchBtn.title = "Geen lokale match — klik voor bekende oplossingen via AI";
    matchBtn.addEventListener("mouseenter", () => { matchBtn.style.opacity = String(parseFloat(matchBtn.style.opacity) + 0.3); });
    matchBtn.addEventListener("mouseleave", () => { updateMatchIndicator(cachedTicketMatches.length); });
    matchBtn.addEventListener("click", async (e) => {
      e.preventDefault(); e.stopPropagation();
      if (cachedTicketMatches.length > 0) showMatchBanner(cachedTicketMatches);
      else await showAISuggestions();
    });
    labelContainer.appendChild(matchBtn);

    // Direct updaten als cache al gevuld is
    if (cachedTicketMatches.length > 0) updateMatchIndicator(cachedTicketMatches.length);
  }
  return result;
}

if (typeof window !== "undefined") {
  window.injectSummaryButton = injectSummaryButtonWithMatch;
}

// --- Stil verzamelen bij openen ticket ---
async function checkMatchesForCurrentTicket() {
  if (!_cachedFeatures.oplossing) return;
  const meta = readTicketMetadata();
  if (!meta.title && !meta.description) return;

  const searchText = [meta.title, meta.description].filter(Boolean).join(" ");
  const matches = await dbFindMatches(searchText, meta).catch(() => []);
  cachedTicketMatches = matches;
  updateMatchIndicator(matches.length); // lampje aan/uit, géén popup

  // Sla ticketcontext op als open entry
  try {
    const allText = [meta.title, meta.description].filter(Boolean).join(" ");
    if (allText.length < 10) return;
    const records   = await dbLoad();
    const ticketRef = hashTicketNr(meta.ticketNr);

    if (ticketRef && records.some(r => r.ref === ticketRef)) return;

    const anonTitle = meta.title       ? anonymize(meta.title)                        : null;
    const anonDesc  = meta.description ? anonymize(meta.description).substring(0,200) : null;
    const keywords  = extractKeywords([anonTitle, anonDesc].filter(Boolean).join(" "));
    if (!keywords.length) return;

    const record = {
      id:   Math.random().toString(36).slice(2,9),
      cat:  detectCategory(keywords),
      kw:   keywords,
      prob: anonTitle || anonDesc || "",
      sol:  "",
      hits: 1,
      last: new Date().toISOString().slice(0,10),
      open: true
    };
    if (anonTitle) record.title = anonTitle;
    if (anonDesc)  record.desc  = anonDesc;
    if (ticketRef) record.ref   = ticketRef;

    records.push(record);
    await dbSave(dbTrim(records));
  } catch { /* silent */ }
}

// --- Detecteer of de "New Ticket Note" modal open is en Status op Complete staat ---
function isNewNoteModalComplete() {
  const completeValues = ["complete", "completed", "resolved"];
  // Vind modal-header
  let modalHdr = null;
  for (const el of document.querySelectorAll("div, span, h1, h2, h3, h4")) {
    if (el.children.length > 0) continue;
    if (el.textContent.trim() === "New Ticket Note") { modalHdr = el; break; }
  }
  if (!modalHdr) return false;
  // Klim omhoog tot een container die ook een Checkbox2 bevat (= modal)
  let modal = modalHdr.parentElement;
  while (modal && modal !== document.body && !modal.querySelector("div.Checkbox2")) {
    modal = modal.parentElement;
  }
  if (!modal || modal === document.body) return false;
  // Zoek het "Status" label binnen de modal en vergelijk de gerenderde waarde
  for (const lbl of modal.querySelectorAll("div, span, label")) {
    if (lbl.children.length > 0) continue;
    if (lbl.textContent.trim().toLowerCase() !== "status") continue;
    // Beperk de zoekruimte tot de directe parent-context
    const scope = lbl.parentElement?.parentElement || lbl.parentElement;
    if (!scope) continue;
    for (const el of scope.querySelectorAll("*")) {
      if (el.children.length > 0) continue;
      const txt = el.textContent.trim().toLowerCase();
      if (completeValues.includes(txt)) return true;
    }
  }
  return false;
}

function startStatusObserver() {
  let alreadyTicked         = false;
  let ticketAlreadyComplete = false;
  let matchCheckedForUrl    = "";
  let completeDialogTicked  = false;   // apart van alreadyTicked — alleen voor Complete Ticket dialog
  let pendingTickTimer      = null;    // debounce voor auto-tick (voorkomt snel klikken bij net-geladen pagina)
  const completeValues = ["complete", "completed", "resolved"];
  const ALL_STATUSES = [
    "new", "escalate", "resolution plan", "in progress",
    "waiting materials", "waiting customer", "waiting vendor",
    "waiting software", "complete", "completed", "resolved",
    "customer note added"
  ];

  // --- Commit-signaal voor de statuskeuze ---------------------------------
  // ".TargetPreview" is een PREVIEW: zolang de statuslijst openstaat toont Autotask
  // daarin de optie waar de cursor overheen gaat. Alleen daarop vertrouwen betekende
  // dat het vinkje al gezet werd door langs "Complete" te scrollen, zonder te kiezen.
  // De auto-tick eist daarom nu een expliciete keuze-actie van de gebruiker.
  // Bewust class-agnostisch: we kijken naar de tekst van wat er is aangeklikt, niet
  // naar Autotask-specifieke classes van de dropdown.
  let statusCommit   = null;   // laatst gekozen statuswaarde (lowercase)
  let statusCommitAt = 0;      // wanneer die keuze plaatsvond
  const COMMIT_TTL_MS = 20000; // ouder dan dit telt niet meer als "net gekozen"

  function noteStatusCommit(value) {
    const v = String(value ?? "").trim().toLowerCase();
    if (!v || !ALL_STATUSES.includes(v)) return;
    statusCommit   = v;
    statusCommitAt = Date.now();
  }

  // --- Staat de statuslijst open? ------------------------------------------
  // Het beslissende signaal, afgeleid uit de echte Autotask-UI: met een open lijst
  // staan ALLE statusopties gelijktijdig als losse regels in beeld, en toont het
  // veld bovenaan nog de oude waarde terwijl de cursor over een andere optie gaat.
  // Dichtgeklapt is er precies één waarde zichtbaar (met een groen vinkje ervoor).
  // Zolang de lijst openstaat is de weergegeven waarde dus geen keuze.
  //
  // Drempel op 3 en niet op 2: naast de popup kan de ticketpagina eronder ook een
  // status tonen, dus twee verschillende waarden is normaal bij een dichte lijst.
  // Een open lijst laat er tien zien, dus de marge is ruim. De vergelijking eist de
  // VOLLEDIGE tekst van een leaf-element, waardoor feed-tekst als "Status changed to
  // Complete" niet meetelt.
  const STATUS_LIST_OPEN_THRESHOLD = 3;

  function visibleStatusOptions() {
    const seen = new Set();
    for (const el of document.querySelectorAll("div, span, li, td")) {
      if (el.children.length > 0) continue;
      const t = el.textContent.trim().toLowerCase();
      if (!ALL_STATUSES.includes(t)) continue;
      // ZICHTBAARHEID is essentieel. Autotask houdt de optielijst permanent in de
      // DOM en verbergt hem met CSS. Zonder deze controle zag deze functie ook bij
      // een dichte lijst alle opties, bleef de blokkade altijd staan en werd er
      // nooit meer gevinkt. getClientRects() is leeg bij display:none en bij nul
      // afmetingen, en wordt hier pas aangeroepen nadat de tekst al matchte, dus
      // voor een handvol elementen in plaats van de hele DOM.
      if (el.getClientRects().length === 0) continue;
      seen.add(t);
    }
    return seen;
  }

  function isStatusListOpen() {
    return visibleStatusOptions().size >= STATUS_LIST_OPEN_THRESHOLD;
  }

  // Aantal opeenvolgende metingen met een DICHTE lijst en Complete als waarde.
  // Bij een dichte lijst is de weergegeven waarde per definitie de gekozen waarde,
  // dus dit is een geldige tweede route naast een expliciete klik. Zo blijft de
  // functie werken ook als Autotask de klik anders aflevert dan verwacht.
  let closedCompletePolls = 0;
  const CLOSED_POLLS_REQUIRED = 2;

  function hasFreshCompleteCommit() {
    if (closedCompletePolls >= CLOSED_POLLS_REQUIRED) return true;
    return statusCommit !== null
        && completeValues.includes(statusCommit)
        && (Date.now() - statusCommitAt) < COMMIT_TTL_MS;
  }

  // --- Diagnostiek ---------------------------------------------------------
  // Aan te roepen in de console met een geopende time entry: _lnDebugStatus()
  // Geeft exact terug wat de observer ziet. Deze detectie leunt op de DOM van
  // Autotask, en die is niet vanaf de broncode te kennen; met deze uitvoer is een
  // foute meting vast te stellen in plaats van te moeten gokken.
  window._lnDebugStatus = () => ({
    zichtbareStatusOpties:  [...visibleStatusOptions()],
    lijstStaatOpen:         isStatusListOpen(),
    targetPreviewTeksten:   [...document.querySelectorAll(".TargetPreview")]
                              .map(el => el.textContent.trim()),
    noteModalComplete:      isNewNoteModalComplete(),
    paginaStatus:           readTicketStatusFromPage(),
    ticketAlreadyComplete,
    closedCompletePolls,
    laatsteKeuze:           statusCommit,
    keuzeGeldig:            hasFreshCompleteCommit(),
    alGevinkt:              alreadyTicked,
    checkboxGevonden:       !!document.querySelector("div.Checkbox2")
  });

  // Klik op een optie. De klik landt vaak op een span of icoon binnen de optieregel,
  // dus een paar niveaus omhoog lopen tot een element waarvan de tekst exact een
  // statuswaarde is.
  document.addEventListener("click", (e) => {
    let n = e.target, depth = 0;
    while (n && depth < 4) {
      const txt = String(n.textContent ?? "").trim();
      if (txt.length <= 40 && ALL_STATUSES.includes(txt.toLowerCase())) {
        noteStatusCommit(txt);
        return;
      }
      n = n.parentElement; depth++;
    }
  }, { capture: true });

  // Toetsenbordselectie: Enter bevestigt de gemarkeerde optie, en die staat op dat
  // moment in de preview. Hier is de preview dus wel betrouwbaar, want er is een
  // expliciete bevestiging.
  document.addEventListener("keydown", (e) => {
    if (e.key !== "Enter") return;
    document.querySelectorAll(".TargetPreview").forEach(el => noteStatusCommit(el.textContent));
  }, { capture: true });

  // Native <select>: dan is er geen klik op een los optie-element.
  document.addEventListener("change", (e) => {
    const el = e.target;
    if (!el || el.tagName !== "SELECT") return;
    noteStatusCommit(el.value);
    noteStatusCommit(el.options?.[el.selectedIndex]?.text);
  }, { capture: true });

  // Lees de pagina-status bij opstart meerdere keren — eerst snel, daarna robuust.
  // Dit zorgt dat ticketAlreadyComplete correct staat vóórdat een popup geopend wordt,
  // ook bij langzame pagina-rendering.
  const _initStatusCheck = (delay) => setTimeout(() => {
    if (ticketAlreadyComplete) return; // al gezet — status wordt niet meer "niet-complete"
    const status = readTicketStatusFromPage();
    if (status !== null) ticketAlreadyComplete = completeValues.includes(status);
  }, delay);
  _initStatusCheck(300);
  _initStatusCheck(1500);
  _initStatusCheck(3000); // extra check voor trage Autotask-renders

  // --- Complete Ticket dialog: auto-aanvinken Append to Resolution ---
  // VEILIGHEID: detecteert de dialog via het unieke label "reason for completing".
  // Dit is fundamenteel anders dan de time entry popup op een al-gesloten ticket
  // (die heeft dit label NIET) — de twee flows raken elkaar dus niet.
  function handleCompleteTicketDialog() {
    // Zoek het unieke label van de Complete Ticket dialog
    let reasonLabel = null;
    for (const el of document.querySelectorAll("div, span")) {
      if (el.children.length === 0 &&
          el.textContent.trim().toLowerCase().includes("reason for completing")) {
        reasonLabel = el;
        break;
      }
    }

    if (!reasonLabel) {
      completeDialogTicked = false; // reset zodra dialog verdwenen is
      return;
    }
    if (completeDialogTicked) return;

    // Zoek Checkbox2 binnen dezelfde dialog-container
    let container = reasonLabel.parentElement;
    while (container && container !== document.body) {
      if (container.querySelector("div.Checkbox2")) break;
      container = container.parentElement;
    }
    if (!container || container === document.body) return;

    container.querySelectorAll("div.Checkbox2").forEach(el => {
      if (!el.textContent.trim().toLowerCase().includes("append")) return;
      const hack = el.querySelector("div.TabIndexHack");
      if (hack && !hack.classList.contains("Checked")) {
        hack.click();
        showToast("☑️ 'Append to Resolution' aangevinkt!", "success");
      }
      completeDialogTicked = true;
    });
  }

  function readTicketStatusFromPage() {
    const allStatuses = ALL_STATUSES;

    const checkbox = document.querySelector("div.Checkbox2");
    let popupContainer = null;
    if (checkbox) {
      let node = checkbox.parentElement;
      while (node && node !== document.body) {
        const r = node.getBoundingClientRect();
        if (r.width > 500 && r.height > 400) { popupContainer = node; break; }
        node = node.parentElement;
      }
    }

    const allEls = document.querySelectorAll("div, span");
    for (const el of allEls) {
      if (el.children.length > 0) continue;
      if (el.textContent.trim() !== "Status") continue;
      if (popupContainer && popupContainer.contains(el)) continue;

      let sibling = el.nextElementSibling;
      while (sibling) {
        const txt = sibling.textContent.trim().toLowerCase();
        if (allStatuses.includes(txt)) return txt;
        for (const child of sibling.querySelectorAll("*")) {
          const childTxt = child.textContent.trim().toLowerCase();
          if (allStatuses.includes(childTxt)) return childTxt;
        }
        sibling = sibling.nextElementSibling;
      }
      const parentNext = el.parentElement?.nextElementSibling;
      if (parentNext) {
        const txt = parentNext.textContent.trim().toLowerCase();
        if (allStatuses.includes(txt)) return txt;
        for (const child of parentNext.querySelectorAll("*")) {
          const childTxt = child.textContent.trim().toLowerCase();
          if (allStatuses.includes(childTxt)) return childTxt;
        }
      }
    }
    return null;
  }

  setInterval(() => {
    // Bij elke interval-tik de status hercontroleren zolang we nog niet zeker zijn dat het ticket gesloten is.
    // Dit lost het geval op waarbij een engineer binnen 1-3s na pagina-load al de popup opent.
    if (!ticketAlreadyComplete) {
      const liveStatus = readTicketStatusFromPage();
      if (liveStatus !== null && completeValues.includes(liveStatus)) {
        ticketAlreadyComplete = true;
      }
    }

    if (!document.getElementById("ln-summary-btn") || !document.getElementById("ln-polish-btn")) {
      injectSummaryButton();
    }

    // Track nieuwe iframes die Autotask dynamisch toevoegt (bijv. bij openen notitieveld)
    if (typeof _lnTrackIframe === "function") {
      document.querySelectorAll("iframe").forEach(frame => {
        if (!frame._lnTracked) {
          frame._lnTracked = true;
          _lnTrackIframe(frame);
        }
      });
    }
    if (!document.getElementById("ln-toolbar-group")) {
      injectActivityToolbarButtons();
    }
    const newtixBtn = document.getElementById("ln-newtix-btn");
    if (newtixBtn && !isNewOrEditTicketPage()) {
      newtixBtn.remove();
    } else if (!newtixBtn) {
      injectNewTicketButtons();
    }

    // Complete Ticket dialog: knoppen + auto-tick Append to Resolution
    handleCompleteTicketDialog();
    if (!document.getElementById("ln-completetix-btn")) {
      if (typeof injectCompleteTicketDialogButtons === "function") {
        injectCompleteTicketDialogButtons();
      }
    }

    // Check matches 1× per unieke ticket URL — stil, geen popup
    const currentUrl = location.href;
    if (currentUrl !== matchCheckedForUrl) {
      matchCheckedForUrl    = currentUrl;
      cachedTicketMatches   = [];
      alreadyTicked         = false;
      statusCommit          = null;  // keuze hoort bij het vorige ticket
      closedCompletePolls   = 0;
      ticketAlreadyComplete = false; // reset bij nieuw ticket, hercheck hieronder
      setTimeout(() => checkMatchesForCurrentTicket(), 1500);
      // Hercheck status na navigatie — proactief, vóór popup kan openen
      _initStatusCheck(300);
      _initStatusCheck(1200);
    }

    const appendExists = document.querySelector("div.Checkbox2");

    if (!appendExists) {
      alreadyTicked = false;
      // Geen checkbox = geen popup. Een volgende popup mag de keuze uit de vorige
      // niet erven, anders vinkt hij daar meteen aan.
      statusCommit = null;
      closedCompletePolls = 0;
      if (pendingTickTimer) { clearTimeout(pendingTickTimer); pendingTickTimer = null; }
      const status = readTicketStatusFromPage();
      if (status !== null) ticketAlreadyComplete = completeValues.includes(status);
      return;
    }

    if (alreadyTicked) return;
    if (ticketAlreadyComplete) return;

    // Wat staat er als doelstatus in beeld?
    let isComplete = false;
    document.querySelectorAll(".TargetPreview").forEach(el => {
      const txt = el.textContent.trim().toLowerCase();
      if (completeValues.includes(txt)) isComplete = true;
    });
    // Ook detecteren in de "New Ticket Note" modal — die heeft geen TargetPreview
    if (!isComplete && isNewNoteModalComplete()) isComplete = true;

    // HARDE BLOKKADE: staat de statuslijst open, dan is de weergegeven waarde geen
    // keuze maar de stand van de cursor. Dit is de kern van de bugfix; hiervoor werd
    // er al gevinkt door langs Complete te scrollen.
    const listOpen = isStatusListOpen();
    if (listOpen) {
      closedCompletePolls = 0;
      if (pendingTickTimer) { clearTimeout(pendingTickTimer); pendingTickTimer = null; }
      return;
    }

    // Lijst is dicht. Tel hoe lang Complete er onafgebroken staat.
    closedCompletePolls = isComplete ? closedCompletePolls + 1 : 0;

    if (!isComplete) {
      if (pendingTickTimer) { clearTimeout(pendingTickTimer); pendingTickTimer = null; }
      return;
    }

    // Complete staat in beeld met een dichte lijst. Vereist daarnaast dat de keuze
    // ook echt gemaakt is: een klik/Enter/select-change, of Complete die meerdere
    // metingen achtereen bij een dichte lijst blijft staan.
    if (!hasFreshCompleteCommit()) {
      if (pendingTickTimer) { clearTimeout(pendingTickTimer); pendingTickTimer = null; }
      return;
    }

    // Debounced auto-tick — niet direct klikken. Geeft de pagina tijd om te renderen en
    // voorkomt dat we vinken terwijl het ticket eigenlijk al gesloten was (trage status-detectie).
    if (pendingTickTimer) return; // er staat al een tick gepland
    pendingTickTimer = setTimeout(() => {
      pendingTickTimer = null;

      // Dubbele check vlak vóór de klik:
      // 1. Ticket mag niet inmiddels als reeds-gesloten blijken
      if (ticketAlreadyComplete || alreadyTicked) return;
      const liveStatus = readTicketStatusFromPage();
      if (liveStatus !== null && completeValues.includes(liveStatus)) {
        ticketAlreadyComplete = true;
        return;
      }
      // 2. De lijst mag inmiddels niet weer opengeklapt zijn, en de keuze moet nog
      //    steeds Complete zijn. Kiest de gebruiker in de tussentijd iets anders, dan
      //    overschrijft die keuze statusCommit en valt dit weg.
      if (isStatusListOpen()) return;
      if (!hasFreshCompleteCommit()) return;

      // 3. Popup moet nog openstaan met Complete-target
      let stillComplete = false;
      document.querySelectorAll(".TargetPreview").forEach(el => {
        if (completeValues.includes(el.textContent.trim().toLowerCase())) stillComplete = true;
      });
      if (!stillComplete && isNewNoteModalComplete()) stillComplete = true;
      if (!stillComplete) return;

      document.querySelectorAll("div.Checkbox2").forEach(el => {
        const t = el.textContent.trim().toLowerCase();
        if (!t.includes("append") || !t.includes("resolution")) return;
        const hack = el.querySelector("div.TabIndexHack");
        if (hack && !hack.classList.contains("Checked") && !alreadyTicked) {
          hack.click();
          showToast("☑️ 'Append to Resolution' automatisch aangevinkt!", "success");
          alreadyTicked = true;
        } else if (hack && hack.classList.contains("Checked")) {
          alreadyTicked = true;
        }
      });
    }, 1200); // debounce: engineer ziet eerst de popup voordat er iets geklikt wordt
  }, 1500);
}

// --- Start ---
startStatusObserver();
langOverride = null;

} // end _lnObserverLoaded guard