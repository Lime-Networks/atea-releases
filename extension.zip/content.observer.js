// ============================================================
// Lime Networks — content.observer.js
// Status observer + message listener
// Vinkt "Append Summary Notes to Resolution" aan wanneer de engineer de
// ticketstatus daadwerkelijk op Complete zet.
// ============================================================

// Guard: voorkom dat het script meerdere keren in dezelfde scope laadt
// (Autotask gebruikt iframes waardoor content scripts herhaald worden geladen)
if (typeof window._lnObserverLoaded !== "undefined") {
  // Al geladen — stop hier
} else {
window._lnObserverLoaded = true;

// --- Ticket metadata uitlezen van de Autotask pagina ---
function readTicketMetadata() {
  const meta = { title: null, description: null, ticketNr: null };

  // Ticketnummer (patroon: T20260311.0027)
  document.querySelectorAll("span, div, h1, h2").forEach(el => {
    if (meta.ticketNr) return;
    const txt = el.textContent.trim();
    if (/^T\d{8}\.\d{4}$/.test(txt)) meta.ticketNr = txt;
  });
  if (!meta.ticketNr) {
    const urlMatch = location.href.match(/ids%5B0%5D=(\d+)/);
    if (urlMatch) meta.ticketNr = "ID" + urlMatch[1];
  }

  // Tickettitel
  document.querySelectorAll("div.Title").forEach(el => {
    if (meta.title) return;
    if (!el.parentElement?.className?.includes("Content")) return;
    const txt = el.textContent.trim();
    if (txt.length > 5 && txt.length < 300 && !txt.includes("Ticket -")) {
      meta.title = txt;
    }
  });

  // Description
  document.querySelectorAll("div, span").forEach(el => {
    if (meta.description) return;
    if (el.children.length > 0) return;
    if (el.textContent.trim() !== "Description") return;
    let node = el.nextElementSibling || el.parentElement?.nextElementSibling;
    while (node) {
      const txt = node.textContent.trim();
      if (txt.length > 10 && txt !== "Description") {
        meta.description = txt.substring(0, 300);
        break;
      }
      node = node.nextElementSibling;
    }
  });

  return meta;
}

// --- HTML escaping ---
// Bewust GEEN eigen esc() meer hier. Dit bestand laadt als laatste (zie manifest.json en
// CONTENT_FILES in background.js), en een functiedeclaratie in dit else-blok wordt via
// Annex B naar de globale scope gehesen. Een duplicaat hier overschreef daarmee de
// volledigere esc() uit content.polish.js voor de HELE extensie — die versie escapet ook
// de apostrof. Gebruik dus die ene implementatie.

// --- Message listener ---
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.action === "polishSelection") handlePolish();
});

// --- Detecteer of de "New Ticket Note" modal open is en Status op Complete staat ---
function isNewNoteModalComplete() {
  const completeValues = ["complete", "completed", "resolved"];
  // Vind modal-header
  let modalHdr = null;
  for (const el of document.querySelectorAll("div, span, h1, h2, h3, h4")) {
    if (el.children.length > 0) continue;
    if (el.textContent.trim() === "New Ticket Note") { modalHdr = el; break; }
  }
  if (!modalHdr) return false;
  // Klim omhoog tot een container die ook een Checkbox2 bevat (= modal)
  let modal = modalHdr.parentElement;
  while (modal && modal !== document.body && !modal.querySelector("div.Checkbox2")) {
    modal = modal.parentElement;
  }
  if (!modal || modal === document.body) return false;
  // Zoek het "Status" label binnen de modal en vergelijk de gerenderde waarde
  for (const lbl of modal.querySelectorAll("div, span, label")) {
    if (lbl.children.length > 0) continue;
    if (lbl.textContent.trim().toLowerCase() !== "status") continue;
    // Beperk de zoekruimte tot de directe parent-context
    const scope = lbl.parentElement?.parentElement || lbl.parentElement;
    if (!scope) continue;
    for (const el of scope.querySelectorAll("*")) {
      if (el.children.length > 0) continue;
      const txt = el.textContent.trim().toLowerCase();
      if (completeValues.includes(txt)) return true;
    }
  }
  return false;
}

function startStatusObserver() {
  let alreadyTicked         = false;
  let laatstGezienUrl       = "";      // om state te resetten bij een ander ticket
  let completeDialogTicked  = false;   // apart van alreadyTicked — alleen voor Complete Ticket dialog
  let pendingTickTimer      = null;    // korte bevestiging vóór de klik
  let popupWasOpen          = false;   // om het sluiten van een popup te herkennen
  const completeValues = ["complete", "completed", "resolved"];
  const ALL_STATUSES = [
    "new", "escalate", "resolution plan", "in progress",
    "waiting materials", "waiting customer", "waiting vendor",
    "waiting software", "complete", "completed", "resolved",
    "customer note added"
  ];

  // --- Wanneer vinken? (regel van Aleks, 17 nov 2026) ----------------------
  // Vinken als de time entry op Complete staat en het TICKET zelf nog niet
  // Complete is. Alleen als het ticket al Complete is en de time entry ook, is
  // het een bij-boeking op een gesloten ticket en blijft het vinkje uit.
  //
  // Waarom dit nodig was: met de Complete-knop bovenin het ticket opent de time
  // entry met de status al op Complete. De engineer kiest dan niets uit de lijst,
  // en de oude logica eiste juist zo'n keuze. Dan werd er dus nooit gevinkt.
  //
  // De ticketstatus komt van de pagina (zijbalk). Lukt het niet die eenduidig te
  // lezen, dan valt de logica terug op het oude, veilige gedrag: alleen vinken na
  // een expliciete keuze voor Complete (uit de lijst, of de Complete-knop).

  // --- Commit-signaal voor de statuskeuze ---------------------------------
  // ".TargetPreview" is een PREVIEW: zolang de statuslijst openstaat toont Autotask
  // daarin de optie waar de cursor overheen gaat. Een keuze vereist daarom een
  // expliciete actie van de gebruiker.
  let statusCommit     = null;   // laatst gekozen statuswaarde (lowercase)
  let statusCommitAt   = 0;      // wanneer die keuze plaatsvond
  let statusCommitBron = null;   // "lijst", "toets", "select" of "werkbalk"
  const COMMIT_TTL_MS = 20000;   // ouder dan dit telt niet meer als "net gekozen"
  const TICK_CONFIRM_MS = 400;   // was 1200; de snelle checks hieronder doen de rest

  function noteStatusCommit(value, bron) {
    const v = String(value ?? "").trim().toLowerCase();
    if (!v || !ALL_STATUSES.includes(v)) return;
    statusCommit     = v;
    statusCommitAt   = Date.now();
    statusCommitBron = bron || null;
  }

  // --- Staat de statuslijst open? ------------------------------------------
  // Met een open lijst staan ALLE statusopties gelijktijdig als losse regels in
  // beeld, en toont het veld bovenaan nog de oude waarde terwijl de cursor over een
  // andere optie gaat. Dichtgeklapt is er precies één waarde zichtbaar.
  //
  // Drempel op 3 en niet op 2: naast de popup kan de ticketpagina eronder ook een
  // status tonen, dus twee verschillende waarden is normaal bij een dichte lijst.
  // Een open lijst laat er tien zien, dus de marge is ruim. De vergelijking eist de
  // VOLLEDIGE tekst van een leaf-element, waardoor feed-tekst als "Status changed to
  // Complete" niet meetelt.
  const STATUS_LIST_OPEN_THRESHOLD = 3;

  // Het vinkje zelf. Een ticketpagina bevat tientallen Checkbox2's (gemeten: 19),
  // dus ankeren op de tekst. Alleen een zichtbare telt: zonder popup is er geen.
  function findAppendCheckbox() {
    for (const el of document.querySelectorAll("div.Checkbox2")) {
      const t = el.textContent.trim().toLowerCase();
      if (!t.includes("append") || !t.includes("resolution")) continue;
      if (el.getClientRects().length === 0) continue;
      return el;
    }
    return null;
  }

  // Het Status-veld zelf: de .TargetPreview die een statuswaarde toont. Die class
  // zit op alle dropdown-weergaven in de popup (ook "Engineer", "Enter Speed Code"),
  // dus filteren op de inhoud is nodig.
  function findStatusField() {
    for (const el of document.querySelectorAll(".TargetPreview")) {
      if (!ALL_STATUSES.includes(el.textContent.trim().toLowerCase())) continue;
      if (el.getClientRects().length === 0) continue;
      return el;
    }
    return null;
  }

  // Marges rond het Status-veld waarbinnen een uitgeklapte lijst kan liggen.
  // Gemeten op een echte ticketpagina: veld op [239,259,294,30], dus midden x=386
  // en onderkant y=289. De open lijst liep van y=311 tot y=617 met x tussen 284 en
  // 332. Ruis die net buiten die band valt: de Complete-knop in de werkbalk
  // (x=464, y=74) en de status in de zijbalk (x=145, y=252). Met deze marges is de
  // meting dicht 1 waarde en open 10 - ruim boven en onder de drempel van 3.
  const FIELD_X_MARGIN    = 200;
  const FIELD_Y_ABOVE     = 100;  // dropdown kan iets omhoog uitklappen
  const FIELD_Y_BELOW     = 450;  // ruimte voor de volledige lijst

  // Statusopties die zichtbaar zijn in de band rond het Status-veld.
  // Twee filters, elk voor een concreet gemeten probleem:
  //  1. Zichtbaarheid. Autotask verwijdert de optielijst niet bij dichtklappen maar
  //     verbergt hem met CSS. Zonder deze controle leek de lijst altijd open en
  //     werd er nooit gevinkt (v2.13.4).
  //  2. Positie rond het Status-VELD, niet rond de popup. Document-breed tellen liep
  //     altijd over de drempel door de statuskolom van het gerelateerde-tickets
  //     paneel (v2.13.5). Begrenzen op de popup-container hielp niet: die container
  //     bleek een binnensectie op y=582 terwijl de lijst uitklapt op y=311..617, dus
  //     werden er maar 2 van de 10 opties geteld en bleef de blokkade uit (v2.13.6).
  // De vergelijking is geometrisch en niet op DOM-nesting, zodat een dropdown die
  // Autotask buiten de modal in de DOM plaatst maar er visueel bovenop rendert,
  // wel meetelt.
  // Geeft null als het Status-veld niet te vinden is.
  function visibleStatusOptions() {
    const veld = findStatusField();
    if (!veld) return null;
    const fr = veld.getBoundingClientRect();
    const fx = fr.left + fr.width / 2;
    const seen = new Set();
    for (const el of document.querySelectorAll("div, span, li, td")) {
      if (el.children.length > 0) continue;
      const t = el.textContent.trim().toLowerCase();
      if (!ALL_STATUSES.includes(t)) continue;
      const rects = el.getClientRects();
      if (rects.length === 0) continue;
      const r = rects[0];
      const cx = r.left + r.width / 2;
      const cy = r.top + r.height / 2;
      if (Math.abs(cx - fx) > FIELD_X_MARGIN) continue;
      if (cy < fr.top - FIELD_Y_ABOVE || cy > fr.bottom + FIELD_Y_BELOW) continue;
      seen.add(t);
    }
    return seen;
  }

  function isStatusListOpen() {
    const opts = visibleStatusOptions();
    if (opts === null) return false;
    return opts.size >= STATUS_LIST_OPEN_THRESHOLD;
  }

  function hasFreshCompleteCommit() {
    return statusCommit !== null
        && completeValues.includes(statusCommit)
        && (Date.now() - statusCommitAt) < COMMIT_TTL_MS;
  }

  // Staat de time entry (of de New Ticket Note) op Complete?
  function entryStatusIsComplete() {
    for (const el of document.querySelectorAll(".TargetPreview")) {
      if (completeValues.includes(el.textContent.trim().toLowerCase())) return true;
    }
    return isNewNoteModalComplete();
  }

  // --- Ticketstatus van de pagina, BUITEN de popup --------------------------
  // De popup heeft zelf ook een "Status"-label met de time-entry-status. Die mag
  // nooit als ticketstatus gelezen worden, anders lijkt elk ticket al Complete.
  // Uitsluiten gebeurt twee keer: via de DOM (gemeenschappelijke voorouder van
  // vinkje en Status-veld) en geometrisch (het vlak van Status-veld tot vinkje),
  // omdat Autotask delen van de popup ook buiten de modal in de DOM kan zetten.
  const POPUP_MARGIN = 40;

  function popupExclusion() {
    const cb = findAppendCheckbox();
    const veld = findStatusField();
    if (!cb || !veld) return null;
    let root = cb.parentElement;
    while (root && !root.contains(veld)) root = root.parentElement;
    if (root === document.body || root === document.documentElement) root = null;
    const a = cb.getBoundingClientRect(), b = veld.getBoundingClientRect();
    return {
      root,
      left:   Math.min(a.left, b.left) - POPUP_MARGIN,
      right:  Math.max(a.right, b.right) + POPUP_MARGIN,
      top:    Math.min(a.top, b.top) - POPUP_MARGIN,
      bottom: Math.max(a.bottom, b.bottom) + POPUP_MARGIN
    };
  }

  function isInPopup(el, excl) {
    if (!excl) return false;
    if (excl.root && excl.root.contains(el)) return true;
    const r = el.getBoundingClientRect();
    const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
    return cx >= excl.left && cx <= excl.right && cy >= excl.top && cy <= excl.bottom;
  }

  // Een waarde hoort bij een label als hij er vlak onder of rechts naast staat.
  // In de zijbalk staat "Status" boven de waarde ("New" in een gekleurd label).
  function isNearLabel(lr, r) {
    return r.top >= lr.top - 10 && r.top <= lr.bottom + 80
        && r.left >= lr.left - 20 && r.left <= lr.right + 300;
  }

  // Geeft de ticketstatus (lowercase) of null. Null als er niets gevonden wordt OF
  // als er verschillende waarden gevonden worden: bij twijfel geen gok, dan geldt
  // de terugval op een expliciete keuze.
  function readTicketStatusFromPage() {
    const excl = popupExclusion();
    const values = new Set();
    for (const label of document.querySelectorAll("div, span, label")) {
      if (label.children.length > 0) continue;
      if (label.textContent.trim() !== "Status") continue;
      if (label.getClientRects().length === 0) continue;
      if (isInPopup(label, excl)) continue;
      const lr = label.getBoundingClientRect();
      // In de dichtstbijzijnde voorouders zoeken: de waarde staat niet altijd in
      // een volgend zusterelement (gemeten in sept 2026: de oude lezer gaf null).
      let anc = label.parentElement, found = null;
      for (let depth = 0; depth < 4 && anc && anc !== document.body && !found; depth++) {
        for (const el of anc.querySelectorAll("*")) {
          if (el === label || el.children.length > 0) continue;
          const t = el.textContent.trim().toLowerCase();
          if (!ALL_STATUSES.includes(t)) continue;
          if (el.getClientRects().length === 0) continue;
          if (isInPopup(el, excl)) continue;
          if (!isNearLabel(lr, el.getBoundingClientRect())) continue;
          found = t;
          break;
        }
        anc = anc.parentElement;
      }
      if (found) values.add(found);
    }
    return values.size === 1 ? [...values][0] : null;
  }

  // De beslissing, los van timing. Alleen zinvol als de time entry op Complete staat.
  function tickDecision() {
    const pagina = readTicketStatusFromPage();
    if (pagina !== null) {
      return completeValues.includes(pagina)
        ? { tick: false, reden: `ticket staat al op ${pagina}` }
        : { tick: true,  reden: `ticket staat op ${pagina}` };
    }
    return hasFreshCompleteCommit()
      ? { tick: true,  reden: `ticketstatus onbekend, Complete gekozen (${statusCommitBron})` }
      : { tick: false, reden: "ticketstatus onbekend en geen keuze voor Complete" };
  }

  // --- Diagnostiek ---------------------------------------------------------
  // Aan te roepen in de console met een geopende time entry: _lnDebugStatus()
  // (contextkiezer op de extensie, niet op "top": content scripts draaien in een
  // isolated world).
  window._lnDebugStatus = () => {
    const excl = popupExclusion();
    return {
      zichtbareStatusOpties: visibleStatusOptions() === null
                               ? "(Status-veld niet gevonden)"
                               : [...visibleStatusOptions()],
      statusVeldRect:        (() => {
                               const v = findStatusField();
                               if (!v) return null;
                               const r = v.getBoundingClientRect();
                               return [Math.round(r.left), Math.round(r.top),
                                       Math.round(r.width), Math.round(r.height)];
                             })(),
      vinkjeGevonden:        !!findAppendCheckbox(),
      popupUitsluiting:      excl ? { viaDom: !!excl.root,
                                      vlak: [excl.left, excl.top, excl.right, excl.bottom].map(Math.round) } : null,
      lijstStaatOpen:        isStatusListOpen(),
      timeEntryOpComplete:   entryStatusIsComplete(),
      noteModalComplete:     isNewNoteModalComplete(),
      paginaStatus:          readTicketStatusFromPage(),
      laatsteKeuze:          statusCommit,
      keuzeBron:             statusCommitBron,
      keuzeGeldig:           hasFreshCompleteCommit(),
      beslissing:            tickDecision(),
      alGevinkt:             alreadyTicked
    };
  };

  // Klik op een optie IN DE UITKLAPLIJST. De klik landt op een span binnen de
  // optieregel, dus een paar niveaus omhoog lopen.
  //
  // Gemeten ketens op een echte pagina:
  //   optie kiezen      SPAN -> DIV.Text -> DIV.Item -> DIV.ItemList
  //   lijst OPENklikken DIV.SelectionDisplay -> DIV.ValueContainer ->
  //                     DIV.ContentContainer -> DIV.SingleItemSelector2
  // Die tweede bevat OOK de tekst van de huidige waarde. Daarom is een
  // ItemList-voorouder vereist voor een keuze uit de lijst.
  //
  // De Complete-knop in de werkbalk van het ticket telt ook als keuze: die opent de
  // time entry met de status al op Complete. Herkend aan de tekst "Complete" in de
  // klikketen, zonder dropdown-classes, op een knop of bovenin het scherm (gemeten:
  // x 464, y 74). Dit is alleen de terugval voor als de ticketstatus niet te lezen is.
  const WERKBALK_MAX_Y = 150;
  const DROPDOWN_CLS   = /\b(ItemList|SingleItemSelector2|TargetPreview|SelectionDisplay)\b/;

  function noteCommitFromEvent(e) {
    let n = e.target, depth = 0, tekst = null, inLijst = false;
    let inDropdown = false, completeEl = null, knopAchtig = false;
    while (n && n !== document.body && depth < 8) {
      const cls = String(n.className || "");
      if (/\bItemList\b/.test(cls)) inLijst = true;
      if (DROPDOWN_CLS.test(cls)) inDropdown = true;
      const txt = String(n.textContent ?? "").trim();
      if (depth < 6 && !tekst && txt.length <= 40 && ALL_STATUSES.includes(txt.toLowerCase())) tekst = txt;
      if (depth < 4 && !completeEl && txt.toLowerCase() === "complete") completeEl = n;
      if (n.tagName === "BUTTON" || n.getAttribute?.("role") === "button" || /button/i.test(cls)) knopAchtig = true;
      n = n.parentElement; depth++;
    }
    if (tekst && inLijst) { noteStatusCommit(tekst, "lijst"); return; }
    if (completeEl && !inDropdown) {
      const bovenin = completeEl.getBoundingClientRect().top < WERKBALK_MAX_Y;
      if (knopAchtig || bovenin) noteStatusCommit("complete", "werkbalk");
    }
  }

  // Na elke actie een paar keer snel controleren, in plaats van te wachten op de
  // interval van 1,5 s. Na de Complete-knop heeft de popup even nodig om te openen,
  // vandaar ook de latere tijdstippen.
  let quickTimers = [];
  function scheduleQuickChecks() {
    quickTimers.forEach(clearTimeout);
    quickTimers = [150, 600, 1500, 3000].map(ms => setTimeout(evaluateAppendTick, ms));
  }

  document.addEventListener("click", (e) => { noteCommitFromEvent(e); scheduleQuickChecks(); }, { capture: true });
  document.addEventListener("mousedown", noteCommitFromEvent, { capture: true });

  // Toetsenbordselectie: Enter bevestigt de gemarkeerde optie, en die staat op dat
  // moment in de preview. Hier is de preview dus wel betrouwbaar, want er is een
  // expliciete bevestiging.
  document.addEventListener("keydown", (e) => {
    if (e.key !== "Enter") return;
    document.querySelectorAll(".TargetPreview").forEach(el => noteStatusCommit(el.textContent, "toets"));
    scheduleQuickChecks();
  }, { capture: true });

  // Native <select>: dan is er geen klik op een los optie-element.
  document.addEventListener("change", (e) => {
    const el = e.target;
    if (!el || el.tagName !== "SELECT") return;
    noteStatusCommit(el.value, "select");
    noteStatusCommit(el.options?.[el.selectedIndex]?.text, "select");
    scheduleQuickChecks();
  }, { capture: true });

  // --- Complete Ticket dialog: auto-aanvinken Append to Resolution ---
  // VEILIGHEID: detecteert de dialog via het unieke label "reason for completing".
  // Dit is fundamenteel anders dan de time entry popup op een al-gesloten ticket
  // (die heeft dit label NIET) — de twee flows raken elkaar dus niet.
  function handleCompleteTicketDialog() {
    // Zoek het unieke label van de Complete Ticket dialog
    let reasonLabel = null;
    for (const el of document.querySelectorAll("div, span")) {
      if (el.children.length === 0 &&
          el.textContent.trim().toLowerCase().includes("reason for completing")) {
        reasonLabel = el;
        break;
      }
    }

    if (!reasonLabel) {
      completeDialogTicked = false; // reset zodra dialog verdwenen is
      return;
    }
    if (completeDialogTicked) return;

    // Zoek Checkbox2 binnen dezelfde dialog-container
    let container = reasonLabel.parentElement;
    while (container && container !== document.body) {
      if (container.querySelector("div.Checkbox2")) break;
      container = container.parentElement;
    }
    if (!container || container === document.body) return;

    container.querySelectorAll("div.Checkbox2").forEach(el => {
      if (!el.textContent.trim().toLowerCase().includes("append")) return;
      const hack = el.querySelector("div.TabIndexHack");
      if (hack && !hack.classList.contains("Checked")) {
        hack.click();
        showToast("☑️ 'Append to Resolution' aangevinkt!", "success");
      }
      completeDialogTicked = true;
    });
  }

  function clearPendingTick() {
    if (pendingTickTimer) { clearTimeout(pendingTickTimer); pendingTickTimer = null; }
  }

  // Alle voorwaarden behalve timing: popup open, nog niet gevinkt, lijst dicht,
  // time entry op Complete, en de beslissing zegt ja.
  function readyToTick() {
    if (alreadyTicked) return false;
    if (!findAppendCheckbox()) return false;
    if (isStatusListOpen()) return false;
    if (!entryStatusIsComplete()) return false;
    return tickDecision().tick;
  }

  function evaluateAppendTick() {
    // Status resetten zodra we op een ander ticket zitten
    if (location.href !== laatstGezienUrl) {
      laatstGezienUrl = location.href;
      alreadyTicked   = false;
      statusCommit    = null;  // keuze hoort bij het vorige ticket
    }

    const popupOpen = !!findAppendCheckbox();
    if (!popupOpen) {
      // Popup net gesloten: een volgende popup mag de keuze en het vinkje uit deze
      // niet erven. Een klik op de Complete-knop gebeurt VÓÓR de popup opent, dus
      // de keuze alleen wissen bij sluiten, niet zolang er geen popup is.
      if (popupWasOpen) { alreadyTicked = false; statusCommit = null; }
      popupWasOpen = false;
      clearPendingTick();
      return;
    }
    popupWasOpen = true;

    if (!readyToTick()) { clearPendingTick(); return; }

    // Korte bevestiging: de pagina krijgt even om te renderen, en een keuze die
    // meteen weer verandert, telt niet.
    if (pendingTickTimer) return;
    pendingTickTimer = setTimeout(() => {
      pendingTickTimer = null;
      if (!readyToTick()) return;
      const cb = findAppendCheckbox();
      const hack = cb && cb.querySelector("div.TabIndexHack");
      if (!hack) return;
      if (!hack.classList.contains("Checked")) {
        hack.click();
        showToast("☑️ 'Append to Resolution' automatisch aangevinkt!", "success");
      }
      alreadyTicked = true;
    }, TICK_CONFIRM_MS);
  }

  setInterval(() => {
    if (!document.getElementById("ln-summary-btn") || !document.getElementById("ln-polish-btn")) {
      injectSummaryButton();
    }

    // Track nieuwe iframes die Autotask dynamisch toevoegt (bijv. bij openen notitieveld)
    if (typeof _lnTrackIframe === "function") {
      document.querySelectorAll("iframe").forEach(frame => {
        if (!frame._lnTracked) {
          frame._lnTracked = true;
          _lnTrackIframe(frame);
        }
      });
    }
    if (!document.getElementById("ln-toolbar-group")) {
      injectActivityToolbarButtons();
    }
    const newtixBtn = document.getElementById("ln-newtix-btn");
    if (newtixBtn && !isNewOrEditTicketPage()) {
      newtixBtn.remove();
    } else if (!newtixBtn) {
      injectNewTicketButtons();
    }

    // Complete Ticket dialog: knoppen + auto-tick Append to Resolution
    handleCompleteTicketDialog();
    if (!document.getElementById("ln-completetix-btn")) {
      if (typeof injectCompleteTicketDialogButtons === "function") {
        injectCompleteTicketDialogButtons();
      }
    }

    evaluateAppendTick();
  }, 1500);
}

// --- Start ---
startStatusObserver();
langOverride = null;

} // end _lnObserverLoaded guard