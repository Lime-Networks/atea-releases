// ============================================================
// Lime Networks — content.ai.js
// AI calls: taaldetectie, polijsten, samenvatting
// ============================================================

async function detectLangAI(text, s) {
  // Uitgebreide lokale detectie als primaire check
  // Dit voorkomt onnodige API calls en is betrouwbaarder voor korte teksten
  const detectedLocally = detectLangLocal(text);
  if (detectedLocally.confidence === "high") return detectedLocally.lang;

  // Bij lage zekerheid: gebruik AI
  try {
    if (s.provider === "openai") {
      const res = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: { "Content-Type": "application/json", "Authorization": `Bearer ${s.openaiKey}` },
        body: JSON.stringify({ model: "gpt-4o-mini", max_tokens: 5, messages: [
          { role: "system", content: "Detect the language of the text. Reply with only: 'nl' or 'en'. Nothing else." },
          { role: "user", content: text }
        ]})
      });
      const data = await res.json();
      return data.choices?.[0]?.message?.content?.trim().toLowerCase() === "nl" ? "nl" : "en";
    } else {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-api-key": s.claudeKey, "anthropic-version": "2023-06-01", "anthropic-dangerous-direct-browser-access": "true" },
        body: JSON.stringify({ model: "claude-haiku-4-5-20251001", max_tokens: 5, system: "Detect the language of the text. Reply with only: 'nl' or 'en'. Nothing else.", messages: [{ role: "user", content: text }] })
      });
      const data = await res.json();
      return data.content?.find(b => b.type === "text")?.text?.trim().toLowerCase() === "nl" ? "nl" : "en";
    }
  } catch(e) {
    return detectedLocally.lang;
  }
}

// Robuuste lokale taaldetectie met confidence score
function detectLangLocal(text) {
  const nlWords = new Set([
    "het","een","van","niet","dat","dit","heeft","zijn","voor","met","bij","naar",
    "ook","aan","maar","door","nog","wel","geen","meer","hebben","werd","kunnen",
    "moet","zou","worden","deze","die","als","dan","om","zij","wij","hun","ons",
    "toch","want","dus","echter","daarna","vervolgens","nadat","hierna","tevens",
    "waarbij","waardoor","indien","alsmede","ik","je","ze","we","hij","haar",
    "onze","jullie","mijn","jouw","zijn","hun","dit","dat","hier","daar","nu",
    "dan","nog","al","al","wel","niet","geen","ook","zo","maar","want","omdat",
    "want","heb","had","was","werden","heeft","hebben","zal","zullen","kan","kunnen",
    "mag","mogen","moet","moeten","zou","zouden","ga","gaan","kom","komen",
    "doe","doen","maak","maken","zet","zetten","kijk","kijken","werkt","werken",
    "probleem","oplossing","klant","gebruiker","systeem",
    "netwerk","telefoon","wachtwoord","toegang","instelling","installatie","back-up","licentie"
  ]);
  const enWords = new Set([
    "the","and","for","are","but","not","you","all","can","had","her","was",
    "one","our","out","day","get","has","him","his","how","man","new","now",
    "old","see","two","way","who","boy","did","its","let","put","say","she",
    "too","use","with","that","this","have","from","they","will","been","could",
    "would","should","there","their","what","said","each","which","made","then",
    "time","look","only","come","over","also","back","after","work","first",
    "well","even","want","give","most","tell","much","keep","good","great",
    "issue","user","system","network","password","access","setting","install"
  ]);

  const words = text.toLowerCase().replace(/[^a-z\s]/g, "").split(/\s+/).filter(w => w.length > 1);
  if (words.length === 0) return { lang: "nl", confidence: "low" };

  const nlCount = words.filter(w => nlWords.has(w)).length;
  const enCount = words.filter(w => enWords.has(w)).length;
  const total = words.length;

  const nlRatio = nlCount / total;
  const enRatio = enCount / total;

  // Duidelijk Nederlands
  if (nlCount >= 2 && nlRatio > enRatio * 1.5) return { lang: "nl", confidence: "high" };
  // Duidelijk Engels
  if (enCount >= 2 && enRatio > nlRatio * 1.5) return { lang: "en", confidence: "high" };
  // Twijfelgeval — gebruik AI
  return { lang: nlCount >= enCount ? "nl" : "en", confidence: "low" };
}

async function callAIWithPrompt(text, sysPrompt) {
  const s = await loadSettings();
  if (s.provider === "openai") {
    if (!s.openaiKey) throw new Error("Geen OpenAI key");
    const res = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST", headers: { "Content-Type": "application/json", "Authorization": `Bearer ${s.openaiKey}` },
      body: JSON.stringify({ model: "gpt-4o", max_tokens: 200, messages: [{ role: "system", content: sysPrompt }, { role: "user", content: text }] })
    });
    const data = await res.json();
    if (data.error) throw new Error(data.error.message);
    return data.choices?.[0]?.message?.content || "";
  } else {
    if (!s.claudeKey) throw new Error("Geen Claude key — stel API key in via ⚙️");
    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST", headers: { "Content-Type": "application/json", "x-api-key": s.claudeKey, "anthropic-version": "2023-06-01", "anthropic-dangerous-direct-browser-access": "true" },
      body: JSON.stringify({ model: "claude-haiku-4-5-20251001", max_tokens: 200, system: sysPrompt, messages: [{ role: "user", content: text }] })
    });
    const data = await res.json();
    if (data.error) throw new Error(data.error.message);
    return data.content?.find(b => b.type === "text")?.text || "";
  }
}

async function callAI(text) {
  const s = await loadSettings();
  const stylePrompts = {
    lime_style: `Write in the natural, direct communication style of Lime Networks IT engineers:
- Short, active sentences. 'Ik heb Peter gesproken' not 'Er is contact geweest met Peter'
- Everyday Dutch/English — no corporate or overly formal words
- Use 'koppelt terug' not 'rapporteert', 'laat het weten' not 'informeert', 'hoor ik graag' not 'verneem ik gaarne'
- Keep technical terms as-is (back-up, licentie, uitrollen, tenant, proxy, SSO, AVD)
- No 'Geachte', no formal closings
- If something is resolved, say so directly: 'Probleem opgelost' not 'De situatie is naar tevredenheid afgehandeld'
- If the input is already natural and correct, make only minimal corrections. Do not rewrite for the sake of rewriting.`,
    lime_tech: `Write in the natural, direct communication style of Lime Networks IT engineers, and include relevant technical facts that are explicitly mentioned in the input:
- Short, active sentences. Everyday Dutch/English.
- Include technical details (system names, error codes, versions, configurations) ONLY if they appear in the input — never invent them
- Keep technical terms as-is (back-up, licentie, uitrollen, tenant, proxy, SSO, AVD)
- No 'Geachte', no formal closings
- Do NOT pad or expand. Do NOT add troubleshooting steps that are not in the input.`,
    leesbaar: `Write in the natural, direct communication style of Lime Networks IT engineers:
- Short, active sentences. Everyday Dutch/English.
- Keep technical terms as-is (back-up, licentie, uitrollen, tenant, proxy, SSO, AVD)
- No 'Geachte', no formal closings
- If the input is already natural and correct, make only minimal corrections.`
  };
  const custom = s.customPrompt ? `\nExtra instructions: ${s.customPrompt}` : "";
  const detectedLang = detectLangLocal(text).lang;
  const lang = langOverride || await detectLangAI(text, s);
  const isTranslation = langOverride && langOverride !== detectedLang;

  const sysPrompt = isTranslation
    ? `You are a professional MSP text translator.
TRANSLATE the following text from ${detectedLang === "nl" ? "Dutch" : "English"} to ${lang === "nl" ? "Dutch (Nederlands)" : "English"}.
Keep the same meaning, tone and style. Keep technical terms as-is (back-up, SSO, AVD, tenant, proxy).
Output ONLY the translated text — no labels, no quotes, no preamble.`
    : `You are an expert MSP time entry writer.
CRITICAL: You MUST write the output in ${lang === "nl" ? "DUTCH (Nederlands)" : "ENGLISH"}. This is non-negotiable.
Style: ${stylePrompts[s.style] || stylePrompts["leesbaar"]}
General rules: professional, client-friendly, past tense, no filler phrases.${custom}
Output ONLY the polished time entry text — no labels, no quotes, no preamble.`;

  if (s.provider === "openai") {
    if (!s.openaiKey) throw new Error("Geen ChatGPT API key ingesteld.");
    const res = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST", headers: { "Content-Type": "application/json", "Authorization": `Bearer ${s.openaiKey}` },
      body: JSON.stringify({ model: "gpt-4o", max_tokens: 1000, messages: [{ role: "system", content: sysPrompt }, { role: "user", content: text }] })
    });
    const data = await res.json();
    if (data.error) throw new Error(data.error.message);
    return data.choices?.[0]?.message?.content || "";
  } else {
    if (!s.claudeKey) throw new Error("Geen Claude API key ingesteld.");
    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST", headers: { "Content-Type": "application/json", "x-api-key": s.claudeKey, "anthropic-version": "2023-06-01", "anthropic-dangerous-direct-browser-access": "true" },
      body: JSON.stringify({ model: "claude-haiku-4-5-20251001", max_tokens: 1000, system: sysPrompt, messages: [{ role: "user", content: text }] })
    });
    const data = await res.json();
    if (data.error) throw new Error(data.error.message);
    return data.content?.find(b => b.type === "text")?.text || "";
  }
}

async function callAIForTicketDescription(text) {
  const s = await loadSettings();
  const lang = detectLangLocal(text).lang;
  const sysPrompt = `You are an expert IT support ticket writer for Lime Networks.
Detect the language of the input (Dutch or English) and write in that same language.
Rewrite the input as a clear, professional ticket description FROM THE USER'S PERSPECTIVE.
Rules:
- Describe the PROBLEM only — what is wrong, what the user experiences
- Use present tense or recent past for the issue: "Outlook start niet op", "Gebruiker kan niet inloggen"
- Do NOT add troubleshooting steps, solutions, or technician actions
- Do NOT write in technician past-tense style ("Ik heb gekeken...", "Bleek dat...")
- Keep it concise: 1-3 sentences max
- Natural, direct tone
Output ONLY the description — no labels, no quotes, no preamble.`;
  if (s.provider === "openai") {
    if (!s.openaiKey) throw new Error("Geen OpenAI key ingesteld.");
    const res = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST", headers: { "Content-Type": "application/json", "Authorization": `Bearer ${s.openaiKey}` },
      body: JSON.stringify({ model: "gpt-4o", max_tokens: 300, messages: [{ role: "system", content: sysPrompt }, { role: "user", content: text }] })
    });
    const data = await res.json();
    if (data.error) throw new Error(data.error.message);
    return data.choices?.[0]?.message?.content || "";
  } else {
    if (!s.claudeKey) throw new Error("Geen Claude API key ingesteld.");
    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST", headers: { "Content-Type": "application/json", "x-api-key": s.claudeKey, "anthropic-version": "2023-06-01", "anthropic-dangerous-direct-browser-access": "true" },
      body: JSON.stringify({ model: "claude-haiku-4-5-20251001", max_tokens: 300, system: sysPrompt, messages: [{ role: "user", content: text }] })
    });
    const data = await res.json();
    if (data.error) throw new Error(data.error.message);
    return data.content?.find(b => b.type === "text")?.text || "";
  }
}

async function callAIForKnownSolutions(problem) {
  const s = await loadSettings();
  const sysPrompt = `You are an MSP IT support knowledge assistant.
Given an IT support ticket description, return 2-3 commonly known practical solutions.
RULES:
- Only include well-known, genuinely common solutions — no invented steps
- Keep each solution to max 1 sentence
- Detect the language from the input and respond in that same language
- Return ONLY a valid JSON array of strings, e.g. ["oplossing 1", "oplossing 2"]
- If you don't know a relevant solution, return fewer items or an empty array []`;

  try {
    let raw = "";
    if (s.provider === "openai") {
      if (!s.openaiKey) throw new Error("Geen OpenAI key ingesteld.");
      const res = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: { "Content-Type": "application/json", "Authorization": `Bearer ${s.openaiKey}` },
        body: JSON.stringify({ model: "gpt-4o", max_tokens: 200,
          messages: [{ role: "system", content: sysPrompt }, { role: "user", content: problem }] })
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error.message);
      raw = data.choices?.[0]?.message?.content || "[]";
    } else {
      if (!s.claudeKey) throw new Error("Geen Claude key — stel API key in via ⚙️");
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-api-key": s.claudeKey,
          "anthropic-version": "2023-06-01", "anthropic-dangerous-direct-browser-access": "true" },
        body: JSON.stringify({ model: "claude-haiku-4-5-20251001", max_tokens: 200,
          system: sysPrompt, messages: [{ role: "user", content: problem }] })
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error.message);
      raw = data.content?.find(b => b.type === "text")?.text || "[]";
    }
    const parsed = JSON.parse(raw.replace(/```json|```/g, "").trim());
    return Array.isArray(parsed) ? parsed.filter(s => typeof s === "string" && s.length > 0) : [];
  } catch(e) {
    if (e.message.includes("JSON")) return [];
    throw e;
  }
}

async function callAIForMail(subject, ticketContext, instruction, lang) {
  const s = await loadSettings();
  const langName = lang === "nl" ? "Dutch (Nederlands)" : "English";
  const sysPrompt = `You are an expert IT support email writer for Lime Networks, a Dutch MSP.
Write a professional but natural client email in ${langName}.
Follow these style rules strictly:
- Use short, active sentences. Write 'Ik heb de server herstart' not 'Er is een herstart uitgevoerd door ons team'
- Use everyday language — avoid corporate or overly formal words
- Use 'laat het weten' not 'informeert u', 'hoor ik graag' not 'verneem ik gaarne'
- Keep technical terms as-is (back-up, licentie, uitrollen, tenant, proxy, SSO, AVD)
- If something is resolved, say so directly: 'Het probleem is opgelost.' not 'De situatie is naar tevredenheid afgehandeld.'
- Greeting: "Hallo," (Dutch) or "Hi," (English) — short and natural
- Closing: "Met vriendelijke groet," / "Kind regards," followed by a blank line for signature
- Do NOT use "Geachte" or other overly formal language
- Write like a knowledgeable colleague communicating to a client, not a formal report
- Short paragraphs, max 3-4 sentences each
Output ONLY the email body — starting with the greeting. No subject line, no labels, no preamble.`;
  const userContent = `Email subject: ${subject}\n\nTicket context:\n${ticketContext}\n\nEngineer instruction:\n${instruction || "Informeer de klant over de situatie en de ondernomen acties."}`;
  if (s.provider === "openai") {
    if (!s.openaiKey) throw new Error("Geen OpenAI key ingesteld.");
    const res = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: { "Content-Type": "application/json", "Authorization": `Bearer ${s.openaiKey}` },
      body: JSON.stringify({ model: "gpt-4o", max_tokens: 600, messages: [{ role: "system", content: sysPrompt }, { role: "user", content: userContent }] })
    });
    const data = await res.json();
    if (data.error) throw new Error(data.error.message);
    return data.choices?.[0]?.message?.content || "";
  } else {
    if (!s.claudeKey) throw new Error("Geen Claude API key ingesteld.");
    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-api-key": s.claudeKey, "anthropic-version": "2023-06-01", "anthropic-dangerous-direct-browser-access": "true" },
      body: JSON.stringify({ model: "claude-haiku-4-5-20251001", max_tokens: 600, system: sysPrompt, messages: [{ role: "user", content: userContent }] })
    });
    const data = await res.json();
    if (data.error) throw new Error(data.error.message);
    return data.content?.find(b => b.type === "text")?.text || "";
  }
}