// ============================================================
// Lime Networks — content.ai.js
// AI calls: taaldetectie, polijsten, samenvatting
// ============================================================

// --- Centrale provider-helper (voorkomt duplicatie van fetch-logica) ---
// options: { openaiModel, claudeModel } — optioneel voor afwijkende modellen (bijv. mini voor lang-detect)
async function _callProvider(s, systemPrompt, userContent, maxTokens, options = {}) {
  const openaiModel  = options.openaiModel  || "gpt-4o";
  const claudeModel  = options.claudeModel  || "claude-haiku-4-5-20251001";

  if (s.provider === "openai") {
    if (!s.openaiKey) throw new Error("Geen OpenAI API key ingesteld.");
    const res = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: { "Content-Type": "application/json", "Authorization": `Bearer ${s.openaiKey}` },
      body: JSON.stringify({
        model: openaiModel, max_tokens: maxTokens,
        messages: [{ role: "system", content: systemPrompt }, { role: "user", content: userContent }]
      })
    });
    if (!res.ok) throw new Error(`OpenAI HTTP ${res.status}`);
    const data = await res.json();
    if (data.error) throw new Error(data.error.message);
    return data.choices?.[0]?.message?.content?.trim() || "";
  } else {
    if (!s.claudeKey) throw new Error("Geen Claude API key ingesteld. Stel deze in via ⚙️");
    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": s.claudeKey,
        "anthropic-version": "2023-06-01",
        "anthropic-dangerous-direct-browser-access": "true"
      },
      body: JSON.stringify({
        model: claudeModel, max_tokens: maxTokens,
        system: systemPrompt, messages: [{ role: "user", content: userContent }]
      })
    });
    if (!res.ok) throw new Error(`Anthropic HTTP ${res.status}`);
    const data = await res.json();
    if (data.error) throw new Error(data.error.message);
    return data.content?.find(b => b.type === "text")?.text?.trim() || "";
  }
}

// --- Taaldetectie via AI (alleen bij lage lokale zekerheid) ---
async function detectLangAI(text, s) {
  const detectedLocally = detectLangLocal(text);
  if (detectedLocally.confidence === "high") return detectedLocally.lang;

  try {
    const sysPrompt = "Detect the language of the text. Reply with only: 'nl' or 'en'. Nothing else.";
    const result = await _callProvider(s, sysPrompt, text, 5, { openaiModel: "gpt-4o-mini" });
    return result.toLowerCase() === "nl" ? "nl" : "en";
  } catch(e) {
    return detectedLocally.lang;
  }
}

// --- Robuuste lokale taaldetectie met confidence score ---
function detectLangLocal(text) {
  // Nederlandse functie- en veelvoorkomende woorden (gededupliceerd).
  // Bewust NL-eigen: woorden als "de","en","op","in" staan erbij maar "de"/"in"/"on"/"is"
  // bestaan ook in Engels — die laten we weg om valse positieven te voorkomen.
  const nlWords = new Set([
    // lidwoorden + zeer frequente functiewoorden (NL-eigen vormen)
    "het","een","van","niet","dat","dit","heeft","hebben","zijn","voor","met","bij","naar",
    "ook","aan","maar","door","nog","wel","geen","meer","werd","werden","kunnen","kan",
    "moet","moeten","zou","zouden","worden","deze","die","als","dan","om","zij","wij","hun",
    "ons","onze","jullie","mijn","jouw","haar",
    // voegwoorden / bijwoorden
    "toch","want","dus","echter","daarna","vervolgens","nadat","hierna","tevens",
    "waarbij","waardoor","indien","alsmede","omdat","zodat","terwijl","hoewel",
    // persoonsvormen
    "ik","je","ze","we","hij","heb","had","zal","zullen","mag","mogen",
    // werkwoorden (infinitief + vervoeging)
    "ga","gaan","kom","komen","doe","doen","maak","maken","zet","zetten",
    "kijk","kijken","werkt","werken","gedaan","gemaakt","gezien","gebeld",
    // context-specifiek (MSP / Lime)
    "probleem","oplossing","klant","gebruiker","systeem","netwerk","telefoon",
    "wachtwoord","toegang","instelling","installatie","licentie","ticket","melding",
    "hier","daar","nu","zo"
  ]);
  const enWords = new Set([
    // lidwoorden + functiewoorden
    "the","and","for","are","but","not","you","all","can","had","her","was",
    "one","our","out","day","get","has","him","his","how","man","new","now",
    "old","see","two","way","who","boy","did","its","let","put","say","she",
    "too","use","with","that","this","have","from","they","will","been","could",
    "would","should","there","their","what","said","each","which","made","then",
    // context
    "time","look","only","come","over","also","back","after","work","first",
    "well","even","want","give","most","tell","much","keep","good","great",
    "issue","user","system","network","password","access","setting","install",
    "because","while","although","customer","ticket","problem","solution","request"
  ]);

  const words = text.toLowerCase().replace(/[^a-z\s]/g, "").split(/\s+/).filter(w => w.length > 1);
  if (words.length === 0) return { lang: "nl", confidence: "low" };

  const nlCount = words.filter(w => nlWords.has(w)).length;
  const enCount = words.filter(w => enWords.has(w)).length;
  const total   = words.length;
  const nlRatio = nlCount / total;
  const enRatio = enCount / total;

  if (nlCount >= 2 && nlRatio > enRatio * 1.5) return { lang: "nl", confidence: "high" };
  if (enCount >= 2 && enRatio > nlRatio * 1.5) return { lang: "en", confidence: "high" };
  return { lang: nlCount >= enCount ? "nl" : "en", confidence: "low" };
}

// --- Centrale taal-resolver: bepaal de output-taal vóór elke AI-call ---
// Volgorde: handmatige override → lokale detect (high confidence) → AI fallback (mini)
async function resolveOutputLang(input, s) {
  if (typeof langOverride !== "undefined" && langOverride) return langOverride;
  const local = detectLangLocal(input || "");
  if (local.confidence === "high") return local.lang;
  try { return await detectLangAI(input || "", s); } catch(e) { return local.lang; }
}

// --- Taal-directive blok: hard ingestelde output-taal in de prompt ---
function langDirective(lang) {
  return lang === "en"
    ? `OUTPUT LANGUAGE: ENGLISH
- Write the output strictly in English. Do NOT use Dutch words or phrases.
- Technical terms stay as-is (back-up, SSO, tenant, proxy, AVD).
- Do NOT translate proper nouns, system names, or quoted text.`
    : `OUTPUT LANGUAGE: NEDERLANDS
- Schrijf de output strikt in het Nederlands. Gebruik geen Engelse zinnen.
- Technische termen blijven onveranderd (back-up, SSO, tenant, proxy, AVD).
- Vertaal geen eigennamen, systeemnamen of geciteerde tekst.`;
}

// --- Algemene AI-call met gegeven systeem-prompt (voor samenvatting, titel, etc.) ---
async function callAIWithPrompt(text, sysPrompt) {
  const s = await loadSettings();
  return _callProvider(s, sysPrompt, text, 200);
}

// --- Hoofd-polish functie ---
// Stijlregels zijn per taal apart — geen tweetalige voorbeelden in één call,
// dat voorkomt dat de LLM door Nederlandse cues naar Nederlands wordt geduwd.
const STYLE_RULES_BY_LANG = {
  nl: {
    lime_style: `- Korte, actieve zinnen in eerste persoon waar relevant ("Ik heb Peter gesproken" — NIET passief "Er is contact geweest met Peter")
- Alledaagse taal — geen corporate of overmatig formele woorden
- Natuurlijke werkwoorden voor statusupdates ("koppelt terug" niet "rapporteert"; "laat het weten" niet "informeert"; "hoor ik graag" niet "verneem ik gaarne")
- Technische termen blijven onveranderd (back-up, licentie, uitrollen, tenant, proxy, SSO, AVD)
- Geen formele aanhef zoals "Geachte", geen formele afsluitingen
- Resultaten direct benoemen ("Probleem opgelost" — NIET "De situatie is naar tevredenheid afgehandeld")
- Als de input al natuurlijk en correct is, alleen minimale correcties. Niet herschrijven om het herschrijven.`,
    lime_tech: `- Korte, actieve zinnen. Alledaagse taal.
- Technische details (systeemnamen, foutcodes, versies, configuraties) ALLEEN opnemen als ze in de input staan — nooit verzinnen
- Technische termen blijven onveranderd (back-up, licentie, uitrollen, tenant, proxy, SSO, AVD)
- Geen formele aanhef of afsluitingen
- NIET uitbreiden of opvullen. GEEN troubleshooting-stappen toevoegen die niet in de input staan.`,
    leesbaar: `- Korte, actieve zinnen. Alledaagse taal.
- Technische termen blijven onveranderd (back-up, licentie, uitrollen, tenant, proxy, SSO, AVD)
- Geen formele aanhef of afsluitingen
- Als de input al natuurlijk en correct is, alleen minimale correcties.`
  },
  en: {
    lime_style: `- Short, active sentences in first person when relevant ("I called Peter" — NOT passive "Contact was made with Peter")
- Everyday language — no corporate or overly formal words
- Natural verbs for status updates ("will get back" not "will report"; "let me know" not "inform me"; "look forward to hearing" not "await your reply")
- Keep technical terms as-is (back-up, license, roll out, tenant, proxy, SSO, AVD)
- No formal greetings like "Dear Sir/Madam", no formal closings
- State outcomes directly ("Issue resolved" — NOT "The situation has been handled satisfactorily")
- If the input is already natural and correct, make only minimal corrections. Do not rewrite for the sake of rewriting.`,
    lime_tech: `- Short, active sentences. Everyday language.
- Include technical details (system names, error codes, versions, configurations) ONLY if they appear in the input — never invent them
- Keep technical terms as-is (back-up, license, roll out, tenant, proxy, SSO, AVD)
- No formal greetings or closings
- Do NOT pad or expand. Do NOT add troubleshooting steps that are not in the input.`,
    leesbaar: `- Short, active sentences. Everyday language.
- Keep technical terms as-is (back-up, license, roll out, tenant, proxy, SSO, AVD)
- No formal greetings or closings
- If the input is already natural and correct, make only minimal corrections.`
  }
};

async function callAI(text) {
  const s = await loadSettings();
  const custom = s.customPrompt ? `\nExtra instructions: ${s.customPrompt}` : "";

  // Bij handmatige override: check eerst of vertaling nodig is (input ≠ override)
  if (langOverride) {
    const detectedLang = detectLangLocal(text).lang;
    if (langOverride !== detectedLang) {
      const sysPrompt = `You are a professional MSP text translator.
TRANSLATE the following text from ${detectedLang === "nl" ? "Dutch" : "English"} to ${langOverride === "nl" ? "Dutch (Nederlands)" : "English"}.
Keep the same meaning, tone and style. Keep technical terms as-is (back-up, SSO, AVD, tenant, proxy).
Output ONLY the translated text — no labels, no quotes, no preamble.`;
      return _callProvider(s, sysPrompt, text, 1000);
    }
  }

  // Anders: taal vooraf hard vastpinnen, taal-pure stijlregels gebruiken
  const lang = await resolveOutputLang(text, s);
  const styleRules = (STYLE_RULES_BY_LANG[lang] || STYLE_RULES_BY_LANG.nl)[s.style]
    || (STYLE_RULES_BY_LANG[lang] || STYLE_RULES_BY_LANG.nl).leesbaar;

  const sysPrompt = `You are an expert MSP time entry writer.

${langDirective(lang)}

Style:
${styleRules}

General rules: professional, client-friendly, past tense, no filler phrases.${custom}

Output ONLY the polished time entry text — no labels, no quotes, no preamble.`;
  return _callProvider(s, sysPrompt, text, 1000);
}

// --- Ticket description polijsten (derde-persoon, probleemgericht) ---
async function callAIForTicketDescription(text) {
  const s = await loadSettings();
  const lang = await resolveOutputLang(text, s);
  const thirdPersonExamples = lang === "en"
    ? `- Use "User", "Customer", "The employee", or describe the situation directly: "Outlook does not start"
- Examples of trigger events: "Outlook stopped working after the update"`
    : `- Gebruik "Gebruiker", "Klant", "De medewerker", of beschrijf de situatie direct: "Outlook start niet op"
- Voorbeelden van trigger-events: "Outlook werkt niet meer na de update"`;

  const sysPrompt = `You are an expert IT support ticket writer for Lime Networks.

${langDirective(lang)}

Rewrite the input as a neutral, professional ticket description that describes the problem.
Rules:
- Write in THIRD PERSON — describe what the user/customer experiences. Never use first person ("ik"/"wij"/"I"/"we")
${thirdPersonExamples}
- Describe the PROBLEM and symptoms only — no solutions, no troubleshooting steps, no technician actions
- If the input mentions a solution or fix, ignore it — only describe what was broken/wrong
- Present tense for ongoing issues, past tense only for the trigger event
- Keep it concise: 2-3 sentences max. Include relevant context if present (what app, what action, what error)
- Professional but natural tone
Output ONLY the description — no labels, no quotes, no preamble.`;
  return _callProvider(s, sysPrompt, text, 300);
}

// --- Bekende oplossingen ophalen (JSON-array) ---
async function callAIForKnownSolutions(problem) {
  const s = await loadSettings();
  const lang = await resolveOutputLang(problem, s);
  const sysPrompt = `You are an MSP IT support knowledge assistant.

${langDirective(lang)}

Given an IT support ticket description, return 2-3 commonly known practical solutions.
RULES:
- Only include well-known, genuinely common solutions — no invented steps
- Keep each solution to max 1 sentence
- Return ONLY a valid JSON array of strings, e.g. ${lang === "en" ? `["solution 1", "solution 2"]` : `["oplossing 1", "oplossing 2"]`}
- If you don't know a relevant solution, return fewer items or an empty array []`;

  try {
    const raw    = await _callProvider(s, sysPrompt, problem, 200);
    const parsed = JSON.parse(raw.replace(/```json|```/g, "").trim());
    return Array.isArray(parsed) ? parsed.filter(s => typeof s === "string" && s.length > 0) : [];
  } catch(e) {
    if (e.message?.includes("JSON")) return [];
    throw e;
  }
}

// --- Mail draften ---
async function callAIForMail(subject, ticketContext, instruction, lang) {
  const s = await loadSettings();
  const styleRules = lang === "en"
    ? `- Use short, active sentences. Write "I restarted the server" not "A restart was performed by our team"
- Use everyday language — avoid corporate or overly formal words
- Use "let me know" not "please inform", "looking forward to hearing" not "awaiting your reply"
- Keep technical terms as-is (back-up, license, roll out, tenant, proxy, SSO, AVD)
- If something is resolved, say so directly: "The issue is resolved." not "The situation has been handled satisfactorily."
- Greeting: "Hi," — short and natural
- Closing: "Kind regards," followed by a blank line for signature
- Do NOT use "Dear Sir/Madam" or other overly formal language`
    : `- Korte, actieve zinnen. Schrijf "Ik heb de server herstart" niet "Er is een herstart uitgevoerd door ons team"
- Alledaagse taal — vermijd corporate of overmatig formele woorden
- Gebruik "laat het weten" niet "informeert u", "hoor ik graag" niet "verneem ik gaarne"
- Technische termen blijven onveranderd (back-up, licentie, uitrollen, tenant, proxy, SSO, AVD)
- Als iets opgelost is, zeg het direct: "Het probleem is opgelost." niet "De situatie is naar tevredenheid afgehandeld."
- Aanhef: "Hallo," — kort en natuurlijk
- Afsluiting: "Met vriendelijke groet," gevolgd door een lege regel voor de handtekening
- GEEN "Geachte" of andere overmatig formele taal`;

  const defaultInstruction = lang === "en"
    ? "Inform the client about the situation and the actions taken."
    : "Informeer de klant over de situatie en de ondernomen acties.";

  const sysPrompt = `You are an expert IT support email writer for Lime Networks, a Dutch MSP.

${langDirective(lang)}

Write a professional but natural client email. Follow these style rules strictly:
${styleRules}
- Write like a knowledgeable colleague communicating to a client, not a formal report
- Short paragraphs, max 3-4 sentences each
Output ONLY the email body — starting with the greeting. No subject line, no labels, no preamble.`;

  const userContent = `Email subject: ${subject}\n\nTicket context:\n${ticketContext}\n\nEngineer instruction:\n${instruction || defaultInstruction}`;
  return _callProvider(s, sysPrompt, userContent, 600);
}
