// ============================================================
// Lime Networks — content.mail.js
// Mail drafter modal + snelkoppeling invoegen
// ============================================================

// --- Snelkoppeling invoegen — probeert actief veld, daarna klembord ---
function insertSnippet(text) {
  // Hulpfunctie: tekst achteraan invoegen in een iframe-body
  function insertInIframe(win, body) {
    body.focus();
    const existing = body.innerText?.trim();
    const range = win.document.createRange();
    range.selectNodeContents(body);
    range.collapse(false);
    const sel = win.getSelection();
    sel.removeAllRanges();
    sel.addRange(range);
    win.document.execCommand("insertText", false, (existing ? "\n" : "") + text);
  }
  // Hulpfunctie: tekst achteraan invoegen in een contenteditable element
  function insertInEditable(el) {
    el.focus();
    const existing = el.innerText?.trim();
    const range = document.createRange();
    range.selectNodeContents(el);
    range.collapse(false);
    const sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(range);
    document.execCommand("insertText", false, (existing ? "\n" : "") + text);
  }
  // Hulpfunctie: tekst invoegen in een textarea op cursorpositie
  function insertInTextarea(el) {
    const pos = el.selectionEnd ?? el.value.length;
    const prefix = pos > 0 && el.value.slice(pos - 1) !== "\n" ? "\n" : "";
    el.value = el.value.slice(0, pos) + prefix + text + el.value.slice(pos);
    el.dispatchEvent(new Event("input",  { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }

  // 1. Summary Notes frame (meest specifiek)
  if (window._lnSummaryNotesFrame) {
    try {
      const win  = window._lnSummaryNotesFrame.contentWindow;
      const body = win.document.body;
      if (body?.isContentEditable) {
        insertInIframe(win, body);
        showToast("⚡ Snelkoppeling ingevoegd!", "success");
        return;
      }
    } catch(e) {}
  }
  // 2. Laatst gefocust veld (toolbar-knoppen of gewone notes)
  if (window._lnLastEditTarget) {
    try {
      const t = window._lnLastEditTarget;
      if (t.method === "iframe-all"         && t.body && t.win) { insertInIframe(t.win, t.body); showToast("⚡ Snelkoppeling ingevoegd!", "success"); return; }
      if (t.method === "contenteditable-all" && t.el)            { insertInEditable(t.el);         showToast("⚡ Snelkoppeling ingevoegd!", "success"); return; }
      if (t.method === "textarea"            && t.el)            { insertInTextarea(t.el);          showToast("⚡ Snelkoppeling ingevoegd!", "success"); return; }
    } catch(e) {}
  }
  // 3. Laatste redmiddel: klembord
  navigator.clipboard.writeText(text).catch(() => {});
  showToast("📋 Geen actief veld gevonden — gekopieerd naar klembord", "info");
}

// --- Internal Notes veld opzoeken ---
function findInternalNotesField() {
  // Zoek via het "Internal Notes" label (meest betrouwbaar)
  let internalLabelContainer = null;
  document.querySelectorAll("span.PrimaryText").forEach(el => {
    if (!internalLabelContainer && el.textContent.trim() === "Internal Notes") {
      internalLabelContainer = el.closest(".LabelContainer1");
    }
  });
  if (internalLabelContainer) {
    const fieldArea = internalLabelContainer.parentElement;
    if (fieldArea) {
      for (const frame of fieldArea.querySelectorAll("iframe")) {
        try {
          const body = frame.contentDocument?.body;
          if (body?.isContentEditable) return { el: body, doc: frame.contentDocument, win: frame.contentWindow };
        } catch(e) {}
      }
      for (const el of fieldArea.querySelectorAll("[contenteditable='true']")) {
        if (el.offsetHeight > 40) return { el, doc: document, win: window };
      }
    }
  }
  // Fallback via isInternalNotesField detectie
  for (const frame of document.querySelectorAll("iframe")) {
    try {
      if (!isInternalNotesField(frame)) continue;
      const body = frame.contentDocument?.body;
      if (body?.isContentEditable) return { el: body, doc: frame.contentDocument, win: frame.contentWindow };
    } catch(e) {}
  }
  return null;
}

// --- Tekst plakken in Internal Notes ---
function pasteToInternalNotes(text) {
  const field = findInternalNotesField();
  if (!field) return false;
  const { el, doc, win } = field;
  el.focus();
  try {
    const range = doc.createRange();
    range.selectNodeContents(el);
    const sel = win.getSelection();
    sel.removeAllRanges();
    sel.addRange(range);
    doc.execCommand("insertText", false, text);
  } catch(e) {
    el.innerText = text;
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }
  return true;
}

// --- Mail modal tonen ---
function showMailModal() {
  document.getElementById("ln-mail-modal")?.remove();

  // Ticket metadata ophalen
  const meta = (typeof readTicketMetadata === "function") ? readTicketMetadata() : { title: null, ticketNr: null };
  const subject = [meta.ticketNr, meta.title].filter(Boolean).join(" - ");

  // Ticket context ophalen (alleen niet-interne notes)
  const { ticketTitle, existingNotes } = getTicketContext();
  const contextText = existingNotes.length > 0
    ? existingNotes.slice(0, 5).map((n, i) => `${i + 1}. ${n.substring(0, 300)}`).join("\n")
    : (ticketTitle || "Geen notes gevonden");

  // Overlay
  const overlay = document.createElement("div");
  overlay.id = "ln-mail-modal";
  Object.assign(overlay.style, {
    position: "fixed", inset: "0", zIndex: "99999999",
    background: "rgba(0,0,0,0.65)", display: "flex",
    alignItems: "center", justifyContent: "center",
    fontFamily: "Segoe UI, system-ui, sans-serif"
  });

  const modal = document.createElement("div");
  Object.assign(modal.style, {
    background: "#1a2233", border: "1.5px solid #84cc16",
    borderRadius: "12px", width: "560px", maxWidth: "calc(100vw - 40px)",
    maxHeight: "calc(100vh - 40px)", overflow: "hidden",
    display: "flex", flexDirection: "column",
    boxShadow: "0 8px 40px rgba(0,0,0,0.6)"
  });

  // esc() is gedefinieerd in content.polish.js (laadt eerder) — volledige escape van & < > " '
  const safeSubject = esc(subject);
  const safeContext = esc(contextText);

  modal.innerHTML = `
    <div style="display:flex;align-items:center;justify-content:space-between;padding:16px 20px;border-bottom:1px solid #2e3a50;flex-shrink:0;">
      <span style="font-size:15px;font-weight:700;color:#e5e7eb;">&#x2709;&#xFE0F; Mail draften</span>
      <span id="ln-mail-close" style="cursor:pointer;font-size:22px;color:#6b7280;line-height:1;padding:2px 6px;">&times;</span>
    </div>
    <div style="overflow-y:auto;padding:16px 20px;display:flex;flex-direction:column;gap:14px;">
      <div>
        <label style="font-size:11px;font-weight:700;color:#84cc16;text-transform:uppercase;letter-spacing:0.5px;display:block;margin-bottom:5px;">Onderwerp</label>
        <input id="ln-mail-subject" type="text" value="${safeSubject}"
          style="width:100%;box-sizing:border-box;background:#252d3d;border:1px solid #3d4e6b;border-radius:6px;
          padding:8px 10px;color:#e5e7eb;font-size:13px;outline:none;
          font-family:Segoe UI,system-ui,sans-serif;" />
      </div>
      <div>
        <label style="font-size:11px;font-weight:700;color:#84cc16;text-transform:uppercase;letter-spacing:0.5px;display:block;margin-bottom:5px;">Ticket context <span style="color:#4b5563;font-weight:400;text-transform:none;">(automatisch, alleen publieke notes)</span></label>
        <div style="background:#0f1620;border:1px solid #2e3a50;border-radius:6px;padding:8px 10px;
          color:#6b7280;font-size:12px;line-height:1.5;max-height:80px;overflow-y:auto;white-space:pre-wrap;">${safeContext}</div>
      </div>
      <div>
        <label style="font-size:11px;font-weight:700;color:#84cc16;text-transform:uppercase;letter-spacing:0.5px;display:block;margin-bottom:5px;">Jouw instructie / aanvulling</label>
        <textarea id="ln-mail-instruction"
          placeholder="Bijv: Klant informeren dat we morgen terugkomen. Benoem dat het netwerk stabiel is maar we nog één check doen."
          style="width:100%;box-sizing:border-box;background:#252d3d;border:1px solid #3d4e6b;border-radius:6px;
          padding:8px 10px;color:#e5e7eb;font-size:13px;line-height:1.5;resize:vertical;min-height:72px;
          outline:none;font-family:Segoe UI,system-ui,sans-serif;"></textarea>
      </div>
      <div style="display:flex;align-items:center;justify-content:space-between;">
        <div style="display:flex;align-items:center;gap:8px;">
          <span style="font-size:11px;color:#6b7280;">Taal:</span>
          <button id="ln-mail-lang"
            style="background:#252d3d;border:1px solid #3d4e6b;border-radius:6px;
            padding:5px 12px;color:#e5e7eb;font-size:12px;cursor:pointer;">&#x1F1F3;&#x1F1F1; NL</button>
        </div>
        <button id="ln-mail-generate"
          style="background:#84cc16;border:none;border-radius:6px;padding:9px 20px;
          color:#0f1117;font-size:13px;font-weight:700;cursor:pointer;">&#x2709;&#xFE0F; Genereer</button>
      </div>
      <div id="ln-mail-preview-section" style="display:none;flex-direction:column;gap:8px;">
        <label style="font-size:11px;font-weight:700;color:#84cc16;text-transform:uppercase;letter-spacing:0.5px;display:block;">Mail draft</label>
        <textarea id="ln-mail-preview"
          style="width:100%;box-sizing:border-box;background:#252d3d;border:1px solid #3d4e6b;border-radius:6px;
          padding:8px 10px;color:#e5e7eb;font-size:13px;line-height:1.6;resize:vertical;min-height:180px;
          outline:none;font-family:Segoe UI,system-ui,sans-serif;"></textarea>
        <div style="display:flex;gap:8px;justify-content:flex-end;">
          <button id="ln-mail-copy"
            style="background:#252d3d;border:1px solid #3d4e6b;border-radius:6px;padding:7px 14px;
            color:#e5e7eb;font-size:12px;font-weight:700;cursor:pointer;">&#x1F4CB; Kopi&#235;ren</button>
          <button id="ln-mail-paste"
            style="background:#252d3d;border:1px solid #84cc16;border-radius:6px;padding:7px 14px;
            color:#84cc16;font-size:12px;font-weight:700;cursor:pointer;">&#x1F4E5; Plakken in Internal Notes</button>
        </div>
      </div>
    </div>
  `;

  overlay.appendChild(modal);
  document.body.appendChild(overlay);

  // Taal toggle (NL → EN → Auto → NL)
  const langBtn = modal.querySelector("#ln-mail-lang");
  let mailLang = "nl";
  langBtn.addEventListener("click", () => {
    if (mailLang === "nl") { mailLang = "en"; langBtn.innerHTML = "&#x1F1EC;&#x1F1E7; EN"; }
    else if (mailLang === "en") { mailLang = "auto"; langBtn.innerHTML = "&#x1F310; Auto"; }
    else { mailLang = "nl"; langBtn.innerHTML = "&#x1F1F3;&#x1F1F1; NL"; }
  });

  // Sluiten
  modal.querySelector("#ln-mail-close").addEventListener("click", () => overlay.remove());
  overlay.addEventListener("click", (e) => { if (e.target === overlay) overlay.remove(); });

  // Genereer
  modal.querySelector("#ln-mail-generate").addEventListener("click", async () => {
    const subjectVal = modal.querySelector("#ln-mail-subject").value.trim();
    const instructionVal = modal.querySelector("#ln-mail-instruction").value.trim();
    const generateBtn = modal.querySelector("#ln-mail-generate");
    const previewSection = modal.querySelector("#ln-mail-preview-section");
    const previewArea = modal.querySelector("#ln-mail-preview");

    generateBtn.textContent = "⏳ Bezig...";
    generateBtn.disabled = true;
    try {
      let lang = mailLang;
      if (lang === "auto") {
        const combined = [subjectVal, contextText, instructionVal].join(" ");
        lang = detectLangLocal(combined).lang;
      }
      const draft = await callAIForMail(subjectVal, contextText, instructionVal, lang);
      previewArea.value = `Onderwerp: ${subjectVal}\n\n${draft}`;
      previewSection.style.display = "flex";
      previewArea.focus();
    } catch(e) {
      showToast("❌ Mail genereren mislukt: " + e.message, "error");
    } finally {
      generateBtn.textContent = "✉️ Genereer";
      generateBtn.disabled = false;
    }
  });

  // Kopiëren
  modal.querySelector("#ln-mail-copy").addEventListener("click", async () => {
    const text = modal.querySelector("#ln-mail-preview").value;
    try {
      await navigator.clipboard.writeText(text);
      showToast("📋 Gekopieerd naar klembord!", "success");
    } catch(e) {
      showToast("❌ Kopiëren mislukt", "error");
    }
  });

  // Plakken in Internal Notes
  modal.querySelector("#ln-mail-paste").addEventListener("click", () => {
    const text = modal.querySelector("#ln-mail-preview").value;
    const ok = pasteToInternalNotes(text);
    if (ok) {
      showToast("📥 Mail geplakt in Internal Notes!", "success");
      overlay.remove();
    } else {
      showToast("⚠️ Internal Notes veld niet gevonden — gebruik Kopiëren", "warning");
    }
  });

  // Focus op instructieveld
  setTimeout(() => modal.querySelector("#ln-mail-instruction")?.focus(), 100);
}
