// ============================================================
// Lime Networks — content.security.js
// Detectie van wachtwoorden/keys/tokens in tekst.
// Puur lokaal: geen opslag, geen verzending — alleen patroonherkenning.
// ============================================================

// Herkent expliciete labels (wachtwoord/key/token gevolgd door een waarde) en
// bekende sleutel-formaten. Dit is GEEN garantie — een engineer kan een wachtwoord
// zonder label typen en dat glipt erdoorheen. Het vangt de voor de hand liggende
// gevallen, als aanvulling op de instructie om dit nooit in een ticket te zetten.
const LN_SENSITIVE_PATTERNS = [
  { type: "wachtwoord",        re: /\b(wachtwoord|password|paswoord|pass|pwd)\s*[:=]\s*\S{3,}/i },
  { type: "pincode",           re: /\b(pincode|pin[\s-]?code|pin)\s*[:=]\s*\d{3,}/i },
  { type: "api-key",           re: /\b(api[\s_-]?key|apikey|client[\s_-]?secret|secret[\s_-]?key)\s*[:=]\s*\S{6,}/i },
  { type: "token",             re: /\b(bearer\s+token|access[\s_-]?token|auth[\s_-]?token)\s*[:=]?\s*\S{10,}/i },
  { type: "aws-key",           re: /\bAKIA[0-9A-Z]{16}\b/ },
  { type: "github-token",      re: /\bgh[pousr]_[A-Za-z0-9]{36,}\b/ },
  { type: "slack-token",       re: /\bxox[baprs]-[A-Za-z0-9-]{10,}\b/ },
  { type: "jwt",                re: /\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b/ },
  { type: "private-key",       re: /-----BEGIN[ A-Z]*PRIVATE KEY-----/ },
  { type: "connection-string", re: /:\/\/[^:\s/]+:[^@\s/]+@/ }
];

// Geeft per regel het eerste match-type terug (max 1 per regel is genoeg signaal —
// dit hoeft geen uitputtende lijst te zijn, alleen genoeg om te blokkeren/waarschuwen).
function detectSensitiveData(text) {
  if (!text) return [];
  const hits = [];
  const lines = String(text).split("\n");
  lines.forEach((line, i) => {
    for (const p of LN_SENSITIVE_PATTERNS) {
      if (p.re.test(line)) {
        hits.push({ type: p.type, line: i + 1 });
        break;
      }
    }
  });
  return hits;
}

// Voor tekst die ATEA alleen toont en niet verstuurt, zoals zoekresultaten uit
// ITGlue: de regel vanaf het gevoelige deel weglaten en de rest wel tonen.
// Zelfde aanpak als 'Bouw Antwoord' in de N8N-zoekflow; dit is het vangnet
// aan deze kant.
function redactSensitive(text) {
  if (!text) return "";
  return String(text).split("\n").map(line => {
    let cut = -1;
    for (const p of LN_SENSITIVE_PATTERNS) {
      const m = line.match(p.re);
      if (m && (cut < 0 || m.index < cut)) cut = m.index;
    }
    return cut < 0 ? line : (line.slice(0, cut).trimEnd() + " [weggelaten: mogelijk gevoelige data]").trim();
  }).join("\n");
}

// Niet-blokkerende waarschuwing voor de bestaande polijst-actie. showToast komt
// uit content.polish.js, dat eerder laadt.
function warnIfSensitive(text) {
  const hits = detectSensitiveData(text);
  if (hits.length === 0) return;
  showToast("⚠️ Mogelijk gevoelige data gedetecteerd (bv. wachtwoord/key) — controleer voordat je opslaat.", "warning");
}
