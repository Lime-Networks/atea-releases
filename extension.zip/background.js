// --- Genereer icoon via canvas (groene achtergrond + zwarte L) ---
function setIcon() {
  const canvas = new OffscreenCanvas(128, 128);
  const ctx = canvas.getContext("2d");
  const r = 24;
  ctx.fillStyle = "#84cc16";
  ctx.beginPath();
  ctx.moveTo(r, 0); ctx.lineTo(128 - r, 0);
  ctx.quadraticCurveTo(128, 0, 128, r);
  ctx.lineTo(128, 128 - r);
  ctx.quadraticCurveTo(128, 128, 128 - r, 128);
  ctx.lineTo(r, 128);
  ctx.quadraticCurveTo(0, 128, 0, 128 - r);
  ctx.lineTo(0, r);
  ctx.quadraticCurveTo(0, 0, r, 0);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = "#0f1117";
  ctx.font = "900 88px 'Segoe UI', system-ui, sans-serif";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText("L", 64, 68);
  chrome.action.setIcon({ imageData: ctx.getImageData(0, 0, 128, 128) });
}

chrome.runtime.onInstalled.addListener(() => {
  setIcon();
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: "ln-polish",
      title: "✨ Polijsten met Lime Networks AI (Ctrl+Shift+L)",
      contexts: ["editable", "selection"]
    });
  });
});

chrome.runtime.onStartup.addListener(() => setIcon());

const CONTENT_FILES = [
  "content.crypto.js",
  "content.ai.js",
  "content.db.js",
  "content.polish.js",
  "content.observer.js"
];

chrome.commands.onCommand.addListener((command) => {
  if (command === "polish-selection") {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (!tabs[0]) return;
      chrome.scripting.executeScript({
        target: { tabId: tabs[0].id, allFrames: true },
        files: CONTENT_FILES
      }).then(() => {
        setTimeout(() => {
          chrome.tabs.sendMessage(tabs[0].id, { action: "polishSelection" }, () => { void chrome.runtime.lastError; });
        }, 150);
      }).catch(() => {
        chrome.tabs.sendMessage(tabs[0].id, { action: "polishSelection" }, () => { void chrome.runtime.lastError; });
      });
    });
  }
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === "complete" && tab.url?.includes("autotask.net")) {
    // Alleen injecteren als content scripts nog niet actief zijn (bijv. na SPA-navigatie)
    chrome.scripting.executeScript({
      target: { tabId, allFrames: false },
      func: () => typeof window._lnObserverLoaded !== "undefined"
    }).then(([result]) => {
      if (!result?.result) {
        chrome.scripting.executeScript({ target: { tabId, allFrames: true }, files: CONTENT_FILES }).catch(() => {});
      }
    }).catch(() => {});
  }
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId !== "ln-polish") return;
  chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, files: CONTENT_FILES })
    .then(() => {
      setTimeout(() => {
        chrome.tabs.sendMessage(tab.id, { action: "polishSelection" }, () => { void chrome.runtime.lastError; });
        chrome.webNavigation?.getAllFrames({ tabId: tab.id }, (frames) => {
          if (!frames) return;
          frames.forEach(frame => {
            if (frame.frameId !== 0) {
              chrome.tabs.sendMessage(tab.id, { action: "polishSelection" }, { frameId: frame.frameId }, () => { void chrome.runtime.lastError; });
            }
          });
        });
      }, 150);
    }).catch(() => {
      chrome.tabs.sendMessage(tab.id, { action: "polishSelection" }, () => { void chrome.runtime.lastError; });
    });
});