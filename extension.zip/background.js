// --- Genereer icoon via canvas (groene achtergrond + zwarte L) ---
function setIcon() {
  const canvas = new OffscreenCanvas(128, 128);
  const ctx = canvas.getContext("2d");
  const r = 24;
  ctx.fillStyle = "#84cc16";
  ctx.beginPath();
  ctx.moveTo(r, 0); ctx.lineTo(128 - r, 0);
  ctx.quadraticCurveTo(128, 0, 128, r);
  ctx.lineTo(128, 128 - r);
  ctx.quadraticCurveTo(128, 128, 128 - r, 128);
  ctx.lineTo(r, 128);
  ctx.quadraticCurveTo(0, 128, 0, 128 - r);
  ctx.lineTo(0, r);
  ctx.quadraticCurveTo(0, 0, r, 0);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = "#0f1117";
  ctx.font = "900 88px 'Segoe UI', system-ui, sans-serif";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText("L", 64, 68);
  chrome.action.setIcon({ imageData: ctx.getImageData(0, 0, 128, 128) });
}

chrome.runtime.onInstalled.addListener(() => {
  setIcon();
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: "ln-polish",
      title: "✨ Polijsten met Lime Networks AI (Ctrl+Shift+L)",
      contexts: ["editable", "selection"],
      // Beperk het menu-item tot Autotask. Zonder dit verscheen het op elke host in
      // host_permissions (claude.ai, api.anthropic.com, ...) waar het of inert was of
      // — op claude.ai — de chat-composer als notitieveld behandelde.
      documentUrlPatterns: ["https://*.autotask.net/*"]
    });
  });
});

chrome.runtime.onStartup.addListener(() => setIcon());

const CONTENT_FILES = [
  "content.crypto.js",
  "content.ai.js",
  "content.db.js",
  "content.polish.js",
  "content.mail.js",
  "content.observer.js"
];

chrome.commands.onCommand.addListener((command) => {
  if (command === "polish-selection") {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (!tabs[0]) return;
      // Alleen op Autotask injecteren. De sneltoets werkt browserbreed, dus zonder deze
      // check injecteerde Ctrl+Shift+L de volledige bundel op elke host in
      // host_permissions — inclusief claude.ai, waar getSelectedText() de chat-composer
      // oppikte, naar de AI stuurde en overschreef.
      if (!isAutotaskUrl(tabs[0].url)) return;
      chrome.scripting.executeScript({
        target: { tabId: tabs[0].id, allFrames: true },
        files: CONTENT_FILES
      }).then(() => {
        setTimeout(() => {
          chrome.tabs.sendMessage(tabs[0].id, { action: "polishSelection" }, () => { void chrome.runtime.lastError; });
        }, 150);
      }).catch(() => {
        chrome.tabs.sendMessage(tabs[0].id, { action: "polishSelection" }, () => { void chrome.runtime.lastError; });
      });
    });
  }
});

// Strikte hostname check — voorkomt dat URLs als https://attacker.com/?fake=autotask.net
// een match opleveren. host_permissions gate't injectie, dit is defense-in-depth.
function isAutotaskUrl(url) {
  try {
    const h = new URL(url).hostname;
    return h === "autotask.net" || h.endsWith(".autotask.net");
  } catch { return false; }
}

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === "complete" && tab.url && isAutotaskUrl(tab.url)) {
    // Alleen injecteren als content scripts nog niet actief zijn (bijv. na SPA-navigatie)
    chrome.scripting.executeScript({
      target: { tabId, allFrames: false },
      func: () => typeof window._lnObserverLoaded !== "undefined"
    }).then(([result]) => {
      if (!result?.result) {
        chrome.scripting.executeScript({ target: { tabId, allFrames: true }, files: CONTENT_FILES }).catch(() => {});
      }
    }).catch(() => {});
  }
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId !== "ln-polish") return;
  // documentUrlPatterns beperkt het menu al tot Autotask; deze check is defense-in-depth
  // en dekt menu-items die nog van een eerdere installatie zonder dat patroon bestaan.
  if (!tab || !isAutotaskUrl(tab.url)) return;
  chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, files: CONTENT_FILES })
    .then(() => {
      setTimeout(() => {
        chrome.tabs.sendMessage(tab.id, { action: "polishSelection" }, () => { void chrome.runtime.lastError; });
        chrome.webNavigation?.getAllFrames({ tabId: tab.id }, (frames) => {
          if (!frames) return;
          frames.forEach(frame => {
            if (frame.frameId !== 0) {
              chrome.tabs.sendMessage(tab.id, { action: "polishSelection" }, { frameId: frame.frameId }, () => { void chrome.runtime.lastError; });
            }
          });
        });
      }, 150);
    }).catch(() => {
      chrome.tabs.sendMessage(tab.id, { action: "polishSelection" }, () => { void chrome.runtime.lastError; });
    });
});