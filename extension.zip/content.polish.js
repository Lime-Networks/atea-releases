// ============================================================
// Lime Networks — content.polish.js
// Tekst polijsten + samenvatting genereren + knoppen injecteren
// ============================================================

// --- HTML-escaping helper (voorkomt XSS bij dynamische content in innerHTML) ---
// Volgorde: & eerst (anders worden eigen entities dubbel geëncodeerd), dan < > " '
function esc(s) {
  return String(s ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

// --- Eén globale click-handler om alle popup-menus te sluiten ---
// Voorheen werd per injectSummaryButton/injectActivityToolbarButtons aanroep een nieuwe
// document.addEventListener("click", ...) toegevoegd — een memory leak omdat deze injecties
// elke 1.5s vanuit de observer aangeroepen kunnen worden. Nu: één handler die alle elementen
// met [data-ln-menu="true"] sluit, registratie via sentinel zodat hij maar 1x bestaat.
if (typeof window._lnMenuCloseHandlerRegistered === "undefined") {
  window._lnMenuCloseHandlerRegistered = true;
  document.addEventListener("click", () => {
    document.querySelectorAll('[data-ln-menu="true"]').forEach(m => {
      if (m.style.display === "block") m.style.display = "none";
    });
  }, { capture: true });
}

// --- Toast ---
function showToast(msg, type = "info") {
  const existing = document.getElementById("ln-toast");
  if (existing) existing.remove();
  const toast = document.createElement("div");
  toast.id = "ln-toast";
  toast.textContent = msg;
  const colors = { success: "#76B82A", error: "#ef4444", warning: "#C2D500", loading: "#00B1EB" };
  Object.assign(toast.style, {
    position: "fixed", bottom: "24px", right: "24px", zIndex: "9999999",
    background: colors[type] || "#374151",
    color: type === "success" || type === "warning" ? "#0f1117" : "#fff",
    padding: "10px 18px", borderRadius: "10px", fontSize: "13px", fontWeight: "700",
    fontFamily: "Segoe UI, system-ui, sans-serif", boxShadow: "0 4px 16px rgba(0,0,0,0.3)",
    transition: "opacity 0.3s", opacity: "1"
  });
  document.body.appendChild(toast);
  if (type !== "loading") {
    setTimeout(() => { toast.style.opacity = "0"; setTimeout(() => toast.remove(), 300); }, 3500);
  }
}

// --- Is deze activiteit-entry ALS GEHEEL een internal note? ---
// Onderscheid dat hier gemaakt moet worden:
//  a) Standalone internal note → de marker staat in de HEADER van de entry en de body
//     is volledig intern. De hele entry moet vervallen.
//  b) Gewone time entry met gevulde "Internal Notes" → publieke Summary Notes plus een
//     intern SUBBLOK dieper in de body. Alleen dat subblok mag vervallen; dit is de
//     normale situatie en de entry zelf is bruikbaar.
// Beide gebruiken dezelfde Internal-classes, dus het verschil is de POSITIE: een
// header-marker zit vlak onder de entry-root, een intern subblok zit dieper.
//
// LET OP: deze drempel is een heuristiek, afgeleid uit de code-historie (v2.11.5 sloeg
// beide gevallen over, v2.11.6 nam beide mee) en niet uit de echte Autotask-DOM.
// Verifieer op een ticket met zowel een interne note als een time entry met gevulde
// Internal Notes via de console:
//   document.querySelectorAll("div.Details").forEach(e => console.log(
//     [...e.querySelectorAll(".Badge.Internal,.Title.Internal")]
//       .map(m => { let d=0; for(let n=m;n&&n!==e;n=n.parentElement) d++; return d; }),
//     e.textContent.trim().slice(0,60)));
// Staat de diepte van een standalone interne note hoger dan van een intern subblok,
// pas dan deze constante aan.
const _LN_INTERNAL_HEADER_DEPTH = 2;

function _lnDepthWithin(node, root) {
  let depth = 0;
  for (let n = node; n && n !== root; n = n.parentElement) depth++;
  return depth;
}

function isInternalEntry(el) {
  for (const m of el.querySelectorAll(".Badge.Internal, .Title.Internal")) {
    if (_lnDepthWithin(m, el) <= _LN_INTERNAL_HEADER_DEPTH) return true;
  }
  // Fallback op het zichtbare label, mocht Autotask de class-naam wijzigen.
  // Bewust strak: "Internal Only"/"Internal Note" matcht, een tickettitel als
  // "Internal server error" niet.
  for (const hdr of el.querySelectorAll(".Title, .Badge")) {
    if (/\binternal\s+(only|note)\b/i.test(hdr.textContent) &&
        _lnDepthWithin(hdr, el) <= _LN_INTERNAL_HEADER_DEPTH) return true;
  }
  return false;
}

// --- Ticket context ophalen ---
// Internal notes worden VOLLEDIG uitgesloten — dit voedt zowel de samenvatting als de
// klantmail in content.mail.js, die belooft "alleen publieke notes" te gebruiken.
// Twee gevallen, bewust apart behandeld:
//  1. De entry zelf is een internal note → hele entry overslaan. Alleen de marker strippen
//     is niet genoeg: dan blijft de interne body staan en belandt die alsnog in de
//     samenvatting (dat was de regressie sinds v2.11.6).
//  2. Publieke entry met een internal-only addendum → alleen dat addendum strippen,
//     de publieke tekst blijft bruikbaar (de bedoeling van v2.11.6).
function getTicketContext() {
  let ticketTitle = "";
  document.querySelectorAll("div.Title").forEach(el => {
    if (el.parentElement?.className?.includes("Content") && !ticketTitle) {
      const txt = el.textContent.trim();
      if (txt.length > 5 && txt.length < 200 && !txt.includes("Ticket -")) ticketTitle = txt;
    }
  });
  const existingNotes = [];
  document.querySelectorAll("div.Details").forEach(el => {
    const rawTxt = el.textContent.trim();
    if (rawTxt.includes("Workflow Rule") || rawTxt.includes("Task Detail") || rawTxt.length < 50) return;
    if (isInternalEntry(el)) return;                                    // geval 1
    // Geval 2: intern subblok uit een verder publieke entry strippen. Alleen de marker
    // verwijderen is niet genoeg — bij een los label ("Internal Only") staat de interne
    // tekst in een zusterelement, dus verwijderen we het omliggende blok. Staat de
    // interne tekst zelf in de Internal-node (lang), dan volstaat die node.
    const clone = el.cloneNode(true);
    clone.querySelectorAll('[class*="Internal" i]').forEach(n => {
      const isBareLabel = n.textContent.trim().length <= 40;
      const target = (isBareLabel && n.parentElement && n.parentElement !== clone)
        ? n.parentElement
        : n;
      target.remove();
    });
    const txt = clone.textContent.trim();
    // Groep 3 = de timestamp zelf; de literal "notetimeattachment" blijft vereist maar
    // valt buiten de groep zodat we een schone datum overhouden voor de chronologie.
    const match = txt.match(/\|\s*(Not\s+)?Posted\s*([\s\S]+?)(\d{2}\/\d{2}\/\d{4}\s+\d{2}:\d{2})notetimeattachment/);
    if (match?.[2]) {
      const noteText = match[2].trim();
      if (noteText.length > 10 && !existingNotes.some(n => n.text === noteText)) {
        existingNotes.push({ text: noteText.substring(0, 500), ts: match[3] || "" });
      }
    }
  });
  let ticketDescription = extractTicketDescription();
  return { ticketTitle, existingNotes, ticketDescription };
}

// --- Robuuste description extractie: probeer meerdere strategieën, ook in iframes ---
function extractTicketDescription() {
  const docs = [document];
  document.querySelectorAll("iframe").forEach(f => {
    try { if (f.contentDocument) docs.push(f.contentDocument); } catch(e) {}
  });
  const clean = (t) => (t || "").replace(/\s+/g, " ").trim();
  for (const doc of docs) {
    // Strategie 1: label "Description" → eerstvolgende zinvolle content
    const labels = doc.querySelectorAll("div, span, label, td, th");
    for (const el of labels) {
      if (el.children.length > 0) continue;
      if (el.textContent.trim() !== "Description") continue;
      const candidates = [];
      if (el.nextElementSibling) candidates.push(el.nextElementSibling);
      if (el.parentElement?.nextElementSibling) candidates.push(el.parentElement.nextElementSibling);
      for (const c of candidates) {
        let node = c;
        let depth = 0;
        while (node && depth < 5) {
          const txt = clean(node.innerText || node.textContent);
          if (txt.length > 10 && txt !== "Description") return txt.substring(0, 1500);
          node = node.nextElementSibling;
          depth++;
        }
      }
    }
    // Strategie 2: containers met class/id Description
    const directs = doc.querySelectorAll("div.Description, td.Description, [id*='Description' i]:not(label):not([id*='Label' i])");
    for (const el of directs) {
      const txt = clean(el.innerText || el.textContent);
      if (txt.length > 20 && txt.length < 5000 && !/^description$/i.test(txt)) return txt.substring(0, 1500);
    }
    // Strategie 3: form-velden met name/data Description
    const fields = doc.querySelectorAll("textarea[name*='Description' i], input[name*='Description' i], [data-field*='Description' i]");
    for (const el of fields) {
      const txt = clean(el.value || el.innerText || el.textContent);
      if (txt.length > 10) return txt.substring(0, 1500);
    }
  }
  return "";
}

// --- Samenvatting genereren en invullen ---
async function generateAndFillSummary(type = "open") {
  let summaryField = null;
  document.querySelectorAll("iframe").forEach(frame => {
    try {
      const editables = frame.contentDocument?.querySelectorAll("[contenteditable='true']");
      editables?.forEach(el => { if (!summaryField && el.offsetHeight > 40) summaryField = { el, doc: frame.contentDocument, win: frame.contentWindow }; });
    } catch(e) {}
  });
  if (!summaryField) {
    document.querySelectorAll("[contenteditable='true']").forEach(el => {
      if (!summaryField && el.offsetHeight > 40) summaryField = { el, doc: document, win: window };
    });
  }
  // Fallback: gebruik focus-tracker (werkt ook na focusverlies door toolbar-klik)
  if (!summaryField && window._lnLastEditTarget) {
    const t = window._lnLastEditTarget;
    if (t.method === "iframe-all" && t.body && t.win) {
      summaryField = { el: t.body, doc: t.win.document, win: t.win };
    } else if ((t.method === "contenteditable-all" || t.method === "textarea") && t.el) {
      summaryField = { el: t.el, doc: document, win: window, isTextarea: t.method === "textarea" };
    }
  }
  if (!summaryField) { showToast("⚠️ Geen invoerveld gevonden — klik eerst in het notitieveld.", "warning"); return; }
  const { ticketTitle, existingNotes, ticketDescription } = getTicketContext();
  const hasEntries = existingNotes.length > 0;
  if (!ticketTitle && !hasEntries && !ticketDescription) return;
  // Guard: zonder entries én zonder description kan AI niets zinnigs maken
  if (!hasEntries && !ticketDescription) {
    showToast("⚠️ Geen time entries of beschrijving gevonden — voeg eerst notities toe.", "warning"); return;
  }
  // Zonder publieke time entries valt ook "Volledig afgesloten" terug op de description.
  // Sinds internal notes volledig worden uitgesloten komt dat vaker voor; blokkeren zou
  // de engineer op zulke tickets laten vastlopen. De prompt hieronder weet dat er geen
  // acties bekend zijn en verzint ze dus niet.
  showToast(hasEntries
    ? "📝 Samenvatting genereren..."
    : "📝 Geen publieke time entries — samenvatten op basis van de beschrijving...", "loading");
  try {
    let context;
    const sourceLabel = hasEntries ? "the time entry notes" : "the ticket description";
    const sourceText = hasEntries ? existingNotes.map(n => n.text).join("\n") : ticketDescription;
    if (hasEntries) {
      // Elke entry krijgt zijn eigen Autotask-timestamp mee. Eerder stond hier de claim
      // "chronological, oldest first", maar de feed-volgorde van Autotask is niet
      // gegarandeerd — en juist bij een afsluitende samenvatting bepaalt de LAATSTE
      // entry de uitkomst. Met de timestamps erbij bepaalt het model de volgorde zelf.
      const entryLines = existingNotes
        .map(n => `- [${n.ts || "geen datum"}] ${n.text}`)
        .join("\n");
      // Beschrijving meesturen als probleemstelling: de afsluitende prompt vraagt om
      // "what the issue was" en dat staat in de description, niet in de time entries.
      const problemBlock = ticketDescription
        ? `\n\nOriginal problem (ticket description):\n${ticketDescription}`
        : "";
      context = `Ticket title: ${ticketTitle}${problemBlock}\n\nTime entry notes, each prefixed with its Autotask timestamp:\n${entryLines}`;
    } else {
      context = `Ticket title: ${ticketTitle}\n\nTicket description:\n${ticketDescription}`;
    }
    // Taal vooraf hard vastpinnen op basis van de bron-tekst (niet de titel — die kan misleidend zijn)
    const settings = await loadSettings();
    const lang = await resolveOutputLang(sourceText, settings);
    const openExamples = lang === "en"
      ? `Examples: "Client confirmed that..." / "Verified and..." / "Followed up to..."`
      : `Voorbeelden: "Klant heeft bevestigd dat..." / "Gecontroleerd en..." / "Teruggebeld om..."`;
    const closingPhrase = lang === "en" ? `"Issue resolved." or "Ticket closed."` : `"Ticket gesloten." of "Probleem opgelost."`;

    // Regels die alleen kloppen als de bijbehorende data er ook is — anders stuurt de
    // prompt het model naar informatie die niet in de context staat.
    const chronoRule = hasEntries
      ? `\n- Each note is prefixed with its timestamp. The MOST RECENT note reflects the final state and the outcome — do not present an earlier step as the result`
      : "";
    const problemRule = (hasEntries && ticketDescription)
      ? `\n- The ticket description is the ORIGINAL PROBLEM; the time entry notes are what was actually done. Never present the problem as if it were the outcome`
      : "";
    const coverRule = hasEntries
      ? `- Cover: what the issue was, what was done, and the outcome — but only if these are in ${sourceLabel}`
      : `- There are NO time entry notes, only a problem description. Describe the problem and, if it is stated, the outcome. Do NOT describe actions, troubleshooting or fixes — none are known`;

    let sysPrompt;
    if (type === "open") {
      sysPrompt = `You are an expert MSP time entry writer for Lime Networks.

${langDirective(lang)}

Write a SHORT summary (2-3 sentences max) based ONLY on what is described in ${sourceLabel}.
Rules:
- Do NOT mention the same fact twice
- Do NOT invent troubleshooting steps or actions that are not explicitly in ${sourceLabel}
- Do NOT ask the user for more information — work with what is provided${chronoRule}${problemRule}
- End with an OPEN, unfinished sentence for the engineer to complete (no period). ${openExamples}
- Natural, direct tone. Past tense. No bullet points.
Output ONLY the summary — no labels, no quotes, no preamble.`;
    } else {
      sysPrompt = `You are an expert MSP time entry writer for Lime Networks.

${langDirective(lang)}

Write a COMPLETE closing summary (max 3 sentences) based ONLY on what is described in ${sourceLabel}.
Rules:
- Do NOT mention the same fact twice
- Do NOT invent troubleshooting steps or actions that are not explicitly in ${sourceLabel}
- Do NOT ask the user for more information — work with what is provided
${coverRule}${chronoRule}${problemRule}
- End with a short closing: ${closingPhrase}
- Natural, direct tone. Past tense. No bullet points.
Output ONLY the summary — no labels, no quotes, no preamble.`;
    }
    const summary = await callAIWithPrompt(context, sysPrompt);
    const { el, doc, win, isTextarea } = summaryField;
    el.focus();
    if (isTextarea) {
      const cur = el.value.trim();
      el.value = cur ? cur + "\n" + summary : summary;
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
    } else {
      const currentText = el.innerText?.trim();
      try {
        const range = doc.createRange();
        if (currentText && currentText.length > 0) { range.selectNodeContents(el); range.collapse(false); }
        else { range.selectNodeContents(el); }
        const sel = win.getSelection();
        sel.removeAllRanges();
        sel.addRange(range);
        doc.execCommand("insertText", false, currentText ? "\n" + summary : summary);
      } catch(e) {
        el.innerText = currentText ? currentText + "\n" + summary : summary;
        el.dispatchEvent(new Event("input", { bubbles: true }));
        el.dispatchEvent(new Event("change", { bubbles: true }));
      }
    }
    showToast("📝 Samenvatting toegevoegd!", "success");
  } catch(e) {
    if (e.message?.includes("rate limit")) {
      showToast("⏳ Rate limit — opnieuw proberen over 15 sec...", "warning");
      setTimeout(() => generateAndFillSummary(type), 15000);
    } else {
      showToast("❌ Samenvatting mislukt: " + e.message, "error");
    }
  }
}

// --- Track laatste actieve invoerveld (voor toolbar knoppen die focus breken) ---
if (typeof window._lnLastEditTarget === "undefined") {
  window._lnLastEditTarget = null;
  document.addEventListener("focusin", (e) => {
    const el = e.target;
    if (!el) return;
    if (el.tagName === "TEXTAREA" && !isInternalNotesField?.(el)) {
      window._lnLastEditTarget = { text: () => el.value.trim(), method: "textarea", el };
    } else if (el.isContentEditable && el.tagName !== "BODY" && !isInternalNotesField?.(el)) {
      window._lnLastEditTarget = { text: () => el.innerText?.trim(), method: "contenteditable-all", el };
    }
  }, true);
  // Track ook focus binnen iframes
  document.querySelectorAll("iframe").forEach(_lnTrackIframe);
}

function _lnTrackIframe(frame) {
  try {
    const win = frame.contentWindow;
    const body = win?.document?.body;
    if (!body) return;
    if (body.isContentEditable) {
      body.addEventListener("focusin", () => {
        if (!isInternalNotesField?.(frame)) {
          window._lnLastEditTarget = { text: () => body.innerText?.trim(), method: "iframe-all", body, win };
        }
      }, { once: false });
    }
  } catch(e) {}
}

// --- Taal override staat (var zodat herhaald laden geen conflict geeft) ---
if (typeof langOverride === "undefined") var langOverride = null;

// --- Feature flags (gecached bij init, bijgewerkt via storage.onChanged) ---
if (typeof _cachedFeatures === "undefined") var _cachedFeatures = {
  mailDraft: true, snelkoppelingen: true, oplossing: true,
  toolbarPolish: true, toolbarSummary: true, toolbarSnippets: true
};
chrome.storage.local.get(["ln_features"], r => {
  if (r.ln_features) _cachedFeatures = { ..._cachedFeatures, ...r.ln_features };
});
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes.ln_features) {
    _cachedFeatures = { ..._cachedFeatures, ...(changes.ln_features.newValue || {}) };
    injectSummaryButton();
    document.getElementById("ln-toolbar-group")?.remove(); // herlaad toolbar bij wijziging
  }
});

// --- Helper: vind de "New Ticket Note" modal-container ---
function findNewNoteModal() {
  for (const el of document.querySelectorAll("div, h1, h2, h3, h4, span")) {
    if (el.children.length > 0) continue;
    if (el.textContent.trim() !== "New Ticket Note") continue;
    let n = el.parentElement;
    while (n && n !== document.body) {
      if (n.querySelector("span.PrimaryText")) return n;
      n = n.parentElement;
    }
  }
  return null;
}

// --- Knoppen injecteren naast "Summary Notes" label (of "Description" in Note modal) ---
function injectSummaryButton() {
  document.getElementById("ln-polish-btn")?.remove();
  document.getElementById("ln-summary-btn")?.remove();
  document.getElementById("ln-lang-btn")?.remove();
  document.getElementById("ln-quick-btn")?.remove();
  document.getElementById("ln-mail-btn")?.remove();
  document.getElementById("ln-snippets-btn")?.closest("span")?.remove();
  let targetSpan = null;
  // Eerst: New Time Entry modal (label "Summary Notes")
  document.querySelectorAll("span.PrimaryText").forEach(el => {
    if (el.textContent.trim() === "Summary Notes" && !targetSpan) targetSpan = el;
  });
  // Fallback: New Ticket Note modal (label "Description" binnen modal met header "New Ticket Note")
  if (!targetSpan) {
    const noteModal = findNewNoteModal();
    if (noteModal) {
      noteModal.querySelectorAll("span.PrimaryText").forEach(el => {
        if (el.textContent.trim() === "Description" && !targetSpan) targetSpan = el;
      });
    }
  }
  if (!targetSpan) return false;
  const labelContainer = targetSpan.closest(".LabelContainer1");
  if (!labelContainer) return false;

  // ✨ Polijst knop
  const polishBtn = document.createElement("span");
  polishBtn.id = "ln-polish-btn";
  polishBtn.title = "Tekst polijsten met Lime Networks AI";
  polishBtn.textContent = "✨";
  polishBtn.style.cssText = "display:inline;cursor:pointer;font-size:14px;user-select:none;margin-left:6px;";
  polishBtn.addEventListener("mouseenter", () => polishBtn.style.opacity = "0.7");
  polishBtn.addEventListener("mouseleave", () => polishBtn.style.opacity = "1");
  polishBtn.addEventListener("click", (e) => { e.preventDefault(); e.stopPropagation(); handlePolish(); });

  // 🇳🇱/🇬🇧 Taal override knop
  const langBtn = document.createElement("span");
  langBtn.id = "ln-lang-btn";
  langBtn.title = "Taal forceren (nu: automatisch)";
  langBtn.textContent = "🌐";
  langBtn.style.cssText = "display:inline;cursor:pointer;font-size:12px;font-weight:700;font-family:Segoe UI,system-ui,sans-serif;user-select:none;margin-left:4px;";
  langBtn.addEventListener("mouseenter", () => langBtn.style.opacity = "0.7");
  langBtn.addEventListener("mouseleave", () => langBtn.style.opacity = "1");
  langBtn.addEventListener("click", (e) => {
    e.preventDefault(); e.stopPropagation();
    if (!langOverride) { langOverride = "nl"; langBtn.textContent = "NL"; langBtn.title = "Taal: Nederlands — klik voor Engels"; showToast("NL Uitvoer: Nederlands (vertaalt indien nodig)", "info"); }
    else if (langOverride === "nl") { langOverride = "en"; langBtn.textContent = "EN"; langBtn.title = "Taal: Engels — klik voor auto"; showToast("EN Uitvoer: Engels (vertaalt indien nodig)", "info"); }
    else { langOverride = null; langBtn.textContent = "🌐"; langBtn.title = "Taal: automatisch detecteren"; showToast("🌐 Taal: automatisch detecteren", "info"); }
  });

  // 📝 Samenvatting knop
  const summaryWrapper = document.createElement("span");
  summaryWrapper.style.cssText = "display:inline;position:relative;";
  const summaryBtn = document.createElement("span");
  summaryBtn.id = "ln-summary-btn";
  summaryBtn.title = "Samenvatting genereren";
  summaryBtn.textContent = "📝";
  summaryBtn.style.cssText = "display:inline;cursor:pointer;font-size:14px;user-select:none;margin-left:4px;";
  summaryBtn.addEventListener("mouseenter", () => summaryBtn.style.opacity = "0.7");
  summaryBtn.addEventListener("mouseleave", () => summaryBtn.style.opacity = "1");

  const menu = document.createElement("div");
  menu.id = "ln-summary-menu";
  menu.setAttribute("data-ln-menu", "true");
  menu.style.cssText = `display:none;position:absolute;top:20px;left:0;z-index:9999999;
    background:#083E47;border:1.5px solid #76B82A;border-radius:8px;
    box-shadow:0 4px 16px rgba(0,0,0,0.4);min-width:200px;overflow:hidden;
    font-family:Segoe UI,system-ui,sans-serif;`;

  [{ label: "✏️ Open einde", desc: "Eindigt met een open zin", type: "open" },
   { label: "✅ Volledig afgesloten", desc: "Compleet met eindstatus", type: "closed" }
  ].forEach(item => {
    const menuItem = document.createElement("div");
    menuItem.dataset.summaryType = item.type;
    menuItem.style.cssText = "padding:10px 14px;cursor:pointer;border-bottom:1px solid #0d4f5c;";
    menuItem.innerHTML = `<div style="font-size:13px;font-weight:700;color:#F7F8F9;">${item.label}</div><div style="font-size:11px;color:#6D6E72;margin-top:2px;">${item.desc}</div>`;
    menuItem.addEventListener("mouseenter", () => menuItem.style.background = "#0d4f5c");
    menuItem.addEventListener("mouseleave", () => menuItem.style.background = "transparent");
    menuItem.addEventListener("click", (e) => { e.preventDefault(); e.stopPropagation(); menu.style.display = "none"; generateAndFillSummary(item.type); });
    menu.appendChild(menuItem);
  });
  menu.lastChild.style.borderBottom = "none";

  summaryBtn.addEventListener("click", (e) => {
    e.preventDefault(); e.stopPropagation();
    // Beide opties zijn altijd beschikbaar. Zonder publieke time entries valt
    // "Volledig afgesloten" terug op de ticketbeschrijving (zie generateAndFillSummary)
    // en meldt de loading-toast dat. Eerder werd de optie hier verborgen, waardoor die
    // fallback onbereikbaar zou zijn — en verborg hij zich sinds het strengere
    // internal-filter ook op tickets die alleen interne notes hebben.
    menu.style.display = menu.style.display === "block" ? "none" : "block";
  });

  summaryWrapper.appendChild(summaryBtn);
  summaryWrapper.appendChild(menu);
  // Sla referentie op naar het Summary Notes editable veld — bug fix: voorkomt dat Internal Notes wordt opgepikt bij polijsten
  window._lnSummaryNotesFrame = null;
  const fieldContainer = labelContainer.parentElement;
  if (fieldContainer) {
    for (const frame of fieldContainer.querySelectorAll("iframe")) {
      try {
        if (frame.contentDocument?.body?.isContentEditable) {
          window._lnSummaryNotesFrame = frame;
          break;
        }
      } catch(e) {}
    }
  }

  labelContainer.appendChild(polishBtn);
  labelContainer.appendChild(langBtn);
  labelContainer.appendChild(summaryWrapper);

  // ✉️ Mail draften (conditioneel op feature-flag)
  if (_cachedFeatures.mailDraft) {
    const mailBtn = document.createElement("span");
    mailBtn.id = "ln-mail-btn";
    mailBtn.title = "Mail draften op basis van ticketcontext";
    mailBtn.textContent = "✉️";
    mailBtn.style.cssText = "display:inline;cursor:pointer;font-size:14px;user-select:none;margin-left:4px;";
    mailBtn.addEventListener("mouseenter", () => mailBtn.style.opacity = "0.7");
    mailBtn.addEventListener("mouseleave", () => mailBtn.style.opacity = "1");
    mailBtn.addEventListener("click", (e) => { e.preventDefault(); e.stopPropagation(); showMailModal(); });
    labelContainer.appendChild(mailBtn);
  }

  // ⚡ Snelkoppelingen (conditioneel op feature-flag)
  if (_cachedFeatures.snelkoppelingen) {
    const snippetsWrapper = document.createElement("span");
    snippetsWrapper.style.cssText = "display:inline;position:relative;";

    const snippetsBtn = document.createElement("span");
    snippetsBtn.id = "ln-snippets-btn";
    snippetsBtn.title = "Snelkoppelingen invoegen";
    snippetsBtn.textContent = "⚡";
    snippetsBtn.style.cssText = "display:inline;cursor:pointer;font-size:14px;user-select:none;margin-left:4px;";
    snippetsBtn.addEventListener("mouseenter", () => snippetsBtn.style.opacity = "0.7");
    snippetsBtn.addEventListener("mouseleave", () => snippetsBtn.style.opacity = "1");

    const snippetsMenu = document.createElement("div");
    snippetsMenu.id = "ln-snippets-menu";
    snippetsMenu.setAttribute("data-ln-menu", "true");
    snippetsMenu.style.cssText = `display:none;position:absolute;top:20px;left:0;z-index:9999999;
      background:#083E47;border:1.5px solid #76B82A;border-radius:8px;
      box-shadow:0 4px 16px rgba(0,0,0,0.4);min-width:220px;overflow:hidden;
      font-family:Segoe UI,system-ui,sans-serif;`;

    snippetsBtn.addEventListener("click", async (e) => {
      e.preventDefault(); e.stopPropagation();
      if (snippetsMenu.style.display === "block") { snippetsMenu.style.display = "none"; return; }
      snippetsMenu.innerHTML = "";

      const snippets = await new Promise(resolve => {
        chrome.storage.local.get(["ln_snippets"], r => resolve(r.ln_snippets || [
          "Klant teruggebeld, geen gehoor.",
          "Wachtend op reactie klant.",
          "Remote sessie uitgevoerd, probleem opgelost.",
          "Ticket gesloten na bevestiging klant.",
          "Doorgestuurd naar 2e lijn.",
          "Onderzocht, geen actie vereist."
        ]));
      });

      if (snippets.length === 0) {
        const empty = document.createElement("div");
        empty.style.cssText = "padding:10px 14px;font-size:12px;color:#4b5563;font-style:italic;";
        empty.textContent = "Voeg snelkoppelingen toe via de extensie";
        snippetsMenu.appendChild(empty);
      } else {
        snippets.forEach(text => {
          const item = document.createElement("div");
          item.style.cssText = "padding:8px 14px;cursor:pointer;border-bottom:1px solid #0d4f5c;";
          item.innerHTML = `<div style="font-size:12px;color:#F7F8F9;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;" title="${esc(text)}">${esc(text)}</div>`;
          item.addEventListener("mouseenter", () => item.style.background = "#0d4f5c");
          item.addEventListener("mouseleave", () => item.style.background = "transparent");
          item.addEventListener("click", (ev) => { ev.preventDefault(); ev.stopPropagation(); snippetsMenu.style.display = "none"; insertSnippet(text); });
          snippetsMenu.appendChild(item);
        });
        snippetsMenu.lastChild.style.borderBottom = "none";
      }
      snippetsMenu.style.display = "block";
    });

    snippetsWrapper.appendChild(snippetsBtn);
    snippetsWrapper.appendChild(snippetsMenu);
    labelContainer.appendChild(snippetsWrapper);
  }

  return true;
}

// --- Knoppen injecteren in de activiteitentoolbalk (naast New Time Entry etc.) ---
function injectActivityToolbarButtons() {
  if (document.getElementById("ln-toolbar-group")) return true;

  // Zoek de kleinste container die alle drie knoppen bevat
  let toolbarContainer = null;
  let node = document.body;
  while (node) {
    const inner = node.innerText || "";
    if (inner.includes("New Time Entry") && inner.includes("New Note") && inner.includes("New Attachment")) {
      toolbarContainer = node;
      // Probeer verder naar beneden — kleinste container wint
      const smaller = Array.from(node.children).find(c => {
        const t = c.innerText || "";
        return t.includes("New Time Entry") && t.includes("New Note") && t.includes("New Attachment");
      });
      if (!smaller) break;
      node = smaller;
    } else {
      break;
    }
  }
  if (!toolbarContainer) return false;

  // Wrapper — alle toolbar-knoppen zitten hierin
  const btnGroup = document.createElement("span");
  btnGroup.id = "ln-toolbar-group";
  btnGroup.style.cssText = "display:inline-flex;align-items:center;gap:4px;margin-left:auto;padding-right:4px;";

  // ✨ Polijst knop
  if (_cachedFeatures.toolbarPolish !== false) {
    const polishBtn = document.createElement("span");
    polishBtn.id = "ln-toolbar-polish-btn";
    polishBtn.title = "Tekst polijsten met Lime Networks AI";
    polishBtn.textContent = "✨";
    polishBtn.style.cssText = "display:inline-flex;align-items:center;cursor:pointer;font-size:14px;user-select:none;vertical-align:middle;";
    polishBtn.addEventListener("mouseenter", () => { polishBtn.style.opacity = "0.7"; });
    polishBtn.addEventListener("mouseleave", () => { polishBtn.style.opacity = "1"; });
    polishBtn.addEventListener("click", (e) => { e.preventDefault(); e.stopPropagation(); handlePolish(); });
    btnGroup.appendChild(polishBtn);
  }

  // 📝 Samenvatting knop met dropdown
  if (_cachedFeatures.toolbarSummary !== false) {
    const summaryWrapper = document.createElement("span");
    summaryWrapper.style.cssText = "display:inline-flex;align-items:center;position:relative;";
    const summaryBtn = document.createElement("span");
    summaryBtn.id = "ln-toolbar-summary-btn";
    summaryBtn.title = "Samenvatting genereren";
    summaryBtn.textContent = "📝";
    summaryBtn.style.cssText = "display:inline-flex;align-items:center;cursor:pointer;font-size:14px;user-select:none;vertical-align:middle;";
    summaryBtn.addEventListener("mouseenter", () => { summaryBtn.style.opacity = "0.7"; });
    summaryBtn.addEventListener("mouseleave", () => { summaryBtn.style.opacity = "1"; });
    const summaryMenu = document.createElement("div");
    summaryMenu.id = "ln-toolbar-summary-menu";
    summaryMenu.setAttribute("data-ln-menu", "true");
    summaryMenu.style.cssText = `display:none;position:absolute;top:22px;left:0;z-index:9999999;
      background:#083E47;border:1.5px solid #76B82A;border-radius:8px;
      box-shadow:0 4px 16px rgba(0,0,0,0.4);min-width:200px;overflow:hidden;
      font-family:Segoe UI,system-ui,sans-serif;`;
    [{ label: "✏️ Open einde", desc: "Eindigt met een open zin", type: "open" },
     { label: "✅ Volledig afgesloten", desc: "Compleet met eindstatus", type: "closed" }
    ].forEach((item, i, arr) => {
      const mi = document.createElement("div");
      mi.dataset.summaryType = item.type;
      mi.style.cssText = "padding:10px 14px;cursor:pointer;border-bottom:1px solid #0d4f5c;";
      mi.innerHTML = `<div style="font-size:13px;font-weight:700;color:#F7F8F9;">${item.label}</div>
        <div style="font-size:11px;color:#6D6E72;margin-top:2px;">${item.desc}</div>`;
      mi.addEventListener("mouseenter", () => { mi.style.background = "#0d4f5c"; });
      mi.addEventListener("mouseleave", () => { mi.style.background = "transparent"; });
      mi.addEventListener("click", (e) => { e.preventDefault(); e.stopPropagation(); summaryMenu.style.display = "none"; generateAndFillSummary(item.type); });
      if (i === arr.length - 1) mi.style.borderBottom = "none";
      summaryMenu.appendChild(mi);
    });
    summaryBtn.addEventListener("click", (e) => {
      e.preventDefault(); e.stopPropagation();
      // Beide opties altijd beschikbaar — zie de gelijke handler in injectSummaryButton.
      summaryMenu.style.display = summaryMenu.style.display === "block" ? "none" : "block";
    });
    summaryWrapper.appendChild(summaryBtn);
    summaryWrapper.appendChild(summaryMenu);
    btnGroup.appendChild(summaryWrapper);
  }

  // ⚡ Snelkoppelingen knop met dropdown
  if (_cachedFeatures.toolbarSnippets !== false) {
    const snipWrapper = document.createElement("span");
    snipWrapper.style.cssText = "display:inline-flex;align-items:center;position:relative;";
    const snipBtn = document.createElement("span");
    snipBtn.id = "ln-toolbar-snippets-btn";
    snipBtn.title = "Snelkoppeling invoegen";
    snipBtn.textContent = "⚡";
    snipBtn.style.cssText = "display:inline-flex;align-items:center;cursor:pointer;font-size:14px;user-select:none;vertical-align:middle;";
    snipBtn.addEventListener("mouseenter", () => { snipBtn.style.opacity = "0.7"; });
    snipBtn.addEventListener("mouseleave", () => { snipBtn.style.opacity = "1"; });
    const snipMenu = document.createElement("div");
    snipMenu.id = "ln-toolbar-snippets-menu";
    snipMenu.setAttribute("data-ln-menu", "true");
    snipMenu.style.cssText = `display:none;position:absolute;top:22px;right:0;left:auto;z-index:9999999;
      background:#083E47;border:1.5px solid #76B82A;border-radius:8px;
      box-shadow:0 4px 16px rgba(0,0,0,0.4);min-width:220px;overflow:hidden;
      font-family:Segoe UI,system-ui,sans-serif;`;
    snipBtn.addEventListener("click", async (e) => {
      e.preventDefault(); e.stopPropagation();
      if (snipMenu.style.display === "block") { snipMenu.style.display = "none"; return; }
      snipMenu.innerHTML = "";
      const snippets = await new Promise(resolve => {
        chrome.storage.local.get(["ln_snippets"], r => resolve(r.ln_snippets || [
          "Klant teruggebeld, geen gehoor.",
          "Wachtend op reactie klant.",
          "Remote sessie uitgevoerd, probleem opgelost.",
          "Ticket gesloten na bevestiging klant.",
          "Doorgestuurd naar 2e lijn.",
          "Onderzocht, geen actie vereist."
        ]));
      });
      if (snippets.length === 0) {
        const empty = document.createElement("div");
        empty.style.cssText = "padding:10px 14px;font-size:12px;color:#4b5563;font-style:italic;";
        empty.textContent = "Voeg snelkoppelingen toe via de extensie";
        snipMenu.appendChild(empty);
      } else {
        snippets.forEach((txt, i) => {
          const mi = document.createElement("div");
          mi.style.cssText = "padding:8px 14px;cursor:pointer;border-bottom:1px solid #0d4f5c;";
          mi.innerHTML = `<div style="font-size:12px;color:#F7F8F9;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;" title="${esc(txt)}">${esc(txt)}</div>`;
          mi.addEventListener("mouseenter", () => { mi.style.background = "#0d4f5c"; });
          mi.addEventListener("mouseleave", () => { mi.style.background = "transparent"; });
          mi.addEventListener("click", (ev) => { ev.preventDefault(); ev.stopPropagation(); snipMenu.style.display = "none"; insertSnippet(txt); });
          if (i === snippets.length - 1) mi.style.borderBottom = "none";
          snipMenu.appendChild(mi);
        });
      }
      snipMenu.style.display = "block";
    });
    snipWrapper.appendChild(snipBtn);
    snipWrapper.appendChild(snipMenu);
    btnGroup.appendChild(snipWrapper);
  }

  if (!btnGroup.children.length) return false;

  toolbarContainer.style.display = "flex";
  toolbarContainer.style.alignItems = "center";
  toolbarContainer.style.width = "100%";
  toolbarContainer.appendChild(btnGroup);
  return true;
}

// --- Controleer of element binnen "Internal Notes" valt ---
function isInternalNotesField(el) {
  // Zoek omhoog naar een container die "Internal Notes" als label heeft
  let node = el;
  while (node && node !== document.body) {
    const prev = node.previousElementSibling;
    if (prev) {
      const txt = prev.textContent?.trim().toLowerCase();
      if (txt === "internal notes") return true;
    }
    // Controleer ook of een parent-sibling het label bevat
    const parentPrev = node.parentElement?.previousElementSibling;
    if (parentPrev) {
      const txt = parentPrev.textContent?.trim().toLowerCase();
      if (txt === "internal notes") return true;
    }
    node = node.parentElement;
  }
  return false;
}

// --- Tekst ophalen ---
function getSelectedText() {
  const sel = window.getSelection().toString().trim();
  if (sel) return { text: sel, method: "selection" };
  const frames = document.querySelectorAll("iframe");
  // Eerst: selecties in iframes checken
  for (const frame of frames) {
    try {
      const iSel = frame.contentWindow.getSelection().toString().trim();
      if (iSel) return { text: iSel, method: "iframe-selection", win: frame.contentWindow };
    } catch(e) {}
  }
  // Gebruik opgeslagen Summary Notes frame als referentie — voorkomt dat Internal Notes meekomt
  if (window._lnSummaryNotesFrame) {
    try {
      const win = window._lnSummaryNotesFrame.contentWindow;
      const body = win.document.body;
      if (body?.isContentEditable && body.innerText.trim()) {
        return { text: body.innerText.trim(), method: "iframe-all", body, win };
      }
    } catch(e) { window._lnSummaryNotesFrame = null; }
  }
  // Fallback: scan iframes, sla Internal Notes expliciet over
  for (const frame of frames) {
    try {
      const win = frame.contentWindow;
      const body = win.document.body;
      if (body?.isContentEditable && body.innerText.trim()) {
        if (isInternalNotesField(frame)) continue;
        return { text: body.innerText.trim(), method: "iframe-all", body, win };
      }
    } catch(e) {}
  }
  const editables = document.querySelectorAll("[contenteditable='true']");
  for (const el of editables) {
    if (el.innerText.trim() && !isInternalNotesField(el)) {
      return { text: el.innerText.trim(), method: "contenteditable-all", el };
    }
  }
  const active = document.activeElement;
  if (active?.tagName === "TEXTAREA" && active.value.trim() && !isInternalNotesField(active)) {
    return { text: active.value.trim(), method: "textarea", el: active };
  }
  // Laatste bekende invoerveld (gebruikt als toolbar-knop het focus heeft gebroken)
  if (window._lnLastEditTarget) {
    const txt = window._lnLastEditTarget.text?.();
    if (txt) return { ...window._lnLastEditTarget, text: txt };
  }
  return null;
}

// --- Tekst vervangen ---
function replaceText(source, replacement) {
  if (!source) return false;
  if (source.method === "selection" || source.method === "iframe-selection") {
    const win = source.method === "iframe-selection" ? source.win : window;
    const sel = win.getSelection();
    if (sel.rangeCount > 0) {
      const range = sel.getRangeAt(0);
      range.deleteContents();
      range.insertNode(document.createTextNode(replacement));
      sel.removeAllRanges();
      return true;
    }
  }
  if (source.method === "iframe-all") {
    const win = source.win;
    win.focus();
    const range = win.document.createRange();
    range.selectNodeContents(source.body);
    const sel = win.getSelection();
    sel.removeAllRanges();
    sel.addRange(range);
    win.document.execCommand("insertText", false, replacement);
    return true;
  }
  if (source.method === "contenteditable-all") {
    const el = source.el;
    el.focus();
    const range = document.createRange();
    range.selectNodeContents(el);
    const sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(range);
    document.execCommand("insertText", false, replacement);
    return true;
  }
  if (source.method === "textarea") {
    source.el.value = replacement;
    source.el.dispatchEvent(new Event("input", { bubbles: true }));
    source.el.dispatchEvent(new Event("change", { bubbles: true }));
    return true;
  }
  return false;
}

// --- Controleer of we op een new/edit ticket pagina zijn ---
function isNewOrEditTicketPage() {
  const url = location.href.toLowerCase();
  return url.includes("ticketnew.mvc") || url.includes("ticketedit.mvc");
}

// --- Nieuw/Edit Ticket: ✨ bij Description + automatische Titel ---
function injectNewTicketButtons() {
  if (!isNewOrEditTicketPage()) return false;
  if (document.getElementById("ln-newtix-btn")) return true;

  // Zoek "Description" sectie-header
  let descHeader = null;
  for (const el of document.querySelectorAll("h3, h4, div, span")) {
    if (el.children.length === 0 && el.textContent.trim() === "Description") {
      descHeader = el;
      break;
    }
  }
  if (!descHeader) return false;

  // Zoek de Title input (label "Title" of input naast "Title *")
  function findTitleInput() {
    // Autotask Title veld = <textarea maxlength="255"> in div.AdjustingTextBox2
    // Zoek DOM-order terugwaarts vanuit descHeader — stopt zodra textarea gevonden.

    const isValidTextarea = ta =>
      !ta.value.trim() && !ta.disabled && !ta.readOnly;

    let node = descHeader.parentElement;
    while (node && node !== document.body) {
      let sib = node.previousElementSibling;
      while (sib) {
        const ta = sib.querySelector("textarea");
        if (ta && isValidTextarea(ta)) return ta;
        sib = sib.previousElementSibling;
      }
      node = node.parentElement;
    }
    return null;
  }

  // Zoek het Description tekstveld — meerdere strategieën
  function findDescriptionField() {
    // Strategie 1: iframes met contenteditable body (TinyMCE e.d.)
    for (const frame of document.querySelectorAll("iframe")) {
      try {
        const body = frame.contentDocument?.body;
        if (!body) continue;
        const ce = body.getAttribute("contenteditable");
        if (body.isContentEditable || ce === "true" || ce === "") {
          return { el: body, win: frame.contentWindow, method: "iframe-all" };
        }
      } catch(e) {}
    }
    // Strategie 2: contenteditable div/p met voldoende hoogte
    for (const el of document.querySelectorAll("[contenteditable]")) {
      const val = el.getAttribute("contenteditable");
      if (val === "false") continue;
      if (el.offsetHeight > 60) {
        return { el, win: window, method: "contenteditable-all" };
      }
    }
    // Strategie 3: tekstarea met voldoende hoogte
    for (const el of document.querySelectorAll("textarea")) {
      if (el.offsetHeight > 60) {
        return { el, win: window, method: "textarea" };
      }
    }
    // Strategie 4: focus-tracker als laatste redmiddel
    if (window._lnLastEditTarget) {
      const t = window._lnLastEditTarget;
      if (t.method === "iframe-all" && t.body && t.win) return { el: t.body, win: t.win, method: "iframe-all" };
      if (t.el) return { el: t.el, win: window, method: t.method };
    }
    return null;
  }

  const btn = document.createElement("span");
  btn.id = "ln-newtix-btn";
  btn.title = "Beschrijving polijsten en titel genereren";
  btn.textContent = "✨";
  btn.style.cssText = "cursor:pointer;font-size:13px;user-select:none;margin-left:8px;vertical-align:middle;";
  btn.addEventListener("mouseenter", () => { btn.style.opacity = "0.7"; });
  btn.addEventListener("mouseleave", () => { btn.style.opacity = "1"; });
  btn.addEventListener("click", async (e) => {
    e.preventDefault(); e.stopPropagation();
    const field = findDescriptionField();
    if (!field) { showToast("⚠️ Description veld niet gevonden.", "warning"); return; }

    const rawText = field.method === "textarea"
      ? field.el.value?.trim()
      : field.el.innerText?.trim() || field.el.textContent?.trim();
    if (!rawText) { showToast("⚠️ Description is leeg.", "warning"); return; }

    showToast("⏳ Bezig met polijsten...", "loading");
    try {
      const polished = await callAIForTicketDescription(rawText);

      // Beschrijving vervangen
      if (field.method === "textarea") {
        field.el.value = polished;
        field.el.dispatchEvent(new Event("input",  { bubbles: true }));
        field.el.dispatchEvent(new Event("change", { bubbles: true }));
      } else if (field.method === "iframe-all") {
        const win = field.win;
        win.focus();
        const range = win.document.createRange();
        range.selectNodeContents(field.el);
        const sel = win.getSelection();
        sel.removeAllRanges();
        sel.addRange(range);
        win.document.execCommand("insertText", false, polished);
      } else {
        field.el.focus();
        const range = document.createRange();
        range.selectNodeContents(field.el);
        const sel = window.getSelection();
        sel.removeAllRanges();
        sel.addRange(range);
        document.execCommand("insertText", false, polished);
      }

      showToast("✅ Beschrijving gepolijst!", "success");

      // Titel genereren en invullen als het veld leeg is
      const titleInput = findTitleInput();
      if (titleInput && !titleInput.value.trim()) {
        showToast("📝 Titel genereren...", "loading");
        const titleLang = await resolveOutputLang(polished, await loadSettings());
        const titleSysPrompt = `You are an expert MSP ticket writer for Lime Networks.

${langDirective(titleLang)}

Generate a short, clear ticket title (max 10 words) based on the description below.
Output ONLY the title — no labels, no quotes, no punctuation at the end.`;
        const title = await callAIWithPrompt(polished, titleSysPrompt);
        titleInput.value = title.trim();
        titleInput.dispatchEvent(new Event("input",  { bubbles: true }));
        titleInput.dispatchEvent(new Event("change", { bubbles: true }));
        showToast("✅ Titel ingevuld!", "success");
      }
    } catch(err) {
      showToast("❌ " + err.message, "error");
    }
  });

  // Knop naast het "Description" label plaatsen
  const headerRow = descHeader.parentElement;
  headerRow.style.display = "flex";
  headerRow.style.alignItems = "center";
  headerRow.appendChild(btn);
  return true;
}

// --- Complete Ticket dialog: ✨ 📝 ⚡ knoppen bij het "reason" tekstveld ---
function injectCompleteTicketDialogButtons() {
  if (document.getElementById("ln-completetix-btn")) return true;

  // Herkenningsteken: label "Please enter a reason for completing this ticket"
  let reasonLabel = null;
  for (const el of document.querySelectorAll("div, span, label")) {
    if (el.children.length === 0 &&
        el.textContent.trim().toLowerCase().includes("reason for completing")) {
      reasonLabel = el;
      break;
    }
  }
  if (!reasonLabel) return false;

  // Zoek de dialog-container die zowel textarea als Checkbox2 bevat
  let dialogContainer = reasonLabel.parentElement;
  while (dialogContainer && dialogContainer !== document.body) {
    if (dialogContainer.querySelector("textarea") &&
        dialogContainer.querySelector("div.Checkbox2")) break;
    dialogContainer = dialogContainer.parentElement;
  }
  if (!dialogContainer || dialogContainer === document.body) return false;

  const textarea = dialogContainer.querySelector("textarea");
  if (!textarea) return false;

  // Zet focus-tracker zodat polish/samenvatting/snippet het veld kunnen vinden
  const setTarget = () => {
    window._lnLastEditTarget = { text: () => textarea.value.trim(), method: "textarea", el: textarea };
    return textarea;
  };
  textarea.addEventListener("focus", setTarget);

  // Knoppengroep
  const btnGroup = document.createElement("span");
  btnGroup.id = "ln-completetix-btn";
  btnGroup.style.cssText = "display:inline-flex;align-items:center;gap:6px;margin-left:8px;vertical-align:middle;";

  // ✨ Polijsten
  const polishBtn = document.createElement("span");
  polishBtn.title = "Tekst polijsten met Lime Networks AI";
  polishBtn.textContent = "✨";
  polishBtn.style.cssText = "cursor:pointer;font-size:14px;user-select:none;";
  polishBtn.addEventListener("mouseenter", () => polishBtn.style.opacity = "0.7");
  polishBtn.addEventListener("mouseleave", () => polishBtn.style.opacity = "1");
  polishBtn.addEventListener("click", async (e) => {
    e.preventDefault(); e.stopPropagation();
    const ta = setTarget();
    const text = ta.value.trim();
    if (!text) { showToast("⚠️ Geen tekst om te polijsten", "warning"); return; }
    showToast("⏳ Bezig met polijsten...", "loading");
    try {
      const result = await callAI(text);
      ta.value = result;
      ta.dispatchEvent(new Event("input",  { bubbles: true }));
      ta.dispatchEvent(new Event("change", { bubbles: true }));
      showToast("✅ Tekst gepolijst!", "success");
    } catch(err) {
      showToast("❌ " + err.message, "error");
    }
  });
  btnGroup.appendChild(polishBtn);

  // 📝 Afsluitende samenvatting
  const summaryBtn = document.createElement("span");
  summaryBtn.title = "Afsluitende samenvatting genereren";
  summaryBtn.textContent = "📝";
  summaryBtn.style.cssText = "cursor:pointer;font-size:14px;user-select:none;";
  summaryBtn.addEventListener("mouseenter", () => summaryBtn.style.opacity = "0.7");
  summaryBtn.addEventListener("mouseleave", () => summaryBtn.style.opacity = "1");
  summaryBtn.addEventListener("click", async (e) => {
    e.preventDefault(); e.stopPropagation();
    setTarget();
    await generateAndFillSummary("closed");
  });
  btnGroup.appendChild(summaryBtn);

  // ⚡ Snelkoppelingen
  if (_cachedFeatures.snelkoppelingen) {
    const snippetsWrapper = document.createElement("span");
    snippetsWrapper.style.cssText = "display:inline;position:relative;";

    const snippetsBtn = document.createElement("span");
    snippetsBtn.title = "Snelkoppeling invoegen";
    snippetsBtn.textContent = "⚡";
    snippetsBtn.style.cssText = "cursor:pointer;font-size:14px;user-select:none;";
    snippetsBtn.addEventListener("mouseenter", () => snippetsBtn.style.opacity = "0.7");
    snippetsBtn.addEventListener("mouseleave", () => snippetsBtn.style.opacity = "1");

    const snippetsMenu = document.createElement("div");
    snippetsMenu.setAttribute("data-ln-menu", "true");
    snippetsMenu.style.cssText = `display:none;position:absolute;top:22px;left:0;z-index:9999999;
      background:#083E47;border:1.5px solid #76B82A;border-radius:8px;
      box-shadow:0 4px 16px rgba(0,0,0,0.4);min-width:220px;max-height:200px;overflow-y:auto;
      font-family:Segoe UI,system-ui,sans-serif;`;

    snippetsBtn.addEventListener("click", async (ev) => {
      ev.preventDefault(); ev.stopPropagation();
      if (snippetsMenu.style.display === "block") { snippetsMenu.style.display = "none"; return; }
      snippetsMenu.innerHTML = "";
      const snippets = await new Promise(resolve =>
        chrome.storage.local.get(["ln_snippets"], r => resolve(r.ln_snippets || [
          "Klant teruggebeld, geen gehoor.",
          "Wachtend op reactie klant.",
          "Remote sessie uitgevoerd, probleem opgelost.",
          "Ticket gesloten na bevestiging klant.",
          "Doorgestuurd naar 2e lijn.",
          "Onderzocht, geen actie vereist."
        ]))
      );
      if (snippets.length === 0) {
        const empty = document.createElement("div");
        empty.style.cssText = "padding:10px 14px;font-size:12px;color:#4b5563;font-style:italic;";
        empty.textContent = "Voeg snelkoppelingen toe via de extensie";
        snippetsMenu.appendChild(empty);
      } else {
        snippets.forEach(text => {
          const item = document.createElement("div");
          item.style.cssText = "padding:8px 14px;cursor:pointer;border-bottom:1px solid #0d4f5c;";
          item.innerHTML = `<div style="font-size:12px;color:#F7F8F9;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"
            title="${esc(text)}">${esc(text)}</div>`;
          item.addEventListener("mouseenter", () => item.style.background = "#0d4f5c");
          item.addEventListener("mouseleave", () => item.style.background = "transparent");
          item.addEventListener("click", (ev2) => {
            ev2.preventDefault(); ev2.stopPropagation();
            snippetsMenu.style.display = "none";
            setTarget();
            insertSnippet(text);
          });
          snippetsMenu.appendChild(item);
        });
        if (snippetsMenu.lastChild) snippetsMenu.lastChild.style.borderBottom = "none";
      }
      snippetsMenu.style.display = "block";
    });

    snippetsWrapper.appendChild(snippetsBtn);
    snippetsWrapper.appendChild(snippetsMenu);
    btnGroup.appendChild(snippetsWrapper);
  }

  // Plak knoppen naast het label
  reasonLabel.style.display = "inline-flex";
  reasonLabel.style.alignItems = "center";
  reasonLabel.appendChild(btnGroup);
  return true;
}

// --- Polijsten ---
async function handlePolish() {
  const source = getSelectedText();
  if (!source || !source.text) {
    showToast("⚠️ Geen tekst gevonden. Selecteer tekst of klik in een tekstveld.", "warning");
    return;
  }
  showToast("⏳ Bezig met polijsten...", "loading");
  try {
    const result = await callAI(source.text);
    const ok = replaceText(source, result);
    if (ok) {
      showToast("✅ Tekst gepolijst!", "success");
    } else {
      await navigator.clipboard.writeText(result);
      showToast("📋 Gekopieerd naar klembord — plak handmatig (Ctrl+V)", "warning");
    }
  } catch(e) {
    showToast("❌ Fout: " + e.message, "error");
  }
}