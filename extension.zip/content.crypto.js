// ============================================================
// Lime Networks — content.crypto.js
// Decryptie van opgeslagen API keys
// ============================================================

async function getEncryptionKey() {
  const rawKey = chrome.runtime.id + "-lime-networks-encryption-key";
  return await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(rawKey.padEnd(32, "0").substring(0, 32)),
    { name: "AES-GCM" }, false, ["encrypt", "decrypt"]
  );
}

async function decryptValue(ciphertext) {
  if (!ciphertext) return "";
  try {
    const key = await getEncryptionKey();
    const combined = Uint8Array.from(atob(ciphertext), c => c.charCodeAt(0));
    const decrypted = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv: combined.slice(0, 12) }, key, combined.slice(12)
    );
    return new TextDecoder().decode(decrypted);
  } catch(e) { return ciphertext; }
}

async function loadSettings() {
  return new Promise((resolve) => {
    chrome.storage.local.get(["claudeKey","openaiKey","provider","style","customPrompt"], async (s) => {
      resolve({
        claudeKey:    await decryptValue(s.claudeKey || ""),
        openaiKey:    await decryptValue(s.openaiKey || ""),
        provider:     s.provider     || "claude",
        style:        s.style        || "leesbaar",
        customPrompt: s.customPrompt || ""
      });
    });
  });
}