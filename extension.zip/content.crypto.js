// ============================================================
// Lime Networks — content.crypto.js
// Decryptie van opgeslagen API keys
// ============================================================
//
// THREAT MODEL — let op: deze "encryptie" is feitelijk obfuscatie, geen sterke security.
// De AES-256-GCM sleutel wordt deterministisch afgeleid uit chrome.runtime.id, dat vast
// staat door de "key" in manifest.json en publiek is. Iedereen met read-toegang tot
// de broncode kan de sleutel reproduceren.
//
// WAT DIT WEL DOET:
// - Beschermt tegen casual inspectie van chrome.storage (DevTools, geëxporteerde profielen)
// - Voorkomt dat keys per ongeluk in logs/screenshots opduiken in plaintext
//
// WAT DIT NIET DOET:
// - Beschermt NIET tegen lokale malware met toegang tot chrome.storage van deze extensie
// - Beschermt NIET tegen andere kwaadaardige Chrome extensies met "storage" permissie en
//   knowledge van de extensie-ID (alleen als ze in dezelfde profile draaien — wat normaal
//   gesproken niet kan zonder dat de gebruiker ze installeert)
// - Vervangt OS-level bescherming niet
//
// Voor sterkere bescherming: API keys via een externe secret-store (1Password, Bitwarden)
// of vraag bij elke sessie een wachtwoord en derive de sleutel met PBKDF2.

async function getEncryptionKey() {
  const rawKey = chrome.runtime.id + "-lime-networks-encryption-key";
  return await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(rawKey.padEnd(32, "0").substring(0, 32)),
    { name: "AES-GCM" }, false, ["encrypt", "decrypt"]
  );
}

async function decryptValue(ciphertext) {
  if (!ciphertext) return "";
  try {
    const key = await getEncryptionKey();
    const combined = Uint8Array.from(atob(ciphertext), c => c.charCodeAt(0));
    const decrypted = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv: combined.slice(0, 12) }, key, combined.slice(12)
    );
    return new TextDecoder().decode(decrypted);
  } catch(e) { return ciphertext; }
}

async function loadSettings() {
  return new Promise((resolve) => {
    chrome.storage.local.get(["claudeKey","openaiKey","provider","style","customPrompt"], async (s) => {
      resolve({
        claudeKey:    await decryptValue(s.claudeKey || ""),
        openaiKey:    await decryptValue(s.openaiKey || ""),
        provider:     s.provider     || "claude",
        style:        s.style        || "leesbaar",
        customPrompt: s.customPrompt || ""
      });
    });
  });
}

// --- ITGlue webhook instellingen ---
// Bewust GEEN default webhook URL. Een hardcoded fallback naar een echte N8N-instance
// zou publiek meegaan in het gepubliceerde extension.zip (zie F11 — dit is exact de
// fout die de eerdere Script-tab fataal werd, zie DISTRIBUTION.md/README voor context).
// Leeg totdat de engineer 'm zelf instelt via ⚙️.
async function loadItglueSettings() {
  return new Promise((resolve) => {
    chrome.storage.local.get(["ln_itglue_webhook", "ln_itglue_token"], async (s) => {
      resolve({
        webhookUrl: s.ln_itglue_webhook || "",
        token:      await decryptValue(s.ln_itglue_token || "")
      });
    });
  });
}