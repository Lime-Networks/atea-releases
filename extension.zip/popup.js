// ============================================================
// Lime Networks — popup.js
// Popup UI: polijsten, snelkoppelingen, instellingen, updates
// ============================================================

// --- Update check ---
const GITHUB_RAW      = "https://raw.githubusercontent.com/Lime-Networks/atea-releases/main";
const GITHUB_RELEASES = "https://github.com/Lime-Networks/atea-releases";
const GITHUB_ZIP      = "https://raw.githubusercontent.com/Lime-Networks/atea-releases/main/extension.zip";
const UPDATE_CACHE_KEY = "ln_update_cache";
const UPDATE_CACHE_TTL = 4 * 60 * 60 * 1000; // 4 uur

function compareVersions(a, b) {
  const pa = a.split(".").map(Number);
  const pb = b.split(".").map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const diff = (pa[i] || 0) - (pb[i] || 0);
    if (diff !== 0) return diff;
  }
  return 0;
}

async function checkForUpdate(force = false) {
  const currentVersion = chrome.runtime.getManifest().version;

  if (!force) {
    const cached = await new Promise(r => chrome.storage.local.get([UPDATE_CACHE_KEY], d => r(d[UPDATE_CACHE_KEY])));
    if (cached && Date.now() - cached.ts < UPDATE_CACHE_TTL) {
      if (compareVersions(cached.version, currentVersion) > 0) showUpdateAvailable(cached.version, cached.notes);
      return;
    }
  }

  try {
    const res  = await fetch(`${GITHUB_RAW}/version.json?t=${Date.now()}`);
    if (!res.ok) { setUpdateStatus(`Kan niet controleren — HTTP ${res.status}`); return; }
    const data = await res.json();
    chrome.storage.local.set({ [UPDATE_CACHE_KEY]: { version: data.version, notes: data.notes || "", ts: Date.now() } });
    if (compareVersions(data.version, currentVersion) > 0) {
      showUpdateAvailable(data.version, data.notes || "");
    } else {
      setUpdateStatus("Geen updates beschikbaar.");
    }
  } catch(e) { setUpdateStatus("Kan niet controleren — " + e.message); }
}

function setUpdateStatus(msg) {
  const el = document.getElementById("update-status");
  if (!el) return;
  el.textContent = msg;
  el.style.display = "block";
}

function showUpdateAvailable(newVersion, notes) {
  setUpdateStatus(`Versie ${newVersion} beschikbaar${notes ? " — " + notes : ""}`);
  document.getElementById("update-changelog-btn").href = GITHUB_RELEASES;

  const actions = document.getElementById("update-actions");
  actions.style.display = "flex";

  const btn = document.getElementById("update-install-btn");
  btn.onclick = () => {
    btn.textContent = "Bezig...";
    btn.disabled = true;
    chrome.runtime.sendNativeMessage("com.limenetworks.atea", { action: "update" }, (resp) => {
      if (chrome.runtime.lastError || !resp || !resp.success) {
        btn.textContent = "Bijwerken";
        btn.disabled = false;
        // Reden meesturen i.p.v. weggooien. Zonder deze tekst is een mislukte update niet
        // te diagnosticeren: lastError betekent dat de host niet bereikbaar was (niet
        // geregistreerd, andere browser, ID-mismatch), resp.error komt van de host zelf.
        const reden = chrome.runtime.lastError?.message
                   || resp?.error
                   || "geen antwoord van de update-host";
        setUpdateStatus("Automatisch bijwerken mislukt — " + reden + ". Download handmatig via Changelog.");
        console.error("[ATEA] automatisch bijwerken mislukt:", reden);
        return;
      }
      btn.textContent = "Herlaad";
      btn.disabled = false;
      setUpdateStatus("Update geinstalleerd — klik Herlaad om te activeren.");
      chrome.storage.local.remove([UPDATE_CACHE_KEY]);
      btn.onclick = () => chrome.runtime.reload();
    });
  };
}

// --- Versleuteling via Web Crypto API (AES-256-GCM) ---
async function getEncryptionKey() {
  const rawKey = chrome.runtime.id + "-lime-networks-encryption-key";
  return await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(rawKey.padEnd(32, "0").substring(0, 32)),
    { name: "AES-GCM" }, false, ["encrypt", "decrypt"]
  );
}

async function encryptValue(plaintext) {
  if (!plaintext) return "";
  try {
    const key = await getEncryptionKey();
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const encrypted = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, new TextEncoder().encode(plaintext));
    const combined = new Uint8Array(iv.byteLength + encrypted.byteLength);
    combined.set(iv, 0); combined.set(new Uint8Array(encrypted), iv.byteLength);
    return btoa(String.fromCharCode(...combined));
  } catch(e) { return plaintext; }
}

async function decryptValue(ciphertext) {
  if (!ciphertext) return "";
  try {
    const key = await getEncryptionKey();
    const combined = Uint8Array.from(atob(ciphertext), c => c.charCodeAt(0));
    const decrypted = await crypto.subtle.decrypt({ name: "AES-GCM", iv: combined.slice(0,12) }, key, combined.slice(12));
    return new TextDecoder().decode(decrypted);
  } catch(e) { return ciphertext; }
}

// --- Taal detectie ---
function detectLang(text) {
  const nlWords = new Set(["het","een","van","niet","dat","dit","heeft","zijn","voor","met","bij","naar","ook","aan","maar","door","nog","wel","geen","meer","hebben","werd","kunnen","moet","zou","worden","deze","die","als","dan","om","zij","wij","hun","ons","toch","want","dus","echter","daarna","vervolgens","nadat","hierna","tevens","waarbij","waardoor","indien","alsmede"]);
  const enWords = new Set(["the","and","for","are","but","not","you","all","can","had","her","was","one","our","out","get","has","him","his","how","new","now","see","way","who","did","its","let","put","say","she","too","use","with","that","this","have","from","they","will","been","could","would","should","there","their","what","said","each","which","made","then","time","look","only","come","over","also","back","after","work","first","well","even","want","give","most","tell","much","keep","good"]);
  const words = text.toLowerCase().replace(/[^a-z\s]/g,"").split(/\s+/).filter(w => w.length > 1);
  const nl = words.filter(w => nlWords.has(w)).length;
  const en = words.filter(w => enWords.has(w)).length;
  return (nl >= 2 && nl / words.length > 0.10 && nl >= en) ? "nl" : "en";
}

// Stijlregels zijn language-agnostic — voorbeelden bilingual waar relevant,
// zodat de output-taal niet impliciet richting één taal wordt gestuurd.
const stylePrompts = {
  lime_style: `- Short, active sentences in first person when relevant ("I called Peter" / "Ik heb Peter gesproken" — NOT passive constructions like "Contact was made with Peter" / "Er is contact geweest met Peter")
- Everyday language — no corporate or overly formal words
- Keep technical terms as-is (back-up, licentie, uitrollen, tenant, proxy, SSO, AVD)
- No formal greetings like "Geachte" or "Dear Sir/Madam", no formal closings
- State outcomes directly ("Probleem opgelost" / "Issue resolved" — NOT "De situatie is naar tevredenheid afgehandeld" / "The situation has been handled satisfactorily")
- Do NOT pad or expand text that is already clear. Only minimal corrections if input is already natural.`,
  lime_tech: `- Short, active sentences. Everyday language.
- Include technical details (system names, error codes, versions, configurations) ONLY if they appear in the input — never invent them
- Keep technical terms as-is (back-up, licentie, uitrollen, tenant, proxy, SSO, AVD)
- No formal greetings or closings
- Do NOT pad or expand. Do NOT add troubleshooting steps that are not in the input.`,
  leesbaar: `- Short, active sentences. Everyday language.
- Keep technical terms as-is (back-up, licentie, uitrollen, tenant, proxy, SSO, AVD)
- No formal greetings or closings
- If the input is already natural and correct, make only minimal corrections.`
};

function buildSystemPrompt(lang, style, customPrompt) {
  const custom = customPrompt ? `\nExtra instructions: ${customPrompt}` : "";
  const rules  = stylePrompts[style] || stylePrompts["leesbaar"];
  return `You are an expert MSP time entry writer.
YOU MUST WRITE THE OUTPUT IN ${lang === "nl" ? "DUTCH (Nederlands)" : "ENGLISH"}. DO NOT USE ANY OTHER LANGUAGE.
Style (apply in the target language):
${rules}
General rules: professional, client-friendly, past tense, no filler phrases.${custom}
Output ONLY the polished time entry text — no labels, no quotes, no preamble.`;
}

function loadSettings(cb) {
  chrome.storage.local.get(["claudeKey","openaiKey","provider","style","customPrompt"], async (r) => {
    cb({
      claudeKey:    await decryptValue(r.claudeKey || ""),
      openaiKey:    await decryptValue(r.openaiKey || ""),
      provider:     r.provider     || "claude",
      style:        r.style        || "lime_style",
      customPrompt: r.customPrompt || ""
    });
  });
}

async function saveSettings(data, cb) {
  const s = { ...data };
  if (data.claudeKey !== undefined) s.claudeKey = data.claudeKey ? await encryptValue(data.claudeKey) : "";
  if (data.openaiKey !== undefined) s.openaiKey = data.openaiKey ? await encryptValue(data.openaiKey) : "";
  chrome.storage.local.set(s, cb);
}

// --- Features laden/opslaan ---
const FEATURES_KEY = "ln_features";
const DEFAULT_FEATURES = {
  mailDraft: true, snelkoppelingen: true,
  toolbarPolish: true, toolbarSummary: true, toolbarSnippets: true
};

async function loadFeatures() {
  return new Promise(resolve => {
    chrome.storage.local.get([FEATURES_KEY], r => {
      resolve({ ...DEFAULT_FEATURES, ...(r[FEATURES_KEY] || {}) });
    });
  });
}

async function saveFeatures(features) {
  return new Promise(resolve => chrome.storage.local.set({ [FEATURES_KEY]: features }, resolve));
}

async function callAI(userContent, lang) {
  return new Promise((resolve, reject) => {
    loadSettings(async (s) => {
      const sysPrompt = buildSystemPrompt(lang, s.style || "leesbaar", s.customPrompt || "");
      try {
        if ((s.provider || "claude") === "openai") {
          if (!s.openaiKey) return reject(new Error("Geen ChatGPT API key ingesteld."));
          const res = await fetch("https://api.openai.com/v1/chat/completions", {
            method: "POST", headers: { "Content-Type": "application/json", "Authorization": `Bearer ${s.openaiKey}` },
            body: JSON.stringify({ model: "gpt-4o", max_tokens: 1000, messages: [{ role: "system", content: sysPrompt }, { role: "user", content: userContent }] })
          });
          const data = await res.json();
          if (data.error) return reject(new Error(data.error.message));
          resolve(data.choices?.[0]?.message?.content || "");
        } else {
          if (!s.claudeKey) return reject(new Error("Geen Claude API key ingesteld."));
          const res = await fetch("https://api.anthropic.com/v1/messages", {
            method: "POST", headers: { "Content-Type": "application/json", "x-api-key": s.claudeKey, "anthropic-version": "2023-06-01", "anthropic-dangerous-direct-browser-access": "true" },
            body: JSON.stringify({ model: "claude-haiku-4-5-20251001", max_tokens: 1000, system: sysPrompt, messages: [{ role: "user", content: userContent }] })
          });
          const data = await res.json();
          if (data.error) return reject(new Error(data.error.message));
          resolve(data.content?.find(b => b.type === "text")?.text || "");
        }
      } catch(e) { reject(e); }
    });
  });
}

// --- Stijl-indicator ---
function updateStyleLabel(style) {
  const el = document.getElementById("active-style-label");
  const labels = { lime_style: "Lime Style", lime_tech: "Lime Style + tech" };
  if (el) el.textContent = labels[style] || "Lime Style";
}

// --- Dark/light mode ---
(function initTheme() {
  const saved = localStorage.getItem("ln-theme");
  const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
  const isDark = saved ? saved === "dark" : prefersDark;
  if (!isDark) document.body.classList.add("light");
  document.getElementById("theme-btn").textContent = isDark ? "🌙" : "☀️";
})();

document.getElementById("theme-btn").addEventListener("click", () => {
  const isLight = document.body.classList.toggle("light");
  document.getElementById("theme-btn").textContent = isLight ? "☀️" : "🌙";
  localStorage.setItem("ln-theme", isLight ? "light" : "dark");
});

// --- Snelkoppelingen ---
const SNIPPETS_KEY = "ln_snippets";
const DEFAULT_SNIPPETS = [
  "Klant teruggebeld, geen gehoor.",
  "Wachtend op reactie klant.",
  "Remote sessie uitgevoerd, probleem opgelost.",
  "Ticket gesloten na bevestiging klant.",
  "Doorgestuurd naar 2e lijn.",
  "Onderzocht, geen actie vereist."
];

async function loadSnippets() {
  return new Promise(resolve => {
    chrome.storage.local.get([SNIPPETS_KEY], r => resolve(r[SNIPPETS_KEY] || DEFAULT_SNIPPETS));
  });
}

async function saveSnippets(snippets) {
  return new Promise(resolve => chrome.storage.local.set({ [SNIPPETS_KEY]: snippets }, resolve));
}

async function renderSnippets() {
  const snippets = await loadSnippets();
  const list = document.getElementById("snippets-list");
  list.innerHTML = "";
  snippets.forEach((text, i) => {
    const item = document.createElement("div");
    item.className = "snippet-item";
    item.style.cssText = "display:flex;align-items:center;gap:6px;";

    const label = document.createElement("span");
    label.textContent = text;
    label.title = "Klik om te kopiëren";
    label.style.cssText = "flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;cursor:pointer;";
    label.addEventListener("click", () => {
      navigator.clipboard.writeText(text);
      const orig = label.textContent;
      label.textContent = "✓ Gekopieerd!";
      item.style.borderColor = "var(--green)";
      setTimeout(() => { label.textContent = orig; item.style.borderColor = ""; }, 1500);
    });

    const delBtn = document.createElement("button");
    delBtn.textContent = "×";
    delBtn.title = "Verwijderen";
    delBtn.style.cssText = "background:none;border:none;color:#6b7280;font-size:16px;cursor:pointer;padding:0 2px;flex-shrink:0;line-height:1;";
    delBtn.addEventListener("mouseenter", () => delBtn.style.color = "#ef4444");
    delBtn.addEventListener("mouseleave", () => delBtn.style.color = "#6b7280");
    delBtn.addEventListener("click", async () => {
      const current = await loadSnippets();
      await saveSnippets(current.filter((_, idx) => idx !== i));
      renderSnippets();
    });

    item.appendChild(label);
    item.appendChild(delBtn);
    list.appendChild(item);
  });
}

document.getElementById("snippet-add-btn").addEventListener("click", async () => {
  const input = document.getElementById("snippet-input");
  const val = input.value.trim();
  if (!val) return;
  const current = await loadSnippets();
  current.push(val);
  await saveSnippets(current);
  input.value = "";
  renderSnippets();
});

document.getElementById("snippet-input").addEventListener("keydown", e => {
  if (e.key === "Enter") document.getElementById("snippet-add-btn").click();
});

renderSnippets();


// --- Tabs ---
let settingsOpen = false;
let featuresOpen = false;

function closeOverlays() {
  settingsOpen = false;
  featuresOpen = false;
  document.getElementById("settings-btn").style.opacity = "0.6";
  document.getElementById("features-btn").style.opacity = "0.6";
}

document.querySelectorAll(".tab").forEach(tab => {
  tab.addEventListener("click", () => {
    document.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
    document.querySelectorAll(".tab-content").forEach(c => c.classList.add("hidden"));
    tab.classList.add("active");
    document.getElementById("tab-" + tab.dataset.tab).classList.remove("hidden");
    closeOverlays();
  });
});

document.getElementById("settings-btn").addEventListener("click", () => {
  settingsOpen = !settingsOpen;
  featuresOpen = false;
  document.getElementById("features-btn").style.opacity = "0.6";
  document.querySelectorAll(".tab-content").forEach(c => c.classList.add("hidden"));
  document.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
  if (settingsOpen) {
    document.getElementById("tab-settings").classList.remove("hidden");
    document.getElementById("settings-btn").style.opacity = "1";
  } else {
    document.getElementById("tab-quick").classList.remove("hidden");
    document.querySelector(".tab[data-tab='quick']").classList.add("active");
    document.getElementById("settings-btn").style.opacity = "0.6";
  }
});

document.getElementById("features-btn").addEventListener("click", () => {
  featuresOpen = !featuresOpen;
  settingsOpen = false;
  document.getElementById("settings-btn").style.opacity = "0.6";
  document.querySelectorAll(".tab-content").forEach(c => c.classList.add("hidden"));
  document.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
  if (featuresOpen) {
    document.getElementById("tab-features").classList.remove("hidden");
    document.getElementById("features-btn").style.opacity = "1";
  } else {
    document.getElementById("tab-quick").classList.remove("hidden");
    document.querySelector(".tab[data-tab='quick']").classList.add("active");
    document.getElementById("features-btn").style.opacity = "0.6";
  }
});


document.querySelectorAll(".change-key-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    const t = btn.dataset.target;
    document.getElementById(`${t}-key-display`).classList.add("hidden");
    document.getElementById(`${t}-key-input-row`).classList.remove("hidden");
    document.getElementById(`${t}-api-key`).value = "";
    document.getElementById(`${t}-api-key`).focus();
  });
});

document.querySelectorAll(".btn-copy").forEach(btn => {
  btn.addEventListener("click", () => {
    navigator.clipboard.writeText(document.getElementById(btn.dataset.target).innerText);
    btn.textContent = "✓ Gekopieerd!";
    setTimeout(() => btn.textContent = "Kopieer", 2000);
  });
});

document.getElementById("save-settings").addEventListener("click", async () => {
  const claudeKey    = document.getElementById("claude-api-key").value.trim();
  const openaiKey    = document.getElementById("openai-api-key").value.trim();
  const provider     = document.querySelector('input[name="ai-provider"]:checked')?.value || "claude";
  const style        = document.querySelector('input[name="style"]:checked')?.value || "leesbaar";
  const customPrompt = document.getElementById("custom-prompt").value.trim();
  const status       = document.getElementById("settings-status");
  const toSave = { provider, style, customPrompt };
  if (claudeKey) toSave.claudeKey = claudeKey;
  if (openaiKey) toSave.openaiKey = openaiKey;
  await saveSettings(toSave, async () => {
    status.textContent = "✓ Opgeslagen!";
    status.style.color = "#84cc16";
    setTimeout(() => status.textContent = "", 2000);
    if (claudeKey) { document.getElementById("claude-key-display").classList.remove("hidden"); document.getElementById("claude-key-input-row").classList.add("hidden"); }
    if (openaiKey) { document.getElementById("openai-key-display").classList.remove("hidden"); document.getElementById("openai-key-input-row").classList.add("hidden"); }
    updateStyleLabel(style);
  });
});

document.getElementById("open-shortcuts-btn").addEventListener("click", () => {
  chrome.tabs.create({ url: navigator.userAgent.includes("Edg/") ? "edge://extensions/shortcuts" : "chrome://extensions/shortcuts" });
});

document.getElementById("quick-btn").addEventListener("click", async () => {
  const input = document.getElementById("quick-input").value.trim();
  if (!input) return;
  const btn = document.getElementById("quick-btn");
  btn.textContent = "Bezig..."; btn.disabled = true;
  try {
    const result = await callAI(`Polish this time entry:\n\n${input}`, detectLang(input));
    document.getElementById("quick-result").textContent = result;
    document.getElementById("quick-output").classList.remove("hidden");
  } catch(e) { alert("Fout: " + e.message); }
  btn.textContent = "✨ Polijst Entry"; btn.disabled = false;
});

window.addEventListener("load", () => {
  const currentVersion = chrome.runtime.getManifest().version;
  const versionEl = document.getElementById("update-current-version");
  if (versionEl) versionEl.textContent = `Geinstalleerd: v${currentVersion}`;

  document.getElementById("update-check-btn").addEventListener("click", () => {
    setUpdateStatus("Controleren...");
    document.getElementById("update-actions").style.display = "none";
    checkForUpdate(true);
  });

  checkForUpdate();

  loadSettings((s) => {
    const pr = document.querySelector(`input[name="ai-provider"][value="${s.provider}"]`);
    if (pr) pr.checked = true;
    if (s.claudeKey) { document.getElementById("claude-key-display").classList.remove("hidden"); document.getElementById("claude-key-input-row").classList.add("hidden"); }
    if (s.openaiKey) { document.getElementById("openai-key-display").classList.remove("hidden"); document.getElementById("openai-key-input-row").classList.add("hidden"); }
    const sr = document.querySelector(`input[name="style"][value="${s.style}"]`);
    if (sr) sr.checked = true;
    else document.querySelector('input[name="style"][value="lime_style"]').checked = true;
    if (s.customPrompt) document.getElementById("custom-prompt").value = s.customPrompt;
    updateStyleLabel(s.style || "leesbaar");
  });

  // Features panel initialiseren
  loadFeatures().then(features => {
    document.getElementById("feat-mail").checked            = features.mailDraft;
    document.getElementById("feat-snippets").checked        = features.snelkoppelingen;
    document.getElementById("feat-toolbar-polish").checked  = features.toolbarPolish  !== false;
    document.getElementById("feat-toolbar-summary").checked = features.toolbarSummary !== false;
    document.getElementById("feat-toolbar-snippets").checked= features.toolbarSnippets !== false;

    const allFeatIds = ["feat-mail","feat-snippets","feat-toolbar-polish","feat-toolbar-summary","feat-toolbar-snippets"];
    allFeatIds.forEach(id => {
      document.getElementById(id).addEventListener("change", async () => {
        const f = {
          mailDraft:       document.getElementById("feat-mail").checked,
          snelkoppelingen: document.getElementById("feat-snippets").checked,
          toolbarPolish:   document.getElementById("feat-toolbar-polish").checked,
          toolbarSummary:  document.getElementById("feat-toolbar-summary").checked,
          toolbarSnippets: document.getElementById("feat-toolbar-snippets").checked
        };
        await saveFeatures(f);
        const status = document.getElementById("features-status");
        status.textContent = "✓ Opgeslagen!";
        setTimeout(() => { status.textContent = ""; }, 2000);
      });
    });
  });
});
