// ============================================================
// Lime Networks — popup.js
// Inclusief database tab
// ============================================================

// --- Update check ---
const GITHUB_RAW      = "https://raw.githubusercontent.com/Lime-Networks/atea-releases/main";
const GITHUB_RELEASES = "https://github.com/Lime-Networks/atea-releases";
const GITHUB_ZIP      = "https://raw.githubusercontent.com/Lime-Networks/atea-releases/main/extension.zip";
const UPDATE_CACHE_KEY = "ln_update_cache";
const UPDATE_CACHE_TTL = 4 * 60 * 60 * 1000; // 4 uur

function compareVersions(a, b) {
  const pa = a.split(".").map(Number);
  const pb = b.split(".").map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const diff = (pa[i] || 0) - (pb[i] || 0);
    if (diff !== 0) return diff;
  }
  return 0;
}

async function checkForUpdate(force = false) {
  const currentVersion = chrome.runtime.getManifest().version;

  if (!force) {
    const cached = await new Promise(r => chrome.storage.local.get([UPDATE_CACHE_KEY], d => r(d[UPDATE_CACHE_KEY])));
    if (cached && Date.now() - cached.ts < UPDATE_CACHE_TTL) {
      if (compareVersions(cached.version, currentVersion) > 0) showUpdateAvailable(cached.version, cached.notes);
      return;
    }
  }

  try {
    const res  = await fetch(`${GITHUB_RAW}/version.json?t=${Date.now()}`);
    if (!res.ok) { setUpdateStatus(`Kan niet controleren — HTTP ${res.status}`); return; }
    const data = await res.json();
    chrome.storage.local.set({ [UPDATE_CACHE_KEY]: { version: data.version, notes: data.notes || "", ts: Date.now() } });
    if (compareVersions(data.version, currentVersion) > 0) {
      showUpdateAvailable(data.version, data.notes || "");
    } else {
      setUpdateStatus("Geen updates beschikbaar.");
    }
  } catch(e) { setUpdateStatus("Kan niet controleren — " + e.message); }
}

function setUpdateStatus(msg) {
  const el = document.getElementById("update-status");
  if (!el) return;
  el.textContent = msg;
  el.style.display = "block";
}

function showUpdateAvailable(newVersion, notes) {
  setUpdateStatus(`Versie ${newVersion} beschikbaar${notes ? " — " + notes : ""}`);
  document.getElementById("update-changelog-btn").href = GITHUB_RELEASES;

  const actions = document.getElementById("update-actions");
  actions.style.display = "flex";

  const btn = document.getElementById("update-install-btn");
  btn.onclick = () => {
    btn.textContent = "Bezig...";
    btn.disabled = true;
    chrome.runtime.sendNativeMessage("com.limenetworks.atea", { action: "update" }, (resp) => {
      if (chrome.runtime.lastError || !resp || !resp.success) {
        btn.textContent = "Bijwerken";
        btn.disabled = false;
        // Reden meesturen i.p.v. weggooien. Zonder deze tekst is een mislukte update niet
        // te diagnosticeren: lastError betekent dat de host niet bereikbaar was (niet
        // geregistreerd, andere browser, ID-mismatch), resp.error komt van de host zelf.
        const reden = chrome.runtime.lastError?.message
                   || resp?.error
                   || "geen antwoord van de update-host";
        setUpdateStatus("Automatisch bijwerken mislukt — " + reden + ". Download handmatig via Changelog.");
        console.error("[ATEA] automatisch bijwerken mislukt:", reden);
        return;
      }
      btn.textContent = "Herlaad";
      btn.disabled = false;
      setUpdateStatus("Update geinstalleerd — klik Herlaad om te activeren.");
      chrome.storage.local.remove([UPDATE_CACHE_KEY]);
      btn.onclick = () => chrome.runtime.reload();
    });
  };
}

// --- Versleuteling via Web Crypto API (AES-256-GCM) ---
async function getEncryptionKey() {
  const rawKey = chrome.runtime.id + "-lime-networks-encryption-key";
  return await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(rawKey.padEnd(32, "0").substring(0, 32)),
    { name: "AES-GCM" }, false, ["encrypt", "decrypt"]
  );
}

async function encryptValue(plaintext) {
  if (!plaintext) return "";
  try {
    const key = await getEncryptionKey();
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const encrypted = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, new TextEncoder().encode(plaintext));
    const combined = new Uint8Array(iv.byteLength + encrypted.byteLength);
    combined.set(iv, 0); combined.set(new Uint8Array(encrypted), iv.byteLength);
    return btoa(String.fromCharCode(...combined));
  } catch(e) { return plaintext; }
}

async function decryptValue(ciphertext) {
  if (!ciphertext) return "";
  try {
    const key = await getEncryptionKey();
    const combined = Uint8Array.from(atob(ciphertext), c => c.charCodeAt(0));
    const decrypted = await crypto.subtle.decrypt({ name: "AES-GCM", iv: combined.slice(0,12) }, key, combined.slice(12));
    return new TextDecoder().decode(decrypted);
  } catch(e) { return ciphertext; }
}

// --- DB lezen in popup context (eigen decrypt, niet via content script) ---
const DB_KEY = "ln_solution_db";

async function popupDbGetKey() {
  const raw = chrome.runtime.id + "-lime-networks-encryption-key";
  return crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(raw.padEnd(32,"0").substring(0,32)),
    { name: "AES-GCM" }, false, ["encrypt","decrypt"]
  );
}

async function popupDbLoad() {
  return new Promise(resolve => {
    chrome.storage.local.get([DB_KEY], async r => {
      if (!r[DB_KEY]) return resolve([]);
      try {
        const key      = await popupDbGetKey();
        const combined = Uint8Array.from(atob(r[DB_KEY]), c => c.charCodeAt(0));
        const dec      = await crypto.subtle.decrypt(
          { name:"AES-GCM", iv: combined.slice(0,12) }, key, combined.slice(12)
        );
        resolve(JSON.parse(new TextDecoder().decode(dec)));
      } catch { resolve([]); }
    });
  });
}

async function loadDbStats() {
  const records = await popupDbLoad();
  const cats = {};
  records.forEach(r => { cats[r.cat] = (cats[r.cat] || 0) + 1; });
  const topCat = Object.entries(cats).sort((a,b)=>b[1]-a[1])[0];
  return { total: records.length, cats, topCat: topCat ? topCat[0] : null };
}

async function renderDbTab() {
  const stats = await loadDbStats();
  const catIcon = { email:"📧", netwerk:"🌐", account:"🔑", hardware:"💻",
                    software:"⚙️", telefoon:"📞", server:"🖥️", overig:"📋" };

  document.getElementById("db-total").textContent = stats.total;
  document.getElementById("db-top-cat").textContent = stats.topCat
    ? (catIcon[stats.topCat] || "📋") + " " + stats.topCat
    : "—";

  const list    = document.getElementById("db-cat-list");
  const emptyEl = document.getElementById("db-empty-msg");
  list.innerHTML = "";

  if (stats.total === 0) {
    emptyEl.style.display = "block";
    return;
  }
  emptyEl.style.display = "none";

  const sorted = Object.entries(stats.cats).sort((a,b) => b[1]-a[1]);
  const max    = sorted[0]?.[1] || 1;

  sorted.forEach(([cat, count]) => {
    const pct  = Math.round((count / max) * 100);
    const item = document.createElement("div");
    item.style.cssText = "display:flex;flex-direction:column;gap:3px;";
    item.innerHTML = `
      <div style="display:flex;justify-content:space-between;font-size:12px;">
        <span style="color:var(--text-primary)">${catIcon[cat] || "📋"} ${cat}</span>
        <span style="color:var(--text-muted)">${count} patroon${count !== 1 ? "en" : ""}</span>
      </div>
      <div style="height:4px;background:var(--border);border-radius:2px;">
        <div style="height:4px;width:${pct}%;background:var(--green);border-radius:2px;transition:width 0.4s;"></div>
      </div>
    `;
    list.appendChild(item);
  });
}

// --- Taal detectie ---
function detectLang(text) {
  const nlWords = new Set(["het","een","van","niet","dat","dit","heeft","zijn","voor","met","bij","naar","ook","aan","maar","door","nog","wel","geen","meer","hebben","werd","kunnen","moet","zou","worden","deze","die","als","dan","om","zij","wij","hun","ons","toch","want","dus","echter","daarna","vervolgens","nadat","hierna","tevens","waarbij","waardoor","indien","alsmede"]);
  const enWords = new Set(["the","and","for","are","but","not","you","all","can","had","her","was","one","our","out","get","has","him","his","how","new","now","see","way","who","did","its","let","put","say","she","too","use","with","that","this","have","from","they","will","been","could","would","should","there","their","what","said","each","which","made","then","time","look","only","come","over","also","back","after","work","first","well","even","want","give","most","tell","much","keep","good"]);
  const words = text.toLowerCase().replace(/[^a-z\s]/g,"").split(/\s+/).filter(w => w.length > 1);
  const nl = words.filter(w => nlWords.has(w)).length;
  const en = words.filter(w => enWords.has(w)).length;
  return (nl >= 2 && nl / words.length > 0.10 && nl >= en) ? "nl" : "en";
}

// Stijlregels zijn language-agnostic — voorbeelden bilingual waar relevant,
// zodat de output-taal niet impliciet richting één taal wordt gestuurd.
const stylePrompts = {
  lime_style: `- Short, active sentences in first person when relevant ("I called Peter" / "Ik heb Peter gesproken" — NOT passive constructions like "Contact was made with Peter" / "Er is contact geweest met Peter")
- Everyday language — no corporate or overly formal words
- Keep technical terms as-is (back-up, licentie, uitrollen, tenant, proxy, SSO, AVD)
- No formal greetings like "Geachte" or "Dear Sir/Madam", no formal closings
- State outcomes directly ("Probleem opgelost" / "Issue resolved" — NOT "De situatie is naar tevredenheid afgehandeld" / "The situation has been handled satisfactorily")
- Do NOT pad or expand text that is already clear. Only minimal corrections if input is already natural.`,
  lime_tech: `- Short, active sentences. Everyday language.
- Include technical details (system names, error codes, versions, configurations) ONLY if they appear in the input — never invent them
- Keep technical terms as-is (back-up, licentie, uitrollen, tenant, proxy, SSO, AVD)
- No formal greetings or closings
- Do NOT pad or expand. Do NOT add troubleshooting steps that are not in the input.`,
  leesbaar: `- Short, active sentences. Everyday language.
- Keep technical terms as-is (back-up, licentie, uitrollen, tenant, proxy, SSO, AVD)
- No formal greetings or closings
- If the input is already natural and correct, make only minimal corrections.`
};

function buildSystemPrompt(lang, style, customPrompt) {
  const custom = customPrompt ? `\nExtra instructions: ${customPrompt}` : "";
  const rules  = stylePrompts[style] || stylePrompts["leesbaar"];
  return `You are an expert MSP time entry writer.
YOU MUST WRITE THE OUTPUT IN ${lang === "nl" ? "DUTCH (Nederlands)" : "ENGLISH"}. DO NOT USE ANY OTHER LANGUAGE.
Style (apply in the target language):
${rules}
General rules: professional, client-friendly, past tense, no filler phrases.${custom}
Output ONLY the polished time entry text — no labels, no quotes, no preamble.`;
}

function loadSettings(cb) {
  chrome.storage.local.get(["claudeKey","openaiKey","provider","style","customPrompt"], async (r) => {
    cb({
      claudeKey:    await decryptValue(r.claudeKey || ""),
      openaiKey:    await decryptValue(r.openaiKey || ""),
      provider:     r.provider     || "claude",
      style:        r.style        || "lime_style",
      customPrompt: r.customPrompt || ""
    });
  });
}

async function saveSettings(data, cb) {
  const s = { ...data };
  if (data.claudeKey !== undefined) s.claudeKey = data.claudeKey ? await encryptValue(data.claudeKey) : "";
  if (data.openaiKey !== undefined) s.openaiKey = data.openaiKey ? await encryptValue(data.openaiKey) : "";
  chrome.storage.local.set(s, cb);
}

// --- Features laden/opslaan ---
const FEATURES_KEY = "ln_features";
const DEFAULT_FEATURES = {
  mailDraft: true, snelkoppelingen: true, oplossing: true,
  toolbarPolish: true, toolbarSummary: true, toolbarSnippets: true
};

async function loadFeatures() {
  return new Promise(resolve => {
    chrome.storage.local.get([FEATURES_KEY], r => {
      resolve({ ...DEFAULT_FEATURES, ...(r[FEATURES_KEY] || {}) });
    });
  });
}

async function saveFeatures(features) {
  return new Promise(resolve => chrome.storage.local.set({ [FEATURES_KEY]: features }, resolve));
}

async function callAI(userContent, lang) {
  return new Promise((resolve, reject) => {
    loadSettings(async (s) => {
      const sysPrompt = buildSystemPrompt(lang, s.style || "leesbaar", s.customPrompt || "");
      try {
        if ((s.provider || "claude") === "openai") {
          if (!s.openaiKey) return reject(new Error("Geen ChatGPT API key ingesteld."));
          const res = await fetch("https://api.openai.com/v1/chat/completions", {
            method: "POST", headers: { "Content-Type": "application/json", "Authorization": `Bearer ${s.openaiKey}` },
            body: JSON.stringify({ model: "gpt-4o", max_tokens: 1000, messages: [{ role: "system", content: sysPrompt }, { role: "user", content: userContent }] })
          });
          const data = await res.json();
          if (data.error) return reject(new Error(data.error.message));
          resolve(data.choices?.[0]?.message?.content || "");
        } else {
          if (!s.claudeKey) return reject(new Error("Geen Claude API key ingesteld."));
          const res = await fetch("https://api.anthropic.com/v1/messages", {
            method: "POST", headers: { "Content-Type": "application/json", "x-api-key": s.claudeKey, "anthropic-version": "2023-06-01", "anthropic-dangerous-direct-browser-access": "true" },
            body: JSON.stringify({ model: "claude-haiku-4-5-20251001", max_tokens: 1000, system: sysPrompt, messages: [{ role: "user", content: userContent }] })
          });
          const data = await res.json();
          if (data.error) return reject(new Error(data.error.message));
          resolve(data.content?.find(b => b.type === "text")?.text || "");
        }
      } catch(e) { reject(e); }
    });
  });
}

// --- Stijl-indicator ---
function updateStyleLabel(style) {
  const el = document.getElementById("active-style-label");
  const labels = { lime_style: "Lime Style", lime_tech: "Lime Style + tech" };
  if (el) el.textContent = labels[style] || "Lime Style";
}

// --- Dark/light mode ---
(function initTheme() {
  const saved = localStorage.getItem("ln-theme");
  const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
  const isDark = saved ? saved === "dark" : prefersDark;
  if (!isDark) document.body.classList.add("light");
  document.getElementById("theme-btn").textContent = isDark ? "🌙" : "☀️";
})();

document.getElementById("theme-btn").addEventListener("click", () => {
  const isLight = document.body.classList.toggle("light");
  document.getElementById("theme-btn").textContent = isLight ? "☀️" : "🌙";
  localStorage.setItem("ln-theme", isLight ? "light" : "dark");
});

// --- Snelkoppelingen ---
const SNIPPETS_KEY = "ln_snippets";
const DEFAULT_SNIPPETS = [
  "Klant teruggebeld, geen gehoor.",
  "Wachtend op reactie klant.",
  "Remote sessie uitgevoerd, probleem opgelost.",
  "Ticket gesloten na bevestiging klant.",
  "Doorgestuurd naar 2e lijn.",
  "Onderzocht, geen actie vereist."
];

async function loadSnippets() {
  return new Promise(resolve => {
    chrome.storage.local.get([SNIPPETS_KEY], r => resolve(r[SNIPPETS_KEY] || DEFAULT_SNIPPETS));
  });
}

async function saveSnippets(snippets) {
  return new Promise(resolve => chrome.storage.local.set({ [SNIPPETS_KEY]: snippets }, resolve));
}

async function renderSnippets() {
  const snippets = await loadSnippets();
  const list = document.getElementById("snippets-list");
  list.innerHTML = "";
  snippets.forEach((text, i) => {
    const item = document.createElement("div");
    item.className = "snippet-item";
    item.style.cssText = "display:flex;align-items:center;gap:6px;";

    const label = document.createElement("span");
    label.textContent = text;
    label.title = "Klik om te kopiëren";
    label.style.cssText = "flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;cursor:pointer;";
    label.addEventListener("click", () => {
      navigator.clipboard.writeText(text);
      const orig = label.textContent;
      label.textContent = "✓ Gekopieerd!";
      item.style.borderColor = "var(--green)";
      setTimeout(() => { label.textContent = orig; item.style.borderColor = ""; }, 1500);
    });

    const delBtn = document.createElement("button");
    delBtn.textContent = "×";
    delBtn.title = "Verwijderen";
    delBtn.style.cssText = "background:none;border:none;color:#6b7280;font-size:16px;cursor:pointer;padding:0 2px;flex-shrink:0;line-height:1;";
    delBtn.addEventListener("mouseenter", () => delBtn.style.color = "#ef4444");
    delBtn.addEventListener("mouseleave", () => delBtn.style.color = "#6b7280");
    delBtn.addEventListener("click", async () => {
      const current = await loadSnippets();
      await saveSnippets(current.filter((_, idx) => idx !== i));
      renderSnippets();
    });

    item.appendChild(label);
    item.appendChild(delBtn);
    list.appendChild(item);
  });
}

document.getElementById("snippet-add-btn").addEventListener("click", async () => {
  const input = document.getElementById("snippet-input");
  const val = input.value.trim();
  if (!val) return;
  const current = await loadSnippets();
  current.push(val);
  await saveSnippets(current);
  input.value = "";
  renderSnippets();
});

document.getElementById("snippet-input").addEventListener("keydown", e => {
  if (e.key === "Enter") document.getElementById("snippet-add-btn").click();
});

renderSnippets();

// ============================================================
// Script Tab
// ============================================================

const SCRIPT_ENGINEERS = [
  "Aad Schimmel", "Aleks Voloshyn", "Davy van Son", "Delano Visser",
  "Iris Pasman", "Maarten van der Horst", "Mike Camman", "Quinten Tieman",
  "Rick Haasnoot", "Sunny Tavares Delgado", "Tyrone Pique"
];

const SCRIPT_WEBHOOK_KEY = "ln_script_webhook";
const SCRIPT_TOKEN_KEY   = "ln_script_token";

// Base64 met Unicode-ondersteuning (btoa() breekt op niet-Latin1 tekens)
function toBase64Unicode(str) {
  const bytes = new TextEncoder().encode(str);
  let binary = "";
  bytes.forEach(b => binary += String.fromCharCode(b));
  return btoa(binary);
}

const SCRIPT_WEBHOOK_DEFAULT = "https://limenetworks02.app.n8n.cloud/webhook-test/atea-script";

async function loadScriptSettings() {
  return new Promise(resolve => {
    chrome.storage.local.get([SCRIPT_WEBHOOK_KEY, SCRIPT_TOKEN_KEY], async (r) => {
      resolve({
        webhookUrl: r[SCRIPT_WEBHOOK_KEY] || SCRIPT_WEBHOOK_DEFAULT,
        token:      await decryptValue(r[SCRIPT_TOKEN_KEY] || "")
      });
    });
  });
}

async function saveScriptSettings(webhookUrl, token) {
  const toSave = { [SCRIPT_WEBHOOK_KEY]: webhookUrl };
  if (token) toSave[SCRIPT_TOKEN_KEY] = await encryptValue(token);
  return new Promise(resolve => chrome.storage.local.set(toSave, resolve));
}

// Scan de actieve tab (claude.ai) naar het laatste code blok
async function scanActiveTabForScript() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    // Strikte hostname check — voorkomt dat een URL als https://attacker.com/?ref=claude.ai matcht
    let isClaudeTab = false;
    try {
      if (tab?.url) {
        const h = new URL(tab.url).hostname;
        isClaudeTab = (h === "claude.ai" || h.endsWith(".claude.ai"));
      }
    } catch {}
    if (!isClaudeTab) return null;
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        const blocks = document.querySelectorAll("pre code, code");
        if (!blocks.length) return null;
        const last    = blocks[blocks.length - 1];
        const content = (last.textContent || "").trim();
        if (!content) return null;
        const firstLine = content.split("\n")[0].trim();
        const match = firstLine.match(/^#\s*(?:[Ss]cript:\s*)?([^\s]+\.[a-zA-Z0-9]{1,10})/);
        return { content, filename: match ? match[1] : null };
      }
    });
    return results?.[0]?.result || null;
  } catch(e) { return null; }
}

// AI call voor script titel + beschrijving — geeft JSON {title, description} terug
async function callScriptAI(scriptContent, filename) {
  return new Promise((resolve, reject) => {
    loadSettings(async (s) => {
      const name = filename || "script";
      const sysPrompt = `Je bent een IT documentatie specialist bij een Nederlands MSP.
Gegeven een PowerShell (of ander) script, genereer:
- Een beknopte professionele Nederlandstalige ticket TITEL (max 80 tekens), formaat: "Script: [bestandsnaam] \u2013 [korte omschrijving functie]"
- Een duidelijke BESCHRIJVING van 2-4 zinnen: wat doet het script, waarvoor is het bedoeld, eventuele parameters of vereisten.
Geef ALLEEN een JSON object terug: {"title": "...", "description": "..."}`;
      const userContent = `Bestandsnaam: ${name}\n\nScript:\n${scriptContent}`;
      try {
        let raw = "";
        if ((s.provider || "claude") === "openai") {
          if (!s.openaiKey) return reject(new Error("Geen ChatGPT API key ingesteld."));
          const res = await fetch("https://api.openai.com/v1/chat/completions", {
            method: "POST",
            headers: { "Content-Type": "application/json", "Authorization": `Bearer ${s.openaiKey}` },
            body: JSON.stringify({
              model: "gpt-4o", max_tokens: 400,
              messages: [{ role: "system", content: sysPrompt }, { role: "user", content: userContent }]
            })
          });
          if (!res.ok) return reject(new Error(`OpenAI HTTP ${res.status}`));
          const data = await res.json();
          if (data.error) return reject(new Error(data.error.message));
          raw = data.choices?.[0]?.message?.content?.trim() || "";
        } else {
          if (!s.claudeKey) return reject(new Error("Geen Claude API key ingesteld."));
          const res = await fetch("https://api.anthropic.com/v1/messages", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "x-api-key": s.claudeKey,
              "anthropic-version": "2023-06-01",
              "anthropic-dangerous-direct-browser-access": "true"
            },
            body: JSON.stringify({
              model: "claude-haiku-4-5-20251001", max_tokens: 400,
              system: sysPrompt,
              messages: [{ role: "user", content: userContent }]
            })
          });
          if (!res.ok) return reject(new Error(`Anthropic HTTP ${res.status}`));
          const data = await res.json();
          if (data.error) return reject(new Error(data.error.message));
          raw = data.content?.find(b => b.type === "text")?.text?.trim() || "";
        }
        // JSON parsen — AI kan ```json ... ``` wrapping toevoegen
        const jsonMatch = raw.match(/\{[\s\S]*\}/);
        if (!jsonMatch) return reject(new Error("AI gaf geen geldig JSON terug."));
        const parsed = JSON.parse(jsonMatch[0]);
        if (!parsed.title || !parsed.description) return reject(new Error("AI response mist titel of beschrijving."));
        resolve(parsed);
      } catch(e) { reject(e); }
    });
  });
}

// Ticket aanmaken via N8N webhook
async function createTicketViaN8N(payload) {
  const settings = await loadScriptSettings();
  if (!settings.webhookUrl) throw new Error("Geen webhook URL ingesteld. Stel deze in via ⚙️ → Script → Webhook.");
  const headers = { "Content-Type": "application/json" };
  if (settings.token) headers["Authorization"] = `Bearer ${settings.token}`;
  const res = await fetch(settings.webhookUrl, {
    method: "POST", headers, body: JSON.stringify(payload)
  });
  if (!res.ok) throw new Error(`Webhook HTTP ${res.status}`);
  const data = await res.json();
  if (data.error) throw new Error(data.error);
  return data;
}

// --- Script form state cache ---
const SCRIPT_FORM_KEY = "ln_script_form";
let _scriptFormSaveTimer = null;

function saveScriptForm() {
  clearTimeout(_scriptFormSaveTimer);
  _scriptFormSaveTimer = setTimeout(() => {
    chrome.storage.local.set({
      [SCRIPT_FORM_KEY]: {
        content:     document.getElementById("script-content")?.value     || "",
        filename:    document.getElementById("script-filename")?.value    || "",
        title:       document.getElementById("script-title")?.value       || "",
        description: document.getElementById("script-description")?.value || "",
        engineer:    document.getElementById("script-engineer")?.value    || "",
        queue:       document.getElementById("script-queue")?.value       || "servicedesk"
      }
    });
  }, 300);
}

function clearScriptForm() {
  ["script-content","script-filename","script-title","script-description"].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.value = "";
  });
  document.getElementById("script-engineer").value = "";
  document.getElementById("script-queue").value    = "servicedesk";
  document.getElementById("script-detect-badge").textContent = "";
  document.getElementById("script-result").classList.add("hidden");
  document.getElementById("script-status").textContent = "";
  chrome.storage.local.remove([SCRIPT_FORM_KEY]);
}

async function restoreScriptForm() {
  return new Promise(resolve => {
    chrome.storage.local.get([SCRIPT_FORM_KEY], r => resolve(r[SCRIPT_FORM_KEY] || null));
  });
}

// Script tab initialiseren (eenmalig bij eerste klik)
let _scriptTabInit = false;
async function initScriptTab() {
  if (_scriptTabInit) return;
  _scriptTabInit = true;

  // Engineer dropdown vullen
  const engineerSelect = document.getElementById("script-engineer");
  SCRIPT_ENGINEERS.forEach(name => {
    const opt = document.createElement("option");
    opt.value = name; opt.textContent = name;
    engineerSelect.appendChild(opt);
  });

  // Formulier state herstellen
  const saved = await restoreScriptForm();
  if (saved) {
    if (saved.content)     document.getElementById("script-content").value     = saved.content;
    if (saved.filename)    document.getElementById("script-filename").value    = saved.filename;
    if (saved.title)       document.getElementById("script-title").value       = saved.title;
    if (saved.description) document.getElementById("script-description").value = saved.description;
    if (saved.engineer)    document.getElementById("script-engineer").value    = saved.engineer;
    if (saved.queue)       document.getElementById("script-queue").value       = saved.queue;
  }

  // Auto-save op elke wijziging
  ["script-content","script-filename","script-title","script-description","script-engineer","script-queue"].forEach(id => {
    const el = document.getElementById(id);
    if (el) { el.addEventListener("input", saveScriptForm); el.addEventListener("change", saveScriptForm); }
  });

  // Badge helper
  function setDetectBadge(type) {
    const badge = document.getElementById("script-detect-badge");
    const styles = {
      auto:  "background:var(--bg-inset);color:var(--green);border:1px solid var(--border-accent);",
      manual:"background:var(--bg-inset);color:var(--yellow);border:1px solid var(--yellow);",
      none:  "background:transparent;color:var(--text-muted);border:none;"
    };
    const labels = { auto: "✓ Auto-detected", manual: "⚠ Handmatig", none: "Geen script gevonden" };
    badge.textContent  = labels[type] || "";
    badge.style.cssText = `font-size:10px;padding:2px 8px;border-radius:10px;font-weight:600;${styles[type] || ""}`;
  }

  // Scan knop
  document.getElementById("script-scan-btn").addEventListener("click", async () => {
    const btn = document.getElementById("script-scan-btn");
    btn.textContent = "⏳ Scannen..."; btn.disabled = true;
    const result = await scanActiveTabForScript();
    btn.textContent = "🔍 Scan actieve tab"; btn.disabled = false;
    if (!result) { setDetectBadge("none"); return; }
    document.getElementById("script-content").value = result.content;
    if (result.filename) {
      document.getElementById("script-filename").value = result.filename;
      setDetectBadge("auto");
    } else {
      setDetectBadge("manual");
    }
  });

  // Bestandskiezer
  document.getElementById("script-browse-btn").addEventListener("click", () => {
    document.getElementById("script-file-input").click();
  });

  document.getElementById("script-file-input").addEventListener("change", (e) => {
    const file = e.target.files[0];
    if (!file) return;
    document.getElementById("script-filename").value = file.name;
    const reader = new FileReader();
    reader.onload = (ev) => {
      document.getElementById("script-content").value = ev.target.result;
      setDetectBadge("auto");
      saveScriptForm();
    };
    reader.onerror = () => alert("Fout bij lezen van bestand.");
    reader.readAsText(file, "UTF-8");
    // Reset zodat hetzelfde bestand opnieuw gekozen kan worden
    e.target.value = "";
  });

  // Leegmaken knop
  document.getElementById("script-clear-btn").addEventListener("click", () => {
    if (!confirm("Formulier leegmaken?")) return;
    clearScriptForm();
  });

  // Genereer knop
  document.getElementById("script-generate-btn").addEventListener("click", async () => {
    const content  = document.getElementById("script-content").value.trim();
    const filename = document.getElementById("script-filename").value.trim();
    if (!content) { alert("Plak eerst een script."); return; }
    const btn = document.getElementById("script-generate-btn");
    btn.textContent = "⏳ Genereren..."; btn.disabled = true;
    try {
      const result = await callScriptAI(content, filename);
      document.getElementById("script-title").value       = result.title;
      document.getElementById("script-description").value = result.description;
    } catch(e) { alert("Fout bij genereren: " + e.message); }
    btn.textContent = "🤖 Genereer titel & beschrijving"; btn.disabled = false;
  });

  // Aanmaken knop
  document.getElementById("script-submit-btn").addEventListener("click", async () => {
    const content  = document.getElementById("script-content").value.trim();
    const filename = document.getElementById("script-filename").value.trim();
    const title    = document.getElementById("script-title").value.trim();
    const desc     = document.getElementById("script-description").value.trim();
    const engineer = document.getElementById("script-engineer").value;
    const queue    = document.getElementById("script-queue").value;
    if (!content)  { alert("Geen script ingevoerd."); return; }
    if (!filename) { alert("Vul een bestandsnaam in."); return; }
    if (!title)    { alert("Vul een titel in of gebruik Genereer."); return; }
    if (!engineer) { alert("Selecteer een engineer."); return; }
    const btn    = document.getElementById("script-submit-btn");
    const status = document.getElementById("script-status");
    btn.textContent = "⏳ Aanmaken..."; btn.disabled = true;
    status.textContent = "";
    try {
      const result = await createTicketViaN8N({
        filename, title, description: desc, engineer, queue,
        script: toBase64Unicode(content)
      });
      // Veilige DOM-opbouw: ticket_number en ticket_id komen uit een externe webhook-response
      // en worden NOOIT als HTML geinjecteerd. Sanitize ticket_id strikt naar cijfers,
      // bouw URL en link-element via createElement zodat injectie onmogelijk is.
      const ticketIdNum = String(result.ticket_id || "").replace(/[^0-9]/g, "");
      const safeUrl = ticketIdNum
        ? `https://ww19.autotask.net/Mvc/ServiceDesk/TicketDetail.mvc?workspace=False&ids%5B0%5D=${ticketIdNum}`
        : "";
      const infoEl = document.getElementById("script-ticket-info");
      infoEl.textContent = ""; // clear

      const titleDiv = document.createElement("div");
      titleDiv.style.cssText = "font-weight:600;color:var(--green);font-size:14px;";
      titleDiv.textContent = result.ticket_number || "Ticket aangemaakt";
      infoEl.appendChild(titleDiv);

      if (safeUrl) {
        const link = document.createElement("a");
        link.href = safeUrl;
        link.target = "_blank";
        link.rel = "noopener noreferrer";
        link.style.cssText = "color:var(--blue);font-size:12px;text-decoration:none;";
        link.textContent = "🔗 Openen in Autotask";
        infoEl.appendChild(link);
      }

      const attachDiv = document.createElement("div");
      attachDiv.style.cssText = "font-size:11px;color:var(--text-muted);margin-top:2px;";
      attachDiv.textContent = result.attachment_ok ? "📎 Script bijlage toegevoegd" : "⚠️ Bijlage niet toegevoegd";
      infoEl.appendChild(attachDiv);

      document.getElementById("script-result").classList.remove("hidden");
      chrome.storage.local.remove([SCRIPT_FORM_KEY]);
    } catch(e) {
      status.textContent = "❌ " + e.message;
      status.style.color = "#d9534f";
    }
    btn.textContent = "📋 Ticket aanmaken"; btn.disabled = false;
  });
}

// --- Tabs ---
let settingsOpen = false;
let featuresOpen = false;

function closeOverlays() {
  settingsOpen = false;
  featuresOpen = false;
  document.getElementById("settings-btn").style.opacity = "0.6";
  document.getElementById("features-btn").style.opacity = "0.6";
}

document.querySelectorAll(".tab").forEach(tab => {
  tab.addEventListener("click", () => {
    document.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
    document.querySelectorAll(".tab-content").forEach(c => c.classList.add("hidden"));
    tab.classList.add("active");
    document.getElementById("tab-" + tab.dataset.tab).classList.remove("hidden");
    closeOverlays();
    if (tab.dataset.tab === "db")     renderDbTab();
    if (tab.dataset.tab === "script") initScriptTab();
  });
});

document.getElementById("settings-btn").addEventListener("click", () => {
  settingsOpen = !settingsOpen;
  featuresOpen = false;
  document.getElementById("features-btn").style.opacity = "0.6";
  document.querySelectorAll(".tab-content").forEach(c => c.classList.add("hidden"));
  document.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
  if (settingsOpen) {
    document.getElementById("tab-settings").classList.remove("hidden");
    document.getElementById("settings-btn").style.opacity = "1";
  } else {
    document.getElementById("tab-quick").classList.remove("hidden");
    document.querySelector(".tab[data-tab='quick']").classList.add("active");
    document.getElementById("settings-btn").style.opacity = "0.6";
  }
});

document.getElementById("features-btn").addEventListener("click", () => {
  featuresOpen = !featuresOpen;
  settingsOpen = false;
  document.getElementById("settings-btn").style.opacity = "0.6";
  document.querySelectorAll(".tab-content").forEach(c => c.classList.add("hidden"));
  document.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
  if (featuresOpen) {
    document.getElementById("tab-features").classList.remove("hidden");
    document.getElementById("features-btn").style.opacity = "1";
  } else {
    document.getElementById("tab-quick").classList.remove("hidden");
    document.querySelector(".tab[data-tab='quick']").classList.add("active");
    document.getElementById("features-btn").style.opacity = "0.6";
  }
});

// --- Database wissen ---
document.getElementById("db-clear-btn").addEventListener("click", async () => {
  if (!confirm("Weet je zeker dat je de volledige database wilt wissen?\nDeze actie kan niet ongedaan worden gemaakt.")) return;
  chrome.storage.local.remove([DB_KEY], () => {
    const status = document.getElementById("db-status");
    status.textContent = "✓ Database gewist.";
    status.style.color = "#84cc16";
    setTimeout(() => { status.textContent = ""; }, 3000);
    renderDbTab();
  });
});

document.querySelectorAll(".change-key-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    const t = btn.dataset.target;
    document.getElementById(`${t}-key-display`).classList.add("hidden");
    document.getElementById(`${t}-key-input-row`).classList.remove("hidden");
    document.getElementById(`${t}-api-key`).value = "";
    document.getElementById(`${t}-api-key`).focus();
  });
});

document.querySelectorAll(".btn-copy").forEach(btn => {
  btn.addEventListener("click", () => {
    navigator.clipboard.writeText(document.getElementById(btn.dataset.target).innerText);
    btn.textContent = "✓ Gekopieerd!";
    setTimeout(() => btn.textContent = "Kopieer", 2000);
  });
});

document.getElementById("save-settings").addEventListener("click", async () => {
  const claudeKey    = document.getElementById("claude-api-key").value.trim();
  const openaiKey    = document.getElementById("openai-api-key").value.trim();
  const provider     = document.querySelector('input[name="ai-provider"]:checked')?.value || "claude";
  const style        = document.querySelector('input[name="style"]:checked')?.value || "leesbaar";
  const customPrompt = document.getElementById("custom-prompt").value.trim();
  const webhookUrl   = document.getElementById("script-webhook-url").value.trim();
  const webhookToken = document.getElementById("script-webhook-token").value.trim();
  const status       = document.getElementById("settings-status");
  const toSave = { provider, style, customPrompt };
  if (claudeKey) toSave.claudeKey = claudeKey;
  if (openaiKey) toSave.openaiKey = openaiKey;
  await saveSettings(toSave, async () => {
    await saveScriptSettings(webhookUrl, webhookToken);
    status.textContent = "✓ Opgeslagen!";
    status.style.color = "#84cc16";
    setTimeout(() => status.textContent = "", 2000);
    if (claudeKey) { document.getElementById("claude-key-display").classList.remove("hidden"); document.getElementById("claude-key-input-row").classList.add("hidden"); }
    if (openaiKey) { document.getElementById("openai-key-display").classList.remove("hidden"); document.getElementById("openai-key-input-row").classList.add("hidden"); }
    updateStyleLabel(style);
  });
});

document.getElementById("open-shortcuts-btn").addEventListener("click", () => {
  chrome.tabs.create({ url: navigator.userAgent.includes("Edg/") ? "edge://extensions/shortcuts" : "chrome://extensions/shortcuts" });
});

document.getElementById("quick-btn").addEventListener("click", async () => {
  const input = document.getElementById("quick-input").value.trim();
  if (!input) return;
  const btn = document.getElementById("quick-btn");
  btn.textContent = "Bezig..."; btn.disabled = true;
  try {
    const result = await callAI(`Polish this time entry:\n\n${input}`, detectLang(input));
    document.getElementById("quick-result").textContent = result;
    document.getElementById("quick-output").classList.remove("hidden");
  } catch(e) { alert("Fout: " + e.message); }
  btn.textContent = "✨ Polijst Entry"; btn.disabled = false;
});

window.addEventListener("load", () => {
  const currentVersion = chrome.runtime.getManifest().version;
  const versionEl = document.getElementById("update-current-version");
  if (versionEl) versionEl.textContent = `Geinstalleerd: v${currentVersion}`;

  document.getElementById("update-check-btn").addEventListener("click", () => {
    setUpdateStatus("Controleren...");
    document.getElementById("update-actions").style.display = "none";
    checkForUpdate(true);
  });

  checkForUpdate();

  // Webhook URL laden (token niet tonen — password veld blijft leeg als indicator)
  loadScriptSettings().then(ws => {
    document.getElementById("script-webhook-url").value = ws.webhookUrl;
  });

  loadSettings((s) => {
    const pr = document.querySelector(`input[name="ai-provider"][value="${s.provider}"]`);
    if (pr) pr.checked = true;
    if (s.claudeKey) { document.getElementById("claude-key-display").classList.remove("hidden"); document.getElementById("claude-key-input-row").classList.add("hidden"); }
    if (s.openaiKey) { document.getElementById("openai-key-display").classList.remove("hidden"); document.getElementById("openai-key-input-row").classList.add("hidden"); }
    const sr = document.querySelector(`input[name="style"][value="${s.style}"]`);
    if (sr) sr.checked = true;
    else document.querySelector('input[name="style"][value="lime_style"]').checked = true;
    if (s.customPrompt) document.getElementById("custom-prompt").value = s.customPrompt;
    updateStyleLabel(s.style || "leesbaar");
  });

  // Features panel initialiseren
  loadFeatures().then(features => {
    document.getElementById("feat-mail").checked            = features.mailDraft;
    document.getElementById("feat-snippets").checked        = features.snelkoppelingen;
    document.getElementById("feat-oplossing").checked       = features.oplossing;
    document.getElementById("feat-toolbar-polish").checked  = features.toolbarPolish  !== false;
    document.getElementById("feat-toolbar-summary").checked = features.toolbarSummary !== false;
    document.getElementById("feat-toolbar-snippets").checked= features.toolbarSnippets !== false;

    const allFeatIds = ["feat-mail","feat-snippets","feat-oplossing","feat-toolbar-polish","feat-toolbar-summary","feat-toolbar-snippets"];
    allFeatIds.forEach(id => {
      document.getElementById(id).addEventListener("change", async () => {
        const f = {
          mailDraft:       document.getElementById("feat-mail").checked,
          snelkoppelingen: document.getElementById("feat-snippets").checked,
          oplossing:       document.getElementById("feat-oplossing").checked,
          toolbarPolish:   document.getElementById("feat-toolbar-polish").checked,
          toolbarSummary:  document.getElementById("feat-toolbar-summary").checked,
          toolbarSnippets: document.getElementById("feat-toolbar-snippets").checked
        };
        await saveFeatures(f);
        const status = document.getElementById("features-status");
        status.textContent = "✓ Opgeslagen!";
        setTimeout(() => { status.textContent = ""; }, 2000);
      });
    });
  });
});
